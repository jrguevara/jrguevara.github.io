# Traspaso para redactar la guía 4

Redactar en español y Markdown una guía progresiva de **dashboard y exploración** a partir de las fuentes adjuntas. El estudiante ya completó la guía 3 y conoce React, Express y el CRUD privado de GPB. Al terminar, debe poder explicar por qué el resumen usa la colección completa y cómo se filtra antes de paginar.

## Secuencia didáctica

1. Partir de `gpb-dev/guia-03` y crear `gpb-dev/guia-04` con la copia selectiva documentada. Preparar un entorno privado propio y conservar el lock verificado.
2. Introducir Recharts y Chart según [FUENTES.md](FUENTES.md), con descripción, razón de uso, enlace oficial, requisitos, instalación y comprobación. Indicar la carpeta donde se ejecuta cada comando.
3. Presentar `GET /api/dashboard` y los parámetros validados de `GET /api/gunpla`. Recorrer primero el alcance por propietario y registros visibles, y luego ambas consultas. Explicar el criterio de orden por fecha de creación e identificador y la búsqueda literal sin distinguir mayúsculas.
4. Extraer la carga y el reintento de recursos compartidos, completar el dashboard y conectar la exploración por URL. Mostrar los estados vacíos, de carga y error y el caso de 13 coincidencias repartidas en dos páginas.
5. Guiar un recorrido por dashboard, colección, búsqueda y tres filtros, formulario de alta, detalle, edición y eliminación. Incluir las capturas **de la aplicación real de guia-04** en el cuerpo de la guía, vinculadas a las acciones, con variantes de escritorio y móvil. Usar el [índice de capturas](CAPTURAS-APP.md) y el [diagrama](DIAGRAMAS.md). Mantener proporciones y conservar enlaces al PNG completo.
6. Registrar resultados esperados y observados según [REGISTRO.md](REGISTRO.md). Explicar el alcance de los adaptadores de memoria, la prueba separada del repositorio y el transporte preparatorio de Electron. Conectar el cierre con Render en etapa 5.

## Adjuntos precisos

Usar [MATERIAL-CHATGPT.zip](MATERIAL-CHATGPT.zip) para adjuntar las fuentes de guia-04, este traspaso, las capturas, el diagrama y el inventario. Adjuntar los archivos de la columna **Nuevos o modificados** del registro desde `gpb-dev/guia-04`, más `package.json`, `pnpm-workspace.yaml`, `playwright.config.js`, `server/.env.example` y `tests/local-api.js` como contexto. Adjuntar `gpb-dev/guia-03` como referencia previa únicamente cuando haga falta reconstruirla. Los archivos de configuración privada quedan fuera del material.

Describir el código por incrementos con rutas exactas y bloques reproducibles. La guía redactada se reproducirá por separado, desde la etapa anterior, cuando el docente lo indique. La fecha editorial y los datos de Canvas de la guía 4 se confirmarán por separado. En un futuro artículo del sitio, usar el visor de imágenes del tema y enlaces de texto independientes para abrir el PNG completo.
