# Diagrama de la etapa 4

[Visor oscuro](../../../.archify/dataflow-gpb-dashboard-exploracion-20261119-160000/gpb-dashboard-exploracion.html?theme=dark) · [PNG](diagramas-publicacion/gpb-dashboard-exploracion.png) · [SVG oscuro fijo](diagramas-publicacion/gpb-dashboard-exploracion.svg)

El flujo muestra el alcance privado común y las dos consultas. El dashboard resume toda la colección activa. Mi colección aplica búsqueda y filtros antes de obtener la página.

| Elemento | Fuente de guia-04 |
|---|---|
| Sesión y propietario de la consulta | [app.js](../../../gpb-dev/guia-04/server/src/app.js#L117), [collection-routes.js](../../../gpb-dev/guia-04/server/src/collection-routes.js#L24) |
| Filtros, orden, recuento y paginación | [gunpla.js](../../../gpb-dev/guia-04/server/src/gunpla.js#L33) |
| Agrupación y registros recientes | [gunpla.js](../../../gpb-dev/guia-04/server/src/gunpla.js#L45), [exploration.js](../../../gpb-dev/guia-04/server/src/exploration.js) |
| Representación en React | [Dashboard.jsx](../../../gpb-dev/guia-04/client/src/dashboard/Dashboard.jsx), [Collection.jsx](../../../gpb-dev/guia-04/client/src/collection/Collection.jsx) |

La correspondencia es con las fuentes conservadas de guia-04 y su inventario SHA-256. Validación, entrega, integridad y navegador aprobados. Se comprobó el atributo `data-theme="dark"` de la exportación SVG y se revisaron visualmente ambas exportaciones.
