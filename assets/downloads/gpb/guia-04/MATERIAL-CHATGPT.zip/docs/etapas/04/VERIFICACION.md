# Verificación de la guía 4

19/11/2026. Se reconstruyó la guía 4 desde las fuentes conservadas de `gpb-dev/guia-03` en una carpeta temporal. Se ejecutaron en orden los bloques de copia e instalación y se transcribieron los 13 bloques de archivo del Markdown. Los 13 archivos, el manifiesto de cliente y el lock coincidieron byte por byte con `gpb-dev/guia-04`. La copia aislada usó su configuración de prueba sin un archivo privado `server/.env`.

| Comprobación | Resultado |
|---|---|
| Node 26.13.1, pnpm 12.18.0 y Vite+ 1.6.0 | Versiones observadas |
| Recharts 3.10.1 y react-is 19.3.1 | Versiones exactas y lock coincidente |
| `pnpm check` y `pnpm build` | Aprobados |
| `pnpm test` | 22/22 aprobadas, incluidos aislamiento, filtros, páginas y totales tras CRUD |
| `pnpm test:transport` | 5/5 aprobados en la reproducción |
| Consultas del repositorio con MongoDB Community 8.0.38 | Aprobadas en la referencia mediante el verificador local |
| Capturas con fotos y datos de ejemplo | 22 vistas renovadas y revisadas en la referencia. Portada y galería del RG MS-06F Zaku II cargadas a través del flujo real de la app con adaptadores de memoria. |

La revisión de navegador en la referencia también aprobó con las fotos: `GPB_GUNPLA_PHOTOS=/private/tmp/gpb04-fotos GPB_DASHBOARD_CAPTURES="$PWD/../../docs/etapas/04/capturas" pnpm test:transport`. La copia aislada ejecutó el recorrido local sin las fotos opcionales. La prueba de MongoDB se realizó en la referencia. Los proveedores remotos de Atlas y Cloudinary conservan las comprobaciones de la etapa 3 y quedan fuera de esta reproducción local. [Fuentes y fotografías](CAPTURAS-APP.md).
