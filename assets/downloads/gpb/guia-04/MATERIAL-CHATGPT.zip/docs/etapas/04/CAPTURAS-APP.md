# Capturas reales de GPB · etapa 4

22 capturas oscuras tomadas en Chromium desde `gpb-dev/guia-04`, con la interfaz React y la API Express de la etapa y datos ficticios en memoria. Escritorio a 1440 × 1000 y móvil a 390 × 844. Las imágenes son de página completa, conservan la proporción original y algunas requieren desplazamiento vertical.

| Pantalla y acción | Escritorio | Móvil |
|---|---|---|
| Dashboard con 14 Gunpla, dona, barras y enlaces recientes | [PNG](capturas/dashboard-escritorio.png) | [PNG](capturas/dashboard-movil.png) |
| Dashboard de una cuenta sin modelos | [PNG](capturas/dashboard-vacio-escritorio.png) | [PNG](capturas/dashboard-vacio-movil.png) |
| Colección, primera página de dos | [PNG](capturas/coleccion-escritorio.png) | [PNG](capturas/coleccion-movil.png) |
| Colección vacía y acceso al formulario | [PNG](capturas/coleccion-vacia-escritorio.png) | [PNG](capturas/coleccion-vacia-movil.png) |
| Filtros combinados, una coincidencia | [PNG](capturas/filtros-con-resultados-escritorio.png) | [PNG](capturas/filtros-con-resultados-movil.png) |
| Búsqueda sin coincidencias | [PNG](capturas/sin-coincidencias-escritorio.png) | [PNG](capturas/sin-coincidencias-movil.png) |
| Formulario para crear un Gunpla | [PNG](capturas/formulario-crear-escritorio.png) | [PNG](capturas/formulario-crear-movil.png) |
| Detalle del RG MS-06F Zaku II con portada y galería | [PNG](capturas/detalle-escritorio.png) | [PNG](capturas/detalle-movil.png) |
| Formulario para editar el estado | [PNG](capturas/formulario-editar-escritorio.png) | [PNG](capturas/formulario-editar-movil.png) |
| Confirmación de eliminación | [PNG](capturas/confirmar-eliminacion-escritorio.png) | [PNG](capturas/confirmar-eliminacion-movil.png) |
| Aviso de éxito y colección de 13 modelos | [PNG](capturas/resultado-eliminacion-escritorio.png) | [PNG](capturas/resultado-eliminacion-movil.png) |

## Comprobación

Desde `gpb-dev/guia-04`, se ejecutó `GPB_GUNPLA_PHOTOS=/private/tmp/gpb04-fotos GPB_DASHBOARD_CAPTURES="$PWD/../../docs/etapas/04/capturas" pnpm test:transport`. El recorrido creó una cuenta ficticia y un Gunpla mediante los formularios. Incorporó 13 modelos por la API local, abrió un registro reciente, recorrió ambas páginas, combinó filtros, editó un estado y eliminó el modelo creado. Comprobó que los totales se actualizan y simuló una respuesta 503 para verificar el reintento.

El test midió el ancho del documento frente al de la ventana en todas las vistas. Se inspeccionaron visualmente las 22 capturas en hojas de contacto y se amplió el selector de grado en móvil para que se leyera completo. [Manifiesto de comprobación](capturas/COMPROBACION.json).

La guía debe insertar las capturas junto a cada acción, a su proporción original y con enlaces para abrir los PNG completos. Para el artículo, conservar el visor propio del tema y usar un enlace de texto separado para cada PNG completo.


## Modelos y fotografías para la edición del 17/11/2026

Los modelos mostrados corresponden a kits Gunpla. La cuenta, la colección, los estados y las notas son ficticios. El protagonista del recorrido es el RG MS-06F Zaku II a escala 1/144. [Manual oficial de Bandai](https://manual.bandai-hobby.net/menus/detail/659).

La caja y la pieza de la galería son fotografías de Gravis bajo [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). Se redujeron a un máximo de 1200 píxeles por lado, se convirtieron a WebP y se usaron como `caja.webp` y `pie.webp`. Los encuadres y adaptaciones fotográficas mantienen esa licencia. [Caja del kit](https://commons.wikimedia.org/wiki/File:Gunpla_model_packed.jpg) · [Pieza montada](https://commons.wikimedia.org/wiki/File:Gunpla_foot_assembly.jpg).

El recorrido usa el formulario real de GPB para subir ambos WebP. Chromium muestra las fotos desde el adaptador en memoria. Los demás kits aparecen con la portada de reemplazo que usa la app para los registros sin foto.
