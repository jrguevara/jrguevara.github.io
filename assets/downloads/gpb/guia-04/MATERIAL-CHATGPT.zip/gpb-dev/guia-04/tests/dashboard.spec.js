import { test, expect } from '@playwright/test';
import { mkdir, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

const captureDir = process.env.GPB_DASHBOARD_CAPTURES;
const viewports = { escritorio: { width: 1440, height: 1000 }, movil: { width: 390, height: 844 } };

test('dashboard y exploración: recorrido con cambios reales en la colección', async ({ page }) => {
  test.setTimeout(75_000);
  const captures = [];
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await page.setViewportSize(viewports.escritorio);
  async function capture(name) {
    for (const [size, viewport] of Object.entries(viewports)) {
      await page.setViewportSize(viewport);
      await page.locator('main img').evaluateAll((images) => Promise.all(images.map((image) => { image.loading = 'eager'; return image.decode(); })));
      await page.evaluate(() => new Promise((done) => requestAnimationFrame(() => requestAnimationFrame(done))));
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), name + ' ' + size).toBe(true);
      if (captureDir) {
        const file = name + '-' + size + '.png';
        await page.screenshot({ path: join(captureDir, file), fullPage: true, animations: 'disabled' });
        captures.push({ file, path: new URL(page.url()).pathname, viewport, horizontalOverflow: false });
      }
    }
    await page.setViewportSize(viewports.escritorio);
  }

  await page.goto('/registro');
  await page.getByLabel('Nombre de usuario').fill('piloto_demo');
  await page.getByLabel('Correo electrónico').fill('piloto_demo@example.com');
  await page.getByLabel('Contraseña', { exact: true }).fill('Clave de prueba 123!');
  await page.getByRole('button', { name: 'Crear cuenta', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'Tu colección está vacía' })).toBeVisible();
  await capture('dashboard-vacio');
  await page.getByRole('link', { name: 'Mi colección', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'El primer build está por llegar' })).toBeVisible();
  await capture('coleccion-vacia');
  await page.getByRole('link', { name: 'Agregar mi primer Gunpla' }).click();
  // Los modelos auxiliares se crean por la API local con la sesión de la cuenta ficticia.
  const fixtures = [
    ['Gundam Calibarn', 1, 0, 'Armado'], ['Gundam Lfrith', 1, 0, 'Sin armar'],
    ['Wing Gundam Zero', 3, 1, 'En progreso'], ['Gundam Exia', 2, 0, 'Armado'],
    ['Gundam Barbatos', 3, 1, 'En progreso'], ['MS-06S Char’s Zaku II', 1, 0, 'Armado'],
    ['Gundam Unicorn', 2, 0, 'En progreso'], ['Sazabi', 2, 0, 'Armado'],
    ['Gundam Mk-II', 1, 0, 'Sin armar'], ['Gundam Dynames', 3, 1, 'Armado'],
    ['Strike Freedom Gundam', 4, 2, 'Sin armar'], ['Gundam Schwarzette', 1, 0, 'Armado'],
    ['Gundam Pharact', 1, 0, 'En progreso'],
  ];
  await page.evaluate(async (rows) => {
    const { csrfToken } = await fetch('/api/auth/csrf').then((response) => response.json());
    const { grades, scales } = await fetch('/api/catalogs').then((response) => response.json());
    for (const [name, grade, scale, state] of rows) {
      const response = await fetch('/api/gunpla', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken },
        body: JSON.stringify({ name, grade: grades[grade].id, scale: scales[scale].id, state }),
      });
      if (response.status !== 201) throw new Error('No se pudo crear el modelo ficticio.');
    }
  }, fixtures);
  await page.getByLabel('Grado', { exact: true }).selectOption({ label: 'Real Grade (RG)' });
  await page.getByLabel('Escala', { exact: true }).selectOption({ label: '1/144' });
  await page.getByLabel('Descripción (opcional)').fill('Kit Real Grade a escala 1/144. La caja contiene las piezas sujetas a sus marcos.');
  const name = page.getByLabel('Nombre', { exact: true });
  await name.fill('MS-06F Zaku II');
  await expect(name).toHaveValue('MS-06F Zaku II');
  await capture('formulario-crear');
  await expect(name).toHaveValue('MS-06F Zaku II');
  await page.getByRole('button', { name: 'Guardar Gunpla' }).click();
  await expect(page.getByRole('heading', { name: 'MS-06F Zaku II', exact: true })).toBeVisible();

  if (process.env.GPB_GUNPLA_PHOTOS) {
    const photos = process.env.GPB_GUNPLA_PHOTOS;
    let coverUrl;
    await page.route('https://res.cloudinary.com/demo/image/upload/**', (route) =>
      route.fulfill({
        path: join(photos, !coverUrl || route.request().url() === coverUrl ? 'caja.webp' : 'pie.webp'),
        contentType: 'image/webp',
      }),
    );
    await page.getByLabel('Archivo para subir portada', { exact: true }).setInputFiles(join(photos, 'caja.webp'));
    await page.getByRole('button', { name: 'Subir portada', exact: true }).click();
    const cover = page.getByRole('img', { name: 'Portada de MS-06F Zaku II' });
    await expect(cover).toBeVisible();
    coverUrl = await cover.getAttribute('src');
    await page.getByLabel('Archivo para agregar a galería', { exact: true }).setInputFiles(join(photos, 'pie.webp'));
    await page.getByRole('button', { name: 'Agregar a galería', exact: true }).click();
    await expect(page.getByText('Galería (1/8)')).toBeVisible();
  }

  const dashboard = page.getByRole('link', { name: 'Dashboard', exact: true });
  const totals = page.getByRole('region', { name: 'Resumen de la colección' });
  await dashboard.click();
  await expect(totals.getByText('14', { exact: true })).toBeVisible();
  await expect(page.locator('[data-slot="chart"] svg.recharts-surface')).toHaveCount(2);
  await expect(page.locator('.recharts-pie-sector')).toHaveCount(3);
  await expect(page.locator('.recharts-bar-rectangle')).toHaveCount(4);
  await capture('dashboard');
  await page.getByRole('link', { name: 'MS-06F Zaku II', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'MS-06F Zaku II', exact: true })).toBeVisible();
  await dashboard.click();
  await page.getByRole('link', { name: 'Ver mi colección' }).click();
  await expect(page.getByText('Página 1 de 2')).toBeVisible();
  await expect(page.locator('.gunpla-card')).toHaveCount(12);
  await capture('coleccion');
  await page.getByRole('button', { name: 'Siguiente' }).click();
  await expect(page.locator('.gunpla-card')).toHaveCount(2);

  const filters = page.getByRole('form', { name: 'Explorar colección' });
  await filters.getByLabel('Buscar por nombre').fill('Zaku');
  await filters.getByLabel('Grado').selectOption({ label: 'Real Grade (RG)' });
  await filters.getByLabel('Escala').selectOption({ label: '1/144' });
  await filters.getByLabel('Estado').selectOption('Sin armar');
  await filters.getByRole('button', { name: 'Aplicar filtros' }).click();
  await expect(page.locator('.gunpla-card')).toHaveCount(1);
  await expect(page.getByText('1 modelo encontrado')).toBeVisible();
  await capture('filtros-con-resultados');
  await filters.getByLabel('Buscar por nombre').fill('Sin ningún resultado');
  await filters.getByRole('button', { name: 'Aplicar filtros' }).click();
  await expect(page.getByRole('heading', { name: 'Sin coincidencias' })).toBeVisible();
  await capture('sin-coincidencias');
  await page.getByRole('button', { name: 'Quitar filtros' }).click();
  await expect(page.getByText('14 modelos en tu colección')).toBeVisible();
  await page.getByRole('link', { name: /MS-06F Zaku II/ }).click();
  await expect(page.getByRole('heading', { name: 'MS-06F Zaku II', exact: true })).toBeVisible();
  await capture('detalle');
  await page.getByRole('link', { name: 'Editar Gunpla' }).click();
  await page.getByLabel('Estado', { exact: true }).selectOption('Armado');
  await capture('formulario-editar');
  await page.getByRole('button', { name: 'Guardar Gunpla' }).click();
  await expect(page.getByText('Gunpla actualizado.')).toBeVisible();
  const detail = page.url();
  await dashboard.click();
  await expect(totals.getByText('7', { exact: true })).toBeVisible();
  await page.goto(detail);
  await page.getByRole('button', { name: 'Eliminar Gunpla', exact: true }).click();
  await expect(page.getByRole('heading', { name: '¿Eliminar este Gunpla?' })).toBeVisible();
  await capture('confirmar-eliminacion');
  await page.getByRole('button', { name: 'Confirmar eliminación' }).click();
  await expect(page.getByText('Gunpla eliminado.')).toBeVisible();
  await expect(page.getByText('13 modelos en tu colección')).toBeVisible();
  await capture('resultado-eliminacion');
  await dashboard.click();
  await expect(totals.getByText('13', { exact: true })).toBeVisible();

  await page.route('**/api/dashboard', (route) => route.fulfill({
    status: 503, json: { message: 'Servicio temporalmente no disponible.' },
  }));
  await page.reload();
  await expect(page.getByRole('alert')).toHaveText('Servicio temporalmente no disponible.');
  await page.unroute('**/api/dashboard');
  await page.getByRole('button', { name: 'Reintentar' }).click();
  await expect(totals.getByText('13', { exact: true })).toBeVisible();
  expect(errors).toEqual([]);

  if (captureDir) {
    await mkdir(captureDir, { recursive: true });
    await writeFile(join(captureDir, 'COMPROBACION.json'), JSON.stringify({
      application: 'gpb-dev/guia-04',
      theme: 'dark',
      data: 'Ficticios. Interfaz React y API Express de la etapa con adaptadores de memoria.',
      photos: process.env.GPB_GUNPLA_PHOTOS ? 'Caja y pieza del kit RG MS-06F Zaku II, fotos de Gravis, CC BY-SA 4.0.' : undefined,
      captures,
    }, null, 2) + '\n');
  }
});
