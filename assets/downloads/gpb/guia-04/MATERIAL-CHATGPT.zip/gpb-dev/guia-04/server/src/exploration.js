export const PAGE_SIZE = 12;
export const RECENT_LIMIT = 5;

export function namePattern(query) {
  return query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export function pageResult(items, total, page) {
  return { items, total, page, pageSize: PAGE_SIZE, pages: Math.max(1, Math.ceil(total / PAGE_SIZE)) };
}

export function summarize(states, grades, recent) {
  const byState = { 'Sin armar': 0, 'En progreso': 0, Armado: 0 };
  for (const { _id, count } of states) byState[_id] = count;
  return {
    total: states.reduce((total, row) => total + row.count, 0),
    byState,
    byGrade: grades,
    recent: recent.map(({ _id, name, state, createdAt }) => ({ id: String(_id), name, state, createdAt })),
  };
}
