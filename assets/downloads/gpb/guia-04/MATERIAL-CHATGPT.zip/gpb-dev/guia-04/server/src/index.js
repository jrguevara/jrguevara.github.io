import mongoose from 'mongoose';
import MongoStore from 'connect-mongo';
import { readConfig } from './config.js';
import { users, User } from './users.js';
import { catalogs, Grade, Scale } from './catalogs.js';
import { gunpla, Gunpla } from './gunpla.js';
import { mediaRepository } from './media-repository.js';
import { mediaService } from './media-service.js';
import { cloudinaryProvider } from './cloudinary.js';
import { createApp } from './app.js';

try {
  const config = readConfig();
  await mongoose.connect(config.MONGODB_URI, { serverSelectionTimeoutMS: 10000 });
  await Promise.all([User.init(), Grade.init(), Scale.init(), Gunpla.init()]); // Esperar los índices únicos antes de aceptar registros.
  const store = MongoStore.create({ client: mongoose.connection.getClient(), collectionName: 'sessions', ttl: 7 * 24 * 60 * 60, touchAfter: 0 });
  store.on('error', () => console.error('No se pudo acceder al almacén de sesiones.'));
  const media = mediaService({ repository: mediaRepository, gunpla, provider: cloudinaryProvider(config) });
  let cleaning = false;
  async function clean() {
    if (cleaning) return;
    cleaning = true;
    try { const result = await media.reconcile(); if (result.pending) console.warn('Hay limpiezas de imágenes pendientes; se reintentarán.'); }
    catch { console.warn('No se pudo completar la limpieza de imágenes; se reintentará.'); }
    finally { cleaning = false; }
  }
  const timer = setInterval(clean, 60000); timer.unref();
  void clean();
  const server = createApp({ config, store, users, catalogs, gunpla, media }).listen(config.PORT, config.NODE_ENV === 'production' ? '0.0.0.0' : '127.0.0.1', () => console.log(`API GPB disponible en el puerto ${config.PORT}`));
  for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => {
    clearInterval(timer);
    server.close(async () => { await mongoose.disconnect(); process.exit(0); });
  });
} catch {
  console.error('No se pudo iniciar GPB. Revisa las variables locales y la conexión con Atlas.');
  process.exitCode = 1;
}
