import test from 'node:test';
import assert from 'node:assert/strict';
import sharp from 'sharp';
import { fixture } from './helpers.js';
import { memoryMedia } from './media-helpers.js';
import { youtubeId } from '../src/media-input.js';
const png = await sharp({ create: { width: 64, height: 64, channels: 3, background: '#123456' } }).png().toBuffer();
function form(buffer = png, name = 'modelo.png', type = 'image/png') { const body = new FormData(); body.append('image', new Blob([buffer], { type }), name); return body; }
async function setup(t) {
  const adapters = memoryMedia(), f = await fixture(adapters); t.after(f.close);
  async function account(suffix) { const c = f.client(); await c.call('/auth/csrf'); await c.call('/auth/register', { method: 'POST', body: { username: `imagenes_${suffix}`, email: `${suffix}@example.com`, password: 'Clave de prueba 123!' } }); return c; }
  const a = await account('a'), b = await account('b');
  const { data } = await a.call('/catalogs');
  const input = { name: 'Modelo de imágenes', grade: data.grades[0].id, scale: data.scales[0].id };
  const created = await a.call('/gunpla', { method: 'POST', body: input });
  return { ...f, ...adapters, a, b, input, id: created.data.gunpla.id };
}
test('portada: subida real decodificada, sustitución y eliminación limpian el proveedor', async (t) => {
  const f = await setup(t); const path = `/gunpla/${f.id}/cover`;
  const first = await f.a.call(path, { method: 'POST', body: form() });
  assert.equal(first.status, 201); const old = first.data.gunpla.cover.publicId;
  assert.equal((await sharp(f.files.get(old)).metadata()).format, 'webp');
  const second = await f.a.call(path, { method: 'POST', body: form() });
  assert.equal(second.status, 201); assert.equal(f.files.has(old), false); assert.equal(f.files.size, 1);
  assert.equal((await f.a.call(path, { method: 'DELETE' })).data.gunpla.cover, null); assert.equal(f.files.size, 0);
});
test('sesión, CSRF y propiedad se comprueban antes de procesar archivos o eliminaciones', async (t) => {
  const f = await setup(t);
  for (const kind of ['cover', 'gallery']) {
    const path = `/gunpla/${f.id}/${kind}`;
    assert.equal((await f.b.call(path, { method: 'POST', body: form() })).status, 404);
    assert.equal((await f.a.call(path, { method: 'POST', body: form(), headers: { 'x-csrf-token': '' } })).status, 403);
    assert.equal((await f.a.call(path, { method: 'POST', body: form(), headers: { origin: 'https://ajeno.example' } })).status, 403);
    const guest = f.client(); await guest.call('/auth/csrf');
    assert.equal((await guest.call(path, { method: 'POST', body: form() })).status, 401);
  }
  const uploaded = await f.a.call(`/gunpla/${f.id}/gallery`, { method: 'POST', body: form() });
  const image = uploaded.data.gunpla.gallery[0];
  for (const path of [`/gunpla/${f.id}/cover`, `/gunpla/${f.id}/gallery/${encodeURIComponent(image.publicId)}`]) {
    assert.equal((await f.b.call(path, { method: 'DELETE' })).status, 404);
    assert.equal((await f.a.call(path, { method: 'DELETE', headers: { 'x-csrf-token': '' } })).status, 403);
  }
  assert.equal(f.files.size, 1);
});
test('rechaza formatos falsos, dañados, excesos y campos multipart adicionales', async (t) => {
  const f = await setup(t), path = `/gunpla/${f.id}/cover`;
  for (const body of [form(png,'falso.jpg','image/jpeg'), form(Buffer.from('<svg/>')), form(png.subarray(0,20)), form(png,'falso.gif','image/gif'), form(png,'modelo.png','text/plain')]) assert.equal((await f.a.call(path,{method:'POST',body})).status,400);
  assert.equal((await f.a.call(path,{method:'POST',body:form(Buffer.alloc(5*1024*1024+1))})).status,413);
  const extra=form();extra.append('owner','otro');assert.equal((await f.a.call(path,{method:'POST',body:extra})).status,400);
  const multiple=form();multiple.append('image',new Blob([png],{type:'image/png'}),'otro.png');assert.equal((await f.a.call(path,{method:'POST',body:multiple})).status,400);
  for (const [format,type] of [['jpeg','image/jpeg'],['webp','image/webp']]) {
    const buffer=await sharp(png)[format]().toBuffer();assert.equal((await f.a.call(path,{method:'POST',body:form(buffer,`modelo.${format==='jpeg'?'jpg':format}`,type)})).status,201);
  }
});
test('galería: ocho imágenes, rechazo de novena, eliminación individual y del Gunpla', async (t) => {
  const f=await setup(t),path=`/gunpla/${f.id}/gallery`;
  let result;for(let i=0;i<8;i++){result=await f.a.call(path,{method:'POST',body:form()});assert.equal(result.status,201);}
  assert.equal((await f.a.call(path,{method:'POST',body:form()})).status,409);
  const image=result.data.gunpla.gallery[0];
  assert.equal((await f.a.call(`${path}/${encodeURIComponent(image.publicId)}`,{method:'DELETE'})).status,200);
  await f.a.call(`/gunpla/${f.id}/cover`,{method:'POST',body:form()});
  assert.equal((await f.a.call(`/gunpla/${f.id}`,{method:'DELETE'})).status,204);
  for(let i=0;i<12;i++)await f.media.reconcile();assert.equal(f.files.size,0);assert.equal(f.records.has(f.id),false);
});
test('fallos parciales: conserva portada, registra incertidumbre y reintenta borrados', async(t)=>{
  const f=await setup(t),path=`/gunpla/${f.id}/cover`;
  const first=await f.a.call(path,{method:'POST',body:form()}),original=first.data.gunpla.cover.publicId;
  f.provider.failUpload=true;assert.equal((await f.a.call(path,{method:'POST',body:form()})).status,502);
  assert.equal((await f.a.call(`/gunpla/${f.id}`)).data.gunpla.cover.publicId,original);
  assert.equal(f.records.get(f.id).mediaJobs.length,2);
  f.provider.failUpload=false;f.provider.failDestroy=true;
  const second=await f.a.call(path,{method:'POST',body:form()});assert.equal(second.data.cleanupPending,true);
  f.provider.failDestroy=false;await f.media.reconcile();assert.equal(f.files.has(original),false);
  for(const job of f.records.get(f.id).mediaJobs)job.createdAt=new Date(Date.now()-25*60*60*1000);
  await f.media.reconcile();await f.media.reconcile();assert.equal(f.records.get(f.id).mediaJobs.length,1);assert.equal(f.files.size,1);
  f.provider.failDestroy=true;assert.equal((await f.a.call(`/gunpla/${f.id}`,{method:'DELETE'})).status,204);
  assert.equal((await f.a.call(`/gunpla/${f.id}`)).status,404);assert.equal(f.records.get(f.id).deleted,true);
  f.provider.failDestroy=false;for(let i=0;i<12;i++)await f.media.reconcile();assert.equal(f.records.has(f.id),false);assert.equal(f.files.size,0);
});
test('fallo MongoDB tras subir: el diario previo permite recuperar el archivo',async(t)=>{
  const f=await setup(t);f.repository.failCommit=true;
  assert.equal((await f.a.call(`/gunpla/${f.id}/cover`,{method:'POST',body:form()})).status,500);
  assert.equal(f.records.get(f.id).cover,null);assert.equal(f.files.size,1);
  f.repository.failCommit=false;await f.media.reconcile();assert.equal(f.files.size,0);
  assert.equal(f.records.get(f.id).mediaJobs.length,1);
});
test('cargas simultáneas: bloqueo por registro y límite de dos buffers por proceso',async(t)=>{
  const f=await setup(t);let release;f.provider.wait=new Promise(resolve=>{release=resolve;});
  const p1=f.a.call(`/gunpla/${f.id}/cover`,{method:'POST',body:form()});
  while(!f.records.get(f.id).mediaLock) await new Promise(resolve=>setTimeout(resolve,5));
  assert.equal((await f.a.call(`/gunpla/${f.id}/cover`,{method:'POST',body:form()})).status,409);
  const other=(await f.a.call('/gunpla',{method:'POST',body:f.input})).data.gunpla.id;
  const p2=f.a.call(`/gunpla/${other}/cover`,{method:'POST',body:form()});
  while(!f.records.get(other).mediaLock) await new Promise(resolve=>setTimeout(resolve,5));
  assert.equal((await f.a.call(`/gunpla/${other}/gallery`,{method:'POST',body:form()})).status,429);
  release();assert.equal((await p1).status,201);assert.equal((await p2).status,201);
});
test('etiquetas normalizadas y YouTube validado sin HTML ni dominios ajenos',async(t)=>{
  const f=await setup(t);
  const result=await f.a.call(`/gunpla/${f.id}`,{method:'PUT',body:{...f.input,tags:[' Pintado ','pintado','Barnizado'],youtubeUrl:'https://youtu.be/dQw4w9WgXcQ'}});
  assert.deepEqual(result.data.gunpla.tags,['pintado','Barnizado']);assert.equal(result.data.gunpla.youtubeId,'dQw4w9WgXcQ');
  for(const fields of [{tags:[' ']},{tags:['x'.repeat(31)]},{tags:Array(21).fill('x')},{youtubeUrl:'<iframe/>'},{youtubeUrl:'https://youtube.com.evil.test/watch?v=dQw4w9WgXcQ'},{youtubeUrl:'http://youtu.be/dQw4w9WgXcQ'},{youtubeUrl:'https://youtu.be/malo'}]) assert.equal((await f.a.call('/gunpla',{method:'POST',body:{...f.input,...fields}})).status,400);
  assert.equal(youtubeId('https://www.youtube.com/shorts/dQw4w9WgXcQ'),'dQw4w9WgXcQ');
});
test('bloqueo vencido: una subida tardía no reemplaza la portada nueva ni pierde su diario', async (t) => {
  const f = await setup(t); let release;
  f.provider.wait = new Promise(resolve => { release = resolve; });
  const path = `/gunpla/${f.id}/cover`;
  const stale = f.a.call(path, { method: 'POST', body: form() });
  while (!f.records.get(f.id).mediaJobs.length) await new Promise(resolve => setTimeout(resolve, 5));
  f.records.get(f.id).mediaLock.until = Date.now() - 1;
  f.provider.wait = null;
  const current = await f.a.call(path, { method: 'POST', body: form() });
  assert.equal(current.status, 201);
  const currentId = current.data.gunpla.cover.publicId;
  release();
  assert.equal((await stale).status, 409);
  assert.equal((await f.a.call(`/gunpla/${f.id}`)).data.gunpla.cover.publicId, currentId);
  assert.equal(f.files.size, 2);
  await f.media.reconcile();
  assert.equal(f.files.size, 1);
  assert.equal(f.files.has(currentId), true);
  assert.equal(f.records.get(f.id).mediaJobs.length, 2);
});
