import { Gunpla } from './gunpla.js';

// El bloqueo y el diario viven en el mismo documento: no requieren transacciones.
export const mediaRepository = {
  async acquire(owner, id, token, now, lease) {
    return Gunpla.findOneAndUpdate({ _id: id, ...(owner ? { owner, deleted: { $ne: true } } : {}), $or: [{ 'mediaLock.until': { $exists: false } }, { 'mediaLock.until': { $lte: new Date(now) } }] }, { $set: { mediaLock: { token, until: new Date(now + lease) } } }, { returnDocument: 'after' }).lean();
  },
  async exists(owner, id) { return Boolean(await Gunpla.exists({ _id: id, owner, deleted: { $ne: true } })); },
  async change(id, token, update) {
    const result = await Gunpla.updateOne({ _id: id, 'mediaLock.token': token, 'mediaLock.until': { $gt: new Date() } }, update);
    if (!result.matchedCount) throw Object.assign(new Error('La operación perdió su bloqueo. Recarga el detalle.'), { status: 409, expose: true });
  },
  async release(id, token) { await Gunpla.updateOne({ _id: id, 'mediaLock.token': token }, { $unset: { mediaLock: 1 } }); },
  async purge(id, token) { await Gunpla.deleteOne({ _id: id, 'mediaLock.token': token, deleted: true, mediaJobs: { $size: 0 } }); },
  async candidates(ids) { return Gunpla.find({ ...(ids ? { _id: { $in: ids } } : {}), $expr: { $gt: [{ $size: { $setDifference: [{ $ifNull: ['$mediaJobs.publicId', []] }, { $cond: ['$deleted', [], { $concatArrays: [[{ $ifNull: ['$cover.publicId', ''] }], { $ifNull: ['$gallery.publicId', []] }] }] }] } }, 0] } }).select('_id').limit(100).lean(); },
};
