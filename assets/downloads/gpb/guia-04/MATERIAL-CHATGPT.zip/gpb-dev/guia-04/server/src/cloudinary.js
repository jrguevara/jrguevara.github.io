import { v2 as cloudinary } from 'cloudinary';
import { failure } from './media-input.js';

export function cloudinaryProvider(config) {
  // Las credenciales sólo entran al SDK del servidor.
  cloudinary.config({ cloud_name: config.CLOUDINARY_CLOUD_NAME, api_key: config.CLOUDINARY_API_KEY, api_secret: config.CLOUDINARY_API_SECRET, secure: true });
  const ready = () => {
    if (!config.CLOUDINARY_CLOUD_NAME || !config.CLOUDINARY_API_KEY || !config.CLOUDINARY_API_SECRET) throw failure(503, 'Las imágenes todavía no están configuradas en el servidor.');
  };
  return {
    configured: Boolean(config.CLOUDINARY_CLOUD_NAME && config.CLOUDINARY_API_KEY && config.CLOUDINARY_API_SECRET),
    async upload(buffer, publicId) {
      ready();
      return new Promise((resolve, reject) => {
        const stream = cloudinary.uploader.upload_stream({ public_id: publicId, resource_type: 'image', overwrite: false, timeout: 30000 }, (error, result) => {
          if (error) return reject(failure(502, 'No se pudo subir la imagen. Intenta de nuevo.'));
          resolve({ publicId, url: result.secure_url });
        });
        stream.on('error', () => reject(failure(502, 'No se pudo subir la imagen. Intenta de nuevo.')));
        stream.end(buffer);
      });
    },
    async destroy(publicId) {
      ready();
      const result = await cloudinary.uploader.destroy(publicId, { resource_type: 'image', invalidate: true, timeout: 10000 });
      if (!['ok', 'not found'].includes(result.result)) throw failure(502, 'La limpieza de imágenes sigue pendiente.');
    },
  };
}
