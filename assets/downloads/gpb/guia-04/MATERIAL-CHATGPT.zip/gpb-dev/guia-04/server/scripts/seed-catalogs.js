import mongoose from 'mongoose';
import { readConfig } from '../src/config.js';
import { seedCatalogs } from '../src/catalogs.js';
try {
  await mongoose.connect(readConfig().MONGODB_URI, { serverSelectionTimeoutMS: 10000 });
  await seedCatalogs();
  console.log('Catálogos cargados: 12 grados y 5 escalas; repetir no duplica las opciones iniciales.');
} catch {
  console.error('No se pudieron cargar los catálogos. Revisa la configuración y el acceso a Atlas.');
  process.exitCode = 1;
} finally { await mongoose.disconnect(); }
