import { Router } from 'express';
import multer from 'multer';
import { MAX_BYTES, failure, validateImage } from './media-input.js';
const idPattern = /^[a-fA-F0-9]{24}$/;
export function mediaRoutes({ media }) {
  const router = Router();
  const receive = multer({ storage: multer.memoryStorage(), limits: { fileSize: MAX_BYTES, files: 1, fields: 0, parts: 1, fieldNameSize: 20 } }).single('image');
  let active = 0;
  // Rechazar antes de reservar buffers. Máximo dos cargas por proceso, un archivo por solicitud.
  async function upload(req, res, kind) {
    if (active >= 2) throw failure(429, 'Hay demasiadas cargas simultáneas. Intenta de nuevo.');
    active++;
    try {
      await new Promise((resolve, reject) => receive(req, res, (error) => error ? reject(error) : resolve()));
      const buffer = await validateImage(req.file);
      res.status(201).json(await media.upload(String(req.user._id), req.params.id, kind, buffer));
    } finally { active--; }
  }
  async function owned(req, _res, next) {
    if (!idPattern.test(req.params.id)) throw failure(400, 'Identificador inválido.');
    if (!await media.owned(String(req.user._id), req.params.id)) throw failure(404, 'Gunpla no encontrado.');
    next();
  }
  for (const kind of ['cover', 'gallery']) {
    router.post(`/gunpla/:id/${kind}`, owned, (req, res) => upload(req, res, kind));
  }
  router.delete('/gunpla/:id/cover', owned, async (req, res) => res.json(await media.erase(String(req.user._id), req.params.id, 'cover')));
  router.delete('/gunpla/:id/gallery/:publicId', owned, async (req, res) => res.json(await media.erase(String(req.user._id), req.params.id, 'gallery', req.params.publicId)));
  router.use((error, _req, _res, next) => {
    if (error instanceof multer.MulterError) return next(failure(error.code === 'LIMIT_FILE_SIZE' ? 413 : 400, 'Envía una sola imagen JPG, PNG o WebP, sin campos adicionales y de hasta 5 MB.'));
    next(error);
  });
  return router;
}
