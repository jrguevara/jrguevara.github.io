import mongoose from 'mongoose';
import { namePattern, pageResult, PAGE_SIZE, RECENT_LIMIT, summarize } from './exploration.js';

export const STATES = ['Sin armar', 'En progreso', 'Armado'];
const image = new mongoose.Schema({ publicId: String, url: String }, { _id: false });
const job = new mongoose.Schema({ publicId: String, createdAt: { type: Date, default: Date.now }, settled: { type: Boolean, default: false } }, { _id: false });
const schema = new mongoose.Schema({
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, immutable: true },
  name: { type: String, required: true, trim: true, maxlength: 120 },
  grade: { type: mongoose.Schema.Types.ObjectId, ref: 'Grade', required: true },
  scale: { type: mongoose.Schema.Types.ObjectId, ref: 'Scale', required: true },
  description: { type: String, trim: true, maxlength: 1000, default: '' },
  notes: { type: String, trim: true, maxlength: 1000, default: '' },
  tags: { type: [String], default: [] },
  youtubeId: { type: String, default: '' },
  cover: { type: image, default: null },
  gallery: { type: [image], default: [] },
  mediaJobs: { type: [job], default: [] },
  mediaLock: { token: String, until: Date },
  deleted: { type: Boolean, default: false },
  state: { type: String, enum: STATES, required: true, default: 'Sin armar' },
}, { timestamps: true });
schema.index({ owner: 1, createdAt: -1, _id: -1 });
export const Gunpla = mongoose.model('Gunpla', schema);
const populate = (query) => query.populate('grade', 'name').populate('scale', 'name').lean();
export function publicGunpla(doc) {
  const option = (value) => value ? { id: String(value._id), name: value.name } : null;
  return { id: String(doc._id), name: doc.name, grade: option(doc.grade), scale: option(doc.scale),
    cover: doc.cover || null, gallery: doc.gallery || [], tags: doc.tags || [], youtubeId: doc.youtubeId || '',
    description: doc.description, notes: doc.notes, state: doc.state, createdAt: doc.createdAt, updatedAt: doc.updatedAt };
}
export const gunpla = {
  async list(owner, { page, q, grade, scale, state }) {
    const filter = { owner, deleted: { $ne: true } };
    if (q) filter.name = { $regex: namePattern(q), $options: 'i' };
    if (grade) filter.grade = grade;
    if (scale) filter.scale = scale;
    if (state) filter.state = state;
    const [docs, total] = await Promise.all([
      populate(Gunpla.find(filter).sort({ createdAt: -1, _id: -1 }).skip((page - 1) * PAGE_SIZE).limit(PAGE_SIZE)),
      Gunpla.countDocuments(filter),
    ]);
    return pageResult(docs.map(publicGunpla), total, page);
  },
  async stats(owner) {
    const [result] = await Gunpla.aggregate([
      { $match: { owner: new mongoose.Types.ObjectId(owner), deleted: { $ne: true } } },
      { $sort: { createdAt: -1, _id: -1 } },
      { $facet: {
        states: [{ $group: { _id: '$state', count: { $sum: 1 } } }],
        grades: [
          { $group: { _id: '$grade', count: { $sum: 1 } } },
          { $lookup: { from: 'grades', localField: '_id', foreignField: '_id', as: 'grade' } },
          { $project: { _id: 0, name: { $ifNull: [{ $first: '$grade.name' }, 'Grado no disponible'] }, count: 1 } },
          { $group: { _id: '$name', count: { $sum: '$count' } } },
          { $sort: { _id: 1 } },
          { $project: { _id: 0, name: '$_id', count: 1 } },
        ],
        recent: [{ $limit: RECENT_LIMIT }, { $project: { name: 1, state: 1, createdAt: 1 } }],
      } },
    ]);
    return summarize(result.states, result.grades, result.recent);
  },
  async get(owner, id) {
    const doc = await populate(Gunpla.findOne({ _id: id, owner, deleted: { $ne: true } }));
    return doc ? publicGunpla(doc) : null;
  },
  async create(owner, input) {
    const doc = await Gunpla.create({ ...input, owner });
    return this.get(owner, doc._id);
  },
  async update(owner, id, input) {
    const doc = await populate(Gunpla.findOneAndUpdate({ _id: id, owner, deleted: { $ne: true } }, { $set: input }, { returnDocument: 'after', runValidators: true }));
    return doc ? publicGunpla(doc) : null;
  },
  async remove(owner, id) { return Boolean(await Gunpla.findOneAndDelete({ _id: id, owner, deleted: { $ne: true } })); },
};
