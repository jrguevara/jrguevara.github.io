import { randomUUID } from 'node:crypto';
import { failure } from './media-input.js';
const LEASE = 5 * 60 * 1000;
const UNCERTAIN = 24 * 60 * 60 * 1000;
export function mediaService({ repository, gunpla, provider, now = Date.now }) {
  async function locked(owner, id, action) {
    const token = randomUUID();
    const doc = await repository.acquire(owner, id, token, now(), LEASE);
    if (!doc) {
      if (owner && !await repository.exists(owner, id)) throw failure(404, 'Gunpla no encontrado.');
      throw failure(409, 'Hay otra operación de imágenes en curso. Intenta de nuevo.');
    }
    doc.gallery ||= []; doc.mediaJobs ||= [];
    const change = (update) => repository.change(id, token, update);
    try { return await action(doc, change, token); }
    finally { await repository.release(id, token); }
  }
  async function cleanup(doc, change, token) {
    const attached = new Set(doc.deleted ? [] : [doc.cover?.publicId, ...(doc.gallery || []).map((image) => image.publicId)]);
    let pending = false, attempted = false;
    for (const job of doc.mediaJobs || []) {
      if (attached.has(job.publicId)) continue;
      if (attempted) { pending = true; continue; }
      attempted = true;
      try {
        await provider.destroy(job.publicId);
        // Si el proceso cayó o hubo un timeout, repetir durante 24 h por posibles respuestas tardías.
        if (job.settled || now() - new Date(job.createdAt).getTime() >= UNCERTAIN) {
          await change({ $pull: { mediaJobs: { publicId: job.publicId } } });
        } else pending = true;
      } catch { pending = true; }
    }
    if (doc.deleted && !pending) await repository.purge(String(doc._id), token);
    return pending;
  }
  return {
    async owned(owner, id) { return gunpla.get(owner, id); },
    async upload(owner, id, kind, buffer) {
      if (provider.configured === false) throw failure(503, 'Las imágenes todavía no están configuradas en el servidor.');
      return locked(owner, id, async (doc, change, token) => {
        if (kind === 'gallery' && doc.gallery.length >= 8) throw failure(409, 'La galería admite hasta ocho imágenes.');
        if (doc.mediaJobs.length >= 32) throw failure(503, 'Hay limpiezas pendientes. Intenta de nuevo cuando se recupere el servicio.');
        const publicId = `gpb/${id}/${randomUUID()}`;
        const job = { publicId, createdAt: new Date(now()), settled: false };
        // Registrar antes de llamar a Cloudinary: también cubre caídas del proceso.
        await change({ $push: { mediaJobs: job } });
        doc.mediaJobs.push(job);
        let image;
        try { image = await provider.upload(buffer, publicId); }
        catch { throw failure(502, 'No se pudo subir la imagen. La portada anterior se conserva; la limpieza se reintentará.'); }
        const images = kind === 'cover' ? { cover: image } : { gallery: [...doc.gallery, image] };
        job.settled = true;
        await change({ $set: { ...images, mediaJobs: doc.mediaJobs } });
        Object.assign(doc, images);
        const cleanupPending = await cleanup(doc, change, token);
        return { gunpla: await gunpla.get(owner, id), cleanupPending };
      });
    },
    async erase(owner, id, kind, publicId) {
      return locked(owner, id, async (doc, change, token) => {
        const images = kind === 'cover' ? { cover: null } : { gallery: doc.gallery.filter((image) => image.publicId !== publicId) };
        if (kind === 'gallery' && images.gallery.length === doc.gallery.length) throw failure(404, 'Imagen no encontrada.');
        await change({ $set: images }); Object.assign(doc, images);
        const cleanupPending = await cleanup(doc, change, token);
        return { gunpla: await gunpla.get(owner, id), cleanupPending };
      });
    },
    async remove(owner, id) {
      if (!await gunpla.get(owner, id)) return false;
      return locked(owner, id, async (doc, change, token) => {
        await change({ $set: { deleted: true } }); doc.deleted = true;
        await cleanup(doc, change, token);
        return true;
      });
    },
    async reconcile() {
      let pending = 0;
      for (const doc of await repository.candidates()) {
        try { if (await locked(null, String(doc._id), (item, change, token) => cleanup(item, change, token))) pending++; }
        catch { pending++; }
      }
      return { pending };
    },
  };
}
