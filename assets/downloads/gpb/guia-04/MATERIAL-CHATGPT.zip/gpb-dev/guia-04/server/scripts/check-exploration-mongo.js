import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import mongoose from 'mongoose';
import { catalogs, seedCatalogs } from '../src/catalogs.js';
import { Gunpla, gunpla } from '../src/gunpla.js';

const port = Number(process.argv[2]);
assert.ok(Number.isInteger(port) && port > 0 && port <= 65535, 'Indica el puerto de un MongoDB local de prueba.');
const dbName = 'gpb_exploration_' + randomUUID().replaceAll('-', '');
await mongoose.connect(`mongodb://127.0.0.1:${port}`, { dbName, serverSelectionTimeoutMS: 5000 });

try {
  const { version } = await mongoose.connection.db.admin().serverInfo();
  await seedCatalogs();
  const { grades, scales } = await catalogs.list();
  const owner = new mongoose.Types.ObjectId();
  const other = new mongoose.Types.ObjectId();
  const input = { owner, grade: grades[1].id, scale: scales[0].id, state: 'Armado' };
  assert.equal((await gunpla.stats(String(owner))).total, 0);
  const [first] = await Gunpla.insertMany(Array.from({ length: 13 }, (_, index) => ({
    ...input, name: 'Gundam [RX] ' + index, createdAt: new Date(1700000000000 + index),
  })));
  await Gunpla.create([
    { ...input, name: 'Gundam [RX] otro usuario', owner: other },
    { ...input, name: 'Gundam [RX] eliminado', deleted: true },
    { ...input, name: 'Gundam [RX] grado\u2028especial', grade: grades[2].id },
    { ...input, name: 'Gundam [RX] otra escala', scale: scales[1].id },
    { ...input, name: 'Gundam [RX] otro estado', state: 'En progreso' },
  ]);
  // Simula un registro creado antes de existir la marca de eliminación lógica.
  await Gunpla.collection.updateOne({ _id: first._id }, { $unset: { deleted: 1 } });
  const id = String(owner);
  const query = { q: '[rx]', grade: input.grade, scale: input.scale, state: input.state };
  const firstPage = await gunpla.list(id, { ...query, page: 1 });
  const secondPage = await gunpla.list(id, { ...query, page: 2 });
  assert.equal(firstPage.total, 13);
  assert.equal(firstPage.items.length, 12);
  assert.deepEqual(secondPage.items.map(({ id }) => id), [String(first._id)]);

  assert.equal((await gunpla.list(id, { q: 'grado\u2028especial', page: 1 })).total, 1);

  const before = await gunpla.stats(id);
  assert.equal(before.total, 16);
  assert.deepEqual(before.byState, { 'Sin armar': 0, 'En progreso': 1, Armado: 15 });
  assert.deepEqual(before.byGrade, [
    { name: 'High Grade (HG)', count: 15 },
    { name: 'Real Grade (RG)', count: 1 },
  ]);
  assert.equal(before.recent.length, 5);
  assert.ok(before.recent.every(({ name }) => !name.includes('eliminado') && !name.includes('usuario')));
  assert.equal((await gunpla.stats(String(other))).total, 1);
  await gunpla.update(id, first._id, { state: 'Sin armar', grade: grades[2].id });
  assert.equal((await gunpla.list(id, { ...query, page: 1 })).total, 12);
  const updated = await gunpla.stats(id);
  assert.equal(updated.byState['Sin armar'], 1);
  assert.equal(updated.byGrade[1].count, 2);
  assert.deepEqual(updated.recent, before.recent);
  assert.equal(await gunpla.remove(id, first._id), true);
  assert.equal((await gunpla.stats(id)).total, 15);
  console.log(`MongoDB ${version}: filtros, páginas, propiedad, recuentos, recientes y cambios comprobados.`);
} finally {
  try {
    await mongoose.connection.dropDatabase();
  } finally {
    await mongoose.disconnect();
  }
}
