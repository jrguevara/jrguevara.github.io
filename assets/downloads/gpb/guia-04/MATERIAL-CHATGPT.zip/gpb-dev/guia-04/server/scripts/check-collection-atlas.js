// Comprueba la entrada real de la API y React con Atlas; sólo elimina la cuenta y sesiones creadas aquí.
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { createServer } from 'node:net';
import { mkdtemp, rm } from 'node:fs/promises';
import { randomBytes } from 'node:crypto';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import mongoose from 'mongoose';
import assert from 'node:assert/strict';
import { seedCatalogs, catalogs, Grade, Scale } from '../src/catalogs.js';
import { Gunpla } from '../src/gunpla.js';
import { chromium } from '@playwright/test';
import { readConfig } from '../src/config.js';
import { User } from '../src/users.js';

const root = fileURLToPath(new URL('../../', import.meta.url));
const suffix = randomBytes(6).toString('hex');
const account = { username: `web_${suffix}`, email: `${suffix}@example.com`, password: randomBytes(24).toString('hex') };
const sessionIds = new Set();
let apiProcess, clientProcess, browser, profile, createdId, gunplaId;
const other = { username: `other_${suffix}`, email: `other_${suffix}@example.com`, password: randomBytes(24).toString('hex') };
let stage = 'configuración';
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function freePort(port) {
  const server = createServer();
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(port, '127.0.0.1', resolve); });
  await new Promise((resolve) => server.close(resolve));
}
function start(executable, args, cwd, env = process.env) {
  const child = spawn(executable, args, { cwd, env, detached: true, stdio: 'ignore' });
  child.on('error', () => {});
  return child;
}
async function stop(child) {
  if (!child || child.exitCode !== null || child.signalCode !== null) return;
  const done = once(child, 'exit').catch(() => {});
  try { process.kill(-child.pid, 'SIGTERM'); } catch { return; }
  await Promise.race([done, delay(5000)]);
  if (child.exitCode === null && child.signalCode === null) { try { process.kill(-child.pid, 'SIGKILL'); } catch {} await done; }
}
async function ready(url, child) {
  const deadline = Date.now() + 20000;
  while (Date.now() < deadline) {
    if (child.exitCode !== null || child.signalCode !== null) throw new Error('Proceso detenido');
    try { const response = await fetch(url, { signal: AbortSignal.timeout(1000) }); if (response.ok) return; } catch {}
    await delay(100);
  }
  throw new Error('Sin respuesta');
}
async function trackCookies() {
  if (!browser) return;
  for (const cookie of await browser.cookies('http://localhost:5173/api/auth/me')) {
    if (cookie.name !== 'gpb.sid') continue;
    const value = decodeURIComponent(cookie.value);
    if (value.startsWith('s:')) sessionIds.add(value.slice(2).split('.')[0]);
  }
}
async function heading(page) {
  await page.getByRole('heading', { name: `Hola, ${account.username}.`, exact: true }).waitFor();
  await trackCookies();
}
try {
  process.env.SESSION_SECRET = randomBytes(48).toString('hex');
  const config = readConfig();
  if (config.NODE_ENV !== 'development' || config.PORT !== 3000 || config.WEB_ORIGIN !== 'http://localhost:5173') throw new Error('La prueba requiere configuración local estándar');
  await freePort(3000); await freePort(5173);
  await mongoose.connect(config.MONGODB_URI, { serverSelectionTimeoutMS: 10000 });
  stage = 'carga idempotente de catálogos';
  await seedCatalogs();
  const before = await catalogs.list();
  await seedCatalogs();
  assert.deepEqual(await catalogs.list(), before);
  assert.equal(await Grade.countDocuments(), 12); assert.equal(await Scale.countDocuments(), 5);
  stage = 'arranque de API y cliente';
  const startApi = () => start(process.execPath, ['src/index.js'], join(root, 'server'));
  apiProcess = startApi();
  await ready('http://127.0.0.1:3000/api/health', apiProcess);
  const clientEnv = { ...process.env }; delete clientEnv.MONGODB_URI; delete clientEnv.SESSION_SECRET;
  clientProcess = start(join(root, 'client/node_modules/vite-plus/bin/vp'), ['dev'], join(root, 'client'), clientEnv);
  await ready('http://localhost:5173', clientProcess);
  profile = await mkdtemp(join(tmpdir(), 'gpb-atlas-web-'));
  const options = { headless: true, args: ['--test-third-party-cookie-phaseout'], viewport: { width: 1280, height: 800 } };
  browser = await chromium.launchPersistentContext(profile, options);
  let page = await browser.newPage();
  page.setDefaultTimeout(15000);
  stage = 'registro desde React';
  await page.goto('http://localhost:5173/'); await page.waitForURL('**/login'); await trackCookies();
  await page.getByRole('link', { name: 'Regístrate', exact: true }).click();
  await page.getByLabel('Nombre de usuario').fill(account.username);
  await page.getByLabel('Correo electrónico').fill(account.email);
  await page.getByLabel('Contraseña', { exact: true }).fill(account.password);
  await page.getByRole('button', { name: 'Crear cuenta', exact: true }).click();
  await heading(page);
  const saved = await User.findOne({ email: account.email, username: account.username }).select('+passwordHash');
  if (!saved || !saved.passwordHash.startsWith('$argon2id$')) throw new Error('Cuenta no persistida');
  createdId = saved._id;
  stage = 'crear Gunpla desde React con catálogos reales';
  await page.getByRole('link', { name: 'Mi colección', exact: true }).click();
  await page.getByRole('link', { name: 'Agregar mi primer Gunpla', exact: true }).click();
  await page.getByLabel('Nombre', { exact: true }).fill('RX-78-2 Atlas');
  await page.getByLabel('Grado', { exact: true }).selectOption({ label: 'High Grade (HG)' });
  await page.getByLabel('Escala', { exact: true }).selectOption({ label: '1/144' });
  await page.getByRole('button', { name: 'Guardar Gunpla', exact: true }).click();
  await page.getByRole('heading', { name: 'RX-78-2 Atlas', exact: true }).waitFor();
  const savedGunpla = await Gunpla.findOne({ owner: createdId });
  assert.ok(savedGunpla); gunplaId = String(savedGunpla._id);
  assert.equal(savedGunpla.state, 'Sin armar');
  stage = 'aislamiento real entre dos usuarios';
  let otherCookie = '', otherCsrf = '';
  async function otherCall(path, method = 'GET', body) {
    const response = await fetch('http://127.0.0.1:3000/api' + path, { method, headers: { cookie: otherCookie, origin: config.WEB_ORIGIN, 'content-type': 'application/json', 'x-csrf-token': otherCsrf }, body: body ? JSON.stringify(body) : undefined });
    const set = response.headers.get('set-cookie');
    if (set) {
      otherCookie = set.split(';')[0];
      const value = decodeURIComponent(otherCookie.slice(otherCookie.indexOf('=') + 1));
      if (value.startsWith('s:')) sessionIds.add(value.slice(2).split('.')[0]);
    }
    const data = response.status === 204 ? null : await response.json();
    if (data?.csrfToken) otherCsrf = data.csrfToken;
    return { status: response.status, data };
  }
  await otherCall('/auth/csrf');
  assert.equal((await otherCall('/auth/register', 'POST', other)).status, 201);
  assert.equal((await otherCall('/gunpla')).data.total, 0);
  for (const method of ['GET', 'PUT', 'DELETE']) assert.equal((await otherCall('/gunpla/' + gunplaId, method, method === 'PUT' ? { name: 'Ajeno' } : undefined)).status, 404);
  assert.equal((await otherCall('/auth/logout', 'POST')).status, 204);
  stage = 'reapertura del navegador y reinicio de API';
  await browser.close(); browser = null;
  await stop(apiProcess); apiProcess = startApi();
  await ready('http://127.0.0.1:3000/api/health', apiProcess);
  browser = await chromium.launchPersistentContext(profile, options);
  page = await browser.newPage(); page.setDefaultTimeout(15000);
  await page.goto('http://localhost:5173/'); await heading(page);
  stage = 'persistencia del Gunpla, edición y eliminación';
  await page.goto('http://localhost:5173/coleccion/' + gunplaId);
  await page.getByRole('heading', { name: 'RX-78-2 Atlas', exact: true }).waitFor();
  await page.getByRole('link', { name: 'Editar Gunpla', exact: true }).click();
  await page.getByLabel('Estado', { exact: true }).selectOption('Armado');
  await page.getByRole('button', { name: 'Guardar Gunpla', exact: true }).click();
  await page.getByText('Armado', { exact: true }).waitFor();
  assert.equal((await Gunpla.findById(gunplaId)).state, 'Armado');
  await page.getByRole('button', { name: 'Eliminar Gunpla', exact: true }).click();
  await page.getByRole('button', { name: 'Confirmar eliminación', exact: true }).click();
  await page.getByText('Gunpla eliminado.', { exact: true }).waitFor();
  assert.equal(await Gunpla.findById(gunplaId), null);
  stage = 'navegación y cierre de sesión';
  await page.getByRole('link', { name: 'Mi colección', exact: true }).click();
  await page.getByRole('heading', { name: 'Mi colección', exact: true }).waitFor();
  await page.getByRole('button', { name: 'Cerrar sesión', exact: true }).click();
  await page.waitForURL('**/login'); await page.reload();
  await page.getByRole('button', { name: 'Iniciar sesión', exact: true }).waitFor(); await trackCookies();
  stage = 'rechazo de contraseña incorrecta y nuevo acceso';
  await page.getByLabel('Correo electrónico').fill(account.email);
  await page.getByLabel('Contraseña', { exact: true }).fill('incorrecta');
  await page.getByRole('button', { name: 'Iniciar sesión', exact: true }).click();
  await page.getByRole('alert').filter({ hasText: 'Correo o contraseña incorrectos.' }).waitFor(); await trackCookies();
  await page.getByLabel('Contraseña', { exact: true }).fill(account.password);
  await page.getByRole('button', { name: 'Iniciar sesión', exact: true }).click(); await heading(page);
  await page.getByRole('button', { name: 'Cerrar sesión', exact: true }).click(); await page.waitForURL('**/login');
  console.log('Colección + Atlas comprobados: catálogos idempotentes, CRUD React, aislamiento entre dos usuarios y persistencia tras reinicios; además: registro React, hash persistido, navegador y API reiniciados, navegación, credenciales incorrectas, nuevo acceso y cierre de sesión.');
} catch {
  console.error(`Comprobación web Atlas no completada. Paso: ${stage}. No se muestran datos privados.`);
  process.exitCode = 1;
} finally {
  if (browser) { await trackCookies().catch(() => {}); await browser.close(); }
  await stop(apiProcess); await stop(clientProcess);
  if (mongoose.connection.readyState === 1) {
    try {
      const user = createdId ? { _id: createdId, email: account.email } : { username: account.username, email: account.email };
      if (createdId) await Gunpla.deleteMany({ owner: createdId });
      else { const own = await User.findOne(user); if (own) await Gunpla.deleteMany({ owner: own._id }); }
      await User.deleteOne(user);
      await User.deleteOne({ username: other.username, email: other.email });
      if (sessionIds.size) await mongoose.connection.collection('sessions').deleteMany({ _id: { $in: [...sessionIds] } });
      console.log('Cuenta y sesiones exclusivas de prueba eliminadas; procesos locales detenidos.');
    } catch { console.error('Pendiente limpiar los registros exclusivos de esta prueba.'); process.exitCode = 1; }
    await mongoose.disconnect();
  }
  if (profile) await rm(profile, { recursive: true, force: true });
}
