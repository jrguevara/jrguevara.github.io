import mongoose from 'mongoose';

export const GRADE_NAMES = ['Entry Grade (EG)', 'High Grade (HG)', 'Real Grade (RG)', 'Master Grade (MG)', 'Perfect Grade (PG)', 'Super Deformed (SD)', 'Full Mechanics (FM)', 'Reborn-One Hundred (RE/100)', 'Master Grade Extreme (MGEX)', 'Master Grade Super Deformed (MGSD)', 'Mega Size', 'Sin Grado'];
export const SCALE_NAMES = ['1/144', '1/100', '1/60', '1/48', 'Sin Escala'];
const catalogSchema = () => new mongoose.Schema({
  name: { type: String, required: true, unique: true },
  order: { type: Number, required: true },
}, { versionKey: false });
export const Grade = mongoose.model('Grade', catalogSchema());
export const Scale = mongoose.model('Scale', catalogSchema());
export async function seedCatalogs() {
  await Promise.all([Grade.init(), Scale.init()]);
  for (const [Model, names] of [[Grade, GRADE_NAMES], [Scale, SCALE_NAMES]]) {
    await Model.bulkWrite(names.map((name, order) => ({ updateOne: {
      filter: { name }, update: { $set: { order }, $setOnInsert: { name } }, upsert: true,
    } })));
  }
}
const option = (doc) => ({ id: String(doc._id), name: doc.name });
export const catalogs = {
  async list() {
    const [grades, scales] = await Promise.all([
      Grade.find().sort({ order: 1, _id: 1 }).lean(),
      Scale.find().sort({ order: 1, _id: 1 }).lean(),
    ]);
    return { grades: grades.map(option), scales: scales.map(option) };
  },
  async valid(grade, scale) {
    const found = await Promise.all([Grade.exists({ _id: grade }), Scale.exists({ _id: scale })]);
    return found.every(Boolean);
  },
};
