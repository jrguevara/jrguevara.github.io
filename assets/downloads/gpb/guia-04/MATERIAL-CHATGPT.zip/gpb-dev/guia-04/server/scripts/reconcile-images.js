import mongoose from 'mongoose';
import { readConfig } from '../src/config.js';
import { gunpla } from '../src/gunpla.js';
import { mediaRepository } from '../src/media-repository.js';
import { mediaService } from '../src/media-service.js';
import { cloudinaryProvider } from '../src/cloudinary.js';
try {
  const config = readConfig();
  await mongoose.connect(config.MONGODB_URI, { serverSelectionTimeoutMS: 10000 });
  const media = mediaService({ repository: mediaRepository, gunpla, provider: cloudinaryProvider(config) });
  const { pending } = await media.reconcile();
  console.log(`Pasada de limpieza terminada. Registros con tareas pendientes en esta pasada: ${pending}.`);
  if (pending) process.exitCode = 2;
} catch { console.error('No se pudo completar la limpieza. Revisa la configuración y la conectividad.'); process.exitCode = 1; }
finally { await mongoose.disconnect(); }
