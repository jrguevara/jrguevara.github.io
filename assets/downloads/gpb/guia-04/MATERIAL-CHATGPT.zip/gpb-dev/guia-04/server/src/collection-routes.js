import { Router } from 'express';
import { z, ZodError } from 'zod';
import { youtubeId } from './media-input.js';
import { STATES } from './gunpla.js';

const id = z.string().regex(/^[a-fA-F0-9]{24}$/, 'Identificador inválido.');
const input = z.strictObject({
  name: z.string().trim().min(1).max(120), grade: id, scale: id,
  description: z.string().trim().max(1000).default(''),
  notes: z.string().trim().max(1000).default(''),
  tags: z.array(z.string().trim().min(1).max(30)).max(20).default([]).transform((tags) => [...new Map(tags.map((tag) => [tag.toLocaleLowerCase('es'), tag])).values()]),
  youtubeUrl: z.string().trim().max(300).default('').refine((value) => youtubeId(value) !== null, 'Usa un enlace HTTPS válido de YouTube.'),
  state: z.enum(STATES).default('Sin armar'),
});
const collectionQuery = z.strictObject({
  page: z.string().regex(/^[1-9]\d{0,5}$/).transform(Number).optional().default(1),
  q: z.string().trim().max(120).optional(),
  grade: id.transform((value) => value.toLowerCase()).optional(),
  scale: id.transform((value) => value.toLowerCase()).optional(),
  state: z.enum(STATES).optional(),
});
const missing = (res) => res.status(404).json({ message: 'Gunpla no encontrado.' });
export function collectionRoutes({ catalogs, gunpla, media }) {
  const router = Router();
  router.get('/catalogs', async (_req, res) => res.json(await catalogs.list()));
  router.get('/gunpla', async (req, res) => {
    const query = collectionQuery.safeParse(req.query);
    if (!query.success) return res.status(400).json({ message: 'Revisa la búsqueda, los filtros y el número de página.' });
    res.json(await gunpla.list(String(req.user._id), query.data));
  });
  router.get('/dashboard', async (req, res) => res.json(await gunpla.stats(String(req.user._id))));
  router.get('/gunpla/:id', async (req, res) => {
    const record = await gunpla.get(String(req.user._id), id.parse(req.params.id));
    return record ? res.json({ gunpla: record }) : missing(res);
  });
  async function readInput(body) {
    const data = input.parse(body);
    if (!await catalogs.valid(data.grade, data.scale)) throw new ZodError([{ code: 'custom', path: ['grade'], message: 'Selecciona un grado y una escala existentes.' }]);
    const { youtubeUrl, ...fields } = data;
    return { ...fields, youtubeId: youtubeId(youtubeUrl) };
  }
  router.post('/gunpla', async (req, res) => {
    const record = await gunpla.create(String(req.user._id), await readInput(req.body));
    res.status(201).json({ gunpla: record });
  });
  router.put('/gunpla/:id', async (req, res) => {
    const recordId = id.parse(req.params.id);
    const owner = String(req.user._id);
    if (!await gunpla.get(owner, recordId)) return missing(res);
    const record = await gunpla.update(owner, recordId, await readInput(req.body));
    return record ? res.json({ gunpla: record }) : missing(res);
  });
  router.delete('/gunpla/:id', async (req, res) => {
    const removed = await (media ? media.remove.bind(media) : gunpla.remove.bind(gunpla))(String(req.user._id), id.parse(req.params.id));
    return removed ? res.sendStatus(204) : missing(res);
  });
  router.use((error, _req, res, next) => {
    if (error instanceof ZodError) return res.status(400).json({ message: 'Revisa los datos: nombre de 1 a 120 caracteres, grado y escala válidos, estado permitido y textos de hasta 1000 caracteres. Etiquetas: hasta 20 de 1–30 caracteres. Video: enlace HTTPS válido de YouTube. No se admiten campos adicionales ni una página inválida.' });
    next(error);
  });
  return router;
}
