import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import mongoose from 'mongoose';
import MongoStore from 'connect-mongo';
import sharp from 'sharp';
import { readConfig } from '../src/config.js';
import { users, User } from '../src/users.js';
import { catalogs, Grade, Scale, seedCatalogs } from '../src/catalogs.js';
import { gunpla, Gunpla } from '../src/gunpla.js';
import { mediaRepository } from '../src/media-repository.js';
import { mediaService } from '../src/media-service.js';
import { cloudinaryProvider } from '../src/cloudinary.js';
import { createApp } from '../src/app.js';
const suffix = randomBytes(6).toString('hex');
const emails = [`gpb_img_a_${suffix}@example.com`, `gpb_img_b_${suffix}@example.com`];
let server, store, media, provider;
const ids = [];
let clean = true;
try {
  const config = { ...readConfig(), NODE_ENV: 'test', SESSION_SECRET: randomBytes(48).toString('base64url') };
  const simulated = process.argv.includes('--provider-memory');
  if (!simulated && ![config.CLOUDINARY_CLOUD_NAME, config.CLOUDINARY_API_KEY, config.CLOUDINARY_API_SECRET].every(Boolean)) throw new Error('Configuración de imágenes incompleta');
  await mongoose.connect(config.MONGODB_URI, { serverSelectionTimeoutMS: 10000 });
  await Promise.all([User.init(), Grade.init(), Scale.init(), Gunpla.init()]);
  await seedCatalogs();
  provider = simulated ? { async upload(_buffer, publicId) { return { publicId, url: 'https://example.com/prueba.webp' }; }, async destroy() {} } : cloudinaryProvider(config);
  const repository = { ...mediaRepository, async candidates() { return mediaRepository.candidates(ids); } };
  media = mediaService({ repository, gunpla, provider });
  store = MongoStore.create({ client: mongoose.connection.getClient(), collectionName: 'sessions' });
  server = createApp({ config, store, users, catalogs, gunpla, media }).listen(0, '127.0.0.1');
  await new Promise(resolve => server.once('listening', resolve));
  const base = `http://127.0.0.1:${server.address().port}/api`;
  function client() {
    let cookie = '', csrf = '';
    return async (path, { method = 'GET', body, headers = {} } = {}) => {
      const multipart = body instanceof FormData;
      const res = await fetch(base + path, { method, headers: { cookie, origin: config.WEB_ORIGIN, 'x-csrf-token': csrf, ...(body && !multipart ? { 'content-type': 'application/json' } : {}), ...headers }, body: multipart ? body : body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(60000) });
      if (res.headers.get('set-cookie')) cookie = res.headers.get('set-cookie').split(';')[0];
      const data = res.status === 204 ? null : await res.json(); if (data?.csrfToken) csrf = data.csrfToken;
      return { status: res.status, data };
    };
  }
  const a = client(), b = client();
  for (const [index, call] of [a,b].entries()) {
    await call('/auth/csrf');
    assert.equal((await call('/auth/register', { method: 'POST', body: { username: `img_${index}_${suffix}`, email: emails[index], password: randomBytes(24).toString('base64url') } })).status, 201);
  }
  const options = (await a('/catalogs')).data;
  const created = await a('/gunpla', { method: 'POST', body: { name: 'Prueba temporal de imágenes', grade: options.grades[0].id, scale: options.scales[0].id, tags: [' Prueba ', 'prueba'], youtubeUrl: 'https://youtu.be/M7lc1UVf-VE' } });
  assert.equal(created.status,201); const id = created.data.gunpla.id; ids.push(id);
  const image = await sharp({ create: { width: 64, height: 64, channels: 3, background: '#132035' } }).png().toBuffer();
  const form = () => { const body = new FormData(); body.append('image',new Blob([image],{type:'image/png'}),'prueba.png'); return body; };
  for (const kind of ['cover','gallery']) assert.equal((await b(`/gunpla/${id}/${kind}`,{method:'POST',body:form()})).status,404);
  assert.equal((await a(`/gunpla/${id}/cover`,{method:'POST',body:form(),headers:{'x-csrf-token':''}})).status,403);
  const first = await a(`/gunpla/${id}/cover`,{method:'POST',body:form()});assert.equal(first.status,201);
  const old = first.data.gunpla.cover.publicId;
  const second = await a(`/gunpla/${id}/cover`,{method:'POST',body:form()});assert.equal(second.status,201);
  assert.notEqual(second.data.gunpla.cover.publicId,old);
  assert.equal((await Gunpla.findById(id)).mediaJobs.some(job=>job.publicId===old),false);
  const gallery = await a(`/gunpla/${id}/gallery`,{method:'POST',body:form()});assert.equal(gallery.status,201);
  const publicId = gallery.data.gunpla.gallery[0].publicId;
  assert.equal((await b(`/gunpla/${id}/gallery/${encodeURIComponent(publicId)}`,{method:'DELETE'})).status,404);
  assert.equal((await a(`/gunpla/${id}/gallery/${encodeURIComponent(publicId)}`,{method:'DELETE'})).status,200);
  const persistent = await gunpla.get(String((await User.findOne({ email: emails[0] }))._id),id);
  assert.equal(persistent.gallery.length,0);assert.deepEqual(persistent.tags,['prueba']);assert.equal(persistent.youtubeId,'M7lc1UVf-VE');
  assert.equal((await a(`/gunpla/${id}/gallery`,{method:'POST',body:form()})).status,201);
  assert.equal((await a(`/gunpla/${id}`,{method:'DELETE'})).status,204);
  for(let i=0;i<12 && await Gunpla.exists({_id:id});i++) await media.reconcile();
  assert.equal(await Gunpla.exists({_id:id}),null);
  console.log(simulated ? 'Atlas real y proveedor simulado: operaciones, propiedad, CSRF, persistencia y diario aprobados. Cloudinary real no comprobado.' : 'Atlas y Cloudinary: subida, sustitución, galería, etiquetas, video, propiedad, CSRF y limpieza aprobados.');
} catch { console.error('No se completó la comprobación real de imágenes. Revisa configuración, conectividad y permisos.'); process.exitCode = 1; }
finally {
  if (mongoose.connection.readyState === 1) {
    const owners = (await User.find({ email: { $in: emails } }).select('_id')).map(user=>String(user._id));
    for (const doc of await Gunpla.find({ owner: { $in: owners } }).lean()) {
      await Gunpla.updateOne({ _id: doc._id }, { $set: { deleted: true } });
      for (const job of doc.mediaJobs || []) {
        if (!job.settled) clean = false; // Conservar el diario ante posibles respuestas tardías.
        try { await provider.destroy(job.publicId); } catch { clean = false; }
      }
      if (clean) await Gunpla.deleteOne({ _id: doc._id });
    }
    if (clean) {
      await mongoose.connection.collection('sessions').deleteMany({ session: { $regex: suffix } });
      for (const owner of owners) await mongoose.connection.collection('sessions').deleteMany({ session: { $regex: `"userId":"${owner}"` } });
      await User.deleteMany({ email: { $in: emails } });
    } else { console.error('Quedan recursos temporales con seguimiento en MongoDB; reintenta su limpieza.'); process.exitCode = 1; }
  }
  if (server) await new Promise(resolve => server.close(resolve));
  await mongoose.disconnect();
}
