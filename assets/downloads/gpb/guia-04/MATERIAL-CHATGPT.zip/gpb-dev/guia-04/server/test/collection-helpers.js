// Adaptadores exclusivos de pruebas: Atlas usa los modelos reales.
import { GRADE_NAMES, SCALE_NAMES } from '../src/catalogs.js';
import { namePattern, pageResult, PAGE_SIZE, RECENT_LIMIT, summarize } from '../src/exploration.js';
const hex = (value) => value.toString(16).padStart(24, '0');
export function memoryCollection() {
  const grades = GRADE_NAMES.map((name, i) => ({ id: hex(i + 1), name }));
  const scales = SCALE_NAMES.map((name, i) => ({ id: hex(i + 101), name }));
  const records = new Map();
  let sequence = 1000;
  const view = (doc) => {
    const { owner: _owner, ...data } = doc;
    return { ...data, grade: grades.find((g) => g.id === doc.grade), scale: scales.find((s) => s.id === doc.scale) };
  };
  const owned = (owner) => [...records.values()].filter((doc) => doc.owner === owner && !doc.deleted).reverse();
  return {
    records,
    catalogs: { async list() { return { grades, scales }; }, async valid(g, s) { return grades.some((x) => x.id === g) && scales.some((x) => x.id === s); } },
    gunpla: {
      async list(owner, { page, q, grade, scale, state }) {
        const pattern = q && new RegExp(namePattern(q), 'i');
        const all = owned(owner).filter((doc) =>
          (!pattern || pattern.test(doc.name)) && (!grade || doc.grade === grade) &&
          (!scale || doc.scale === scale) && (!state || doc.state === state));
        return pageResult(all.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE).map(view), all.length, page);
      },
      async stats(owner) {
        const all = owned(owner);
        const countBy = (key) => Object.entries(Object.groupBy(all, key));
        const states = countBy((doc) => doc.state).map(([_id, docs]) => ({ _id, count: docs.length }));
        const byGrade = countBy((doc) => view(doc).grade?.name || 'Grado no disponible')
          .map(([name, docs]) => ({ name, count: docs.length }))
          .sort((a, b) => a.name.localeCompare(b.name));
        return summarize(states, byGrade, all.slice(0, RECENT_LIMIT));
      },
      async get(owner, id) { const doc = records.get(id); return doc?.owner === owner && !doc.deleted ? view(doc) : null; },
      async create(owner, data) { const id = hex(sequence++); const doc = { cover: null, gallery: [], mediaJobs: [], ...data, owner, id, _id: id, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }; records.set(id, doc); return view(doc); },
      async update(owner, id, data) { const doc = records.get(id); if (doc?.owner !== owner || doc.deleted) return null; Object.assign(doc, data, { updatedAt: new Date().toISOString() }); return view(doc); },
      async remove(owner, id) { return records.get(id)?.owner === owner && records.delete(id); },
    },
  };
}
