import sharp from 'sharp';
import { extname } from 'node:path';

export const MAX_BYTES = 5 * 1024 * 1024;
export const failure = (status, message) => Object.assign(new Error(message), { status, expose: true });
// No basta la extensión ni el Content-Type enviado por el navegador.
export async function validateImage(file) {
  if (!file) throw failure(400, 'Selecciona una imagen.');
  const expected = { '.jpg': 'jpeg', '.jpeg': 'jpeg', '.png': 'png', '.webp': 'webp' }[extname(file.originalname).toLowerCase()];
  const mime = { jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp' }[expected];
  if (!expected || file.mimetype !== mime) throw failure(400, 'Usa JPG, PNG o WebP con su extensión y tipo correctos.');
  if (file.buffer.length > MAX_BYTES) throw failure(413, 'Cada imagen admite como máximo 5 MB.');
  try {
    const image = sharp(file.buffer, { failOn: 'warning', limitInputPixels: 25000000 });
    const info = await image.metadata();
    if (info.format !== expected || (info.pages || 1) !== 1) throw new Error('Formato incorrecto o animado');
    // Decodificar y reexportar elimina metadatos y contenido adjunto al archivo.
    return await image.rotate().resize({ width: 2400, height: 2400, fit: 'inside', withoutEnlargement: true }).webp({ quality: 85 }).toBuffer();
  } catch { throw failure(400, 'La imagen está dañada, no coincide con su formato, es animada o supera 25 megapíxeles.'); }
}

export function youtubeId(value) {
  if (!value) return '';
  let url;
  try { url = new URL(value); } catch { return null; }
  if (url.protocol !== 'https:' || url.username || url.password || url.port || url.hash) return null;
  const host = url.hostname.toLowerCase();
  let id;
  if (host === 'youtu.be') id = url.pathname.slice(1);
  else if (['youtube.com', 'www.youtube.com', 'm.youtube.com'].includes(host)) {
    if (url.pathname === '/watch') id = url.searchParams.get('v');
    else id = /^\/(?:shorts|embed)\/([\w-]{11})$/.exec(url.pathname)?.[1];
  }
  return /^[\w-]{11}$/.test(id || '') ? id : null;
}
