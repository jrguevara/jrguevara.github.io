import { mediaService } from '../src/media-service.js';
import { memoryCollection } from './collection-helpers.js';
import { failure } from '../src/media-input.js';
export function memoryMedia() {
  const collection = memoryCollection();
  const { records } = collection;
  const files = new Map();
  const provider = {
    failUpload: false, failDestroy: false, wait: null,
    async upload(buffer, publicId) {
      if (this.wait) await this.wait;
      files.set(publicId, buffer);
      if (this.failUpload) throw new Error('timeout después de aceptar');
      return { publicId, url: `https://res.cloudinary.com/demo/image/upload/${publicId}.webp` };
    },
    async destroy(id) { if (this.failDestroy) throw new Error('Proveedor no disponible'); files.delete(id); },
  };
  const repository = {
    failCommit: false,
    async acquire(owner, id, token, now, lease) {
      const doc = records.get(id);
      if (!doc || (owner && (doc.owner !== owner || doc.deleted)) || doc.mediaLock?.until > now) return null;
      doc.mediaLock = { token, until: now + lease };
      return structuredClone(doc);
    },
    async exists(owner, id) { const doc = records.get(id); return doc?.owner === owner && !doc.deleted; },
    async change(id, token, update) {
      const doc = records.get(id);
      if (doc?.mediaLock?.token !== token || doc.mediaLock.until <= Date.now()) throw failure(409, 'Bloqueo perdido');
      if (this.failCommit && update.$set?.mediaJobs) throw new Error('MongoDB no disponible');
      if (update.$set) Object.assign(doc, structuredClone(update.$set));
      if (update.$push) doc.mediaJobs.push(structuredClone(update.$push.mediaJobs));
      if (update.$pull) doc.mediaJobs = doc.mediaJobs.filter((job) => job.publicId !== update.$pull.mediaJobs.publicId);
    },
    async release(id, token) { const doc = records.get(id); if (doc?.mediaLock?.token === token) delete doc.mediaLock; },
    async purge(id, token) { const doc = records.get(id); if (doc?.mediaLock?.token === token && doc.deleted && !doc.mediaJobs.length) records.delete(id); },
    async candidates() { return [...records.values()].filter((doc) => doc.mediaJobs.some((job) => doc.deleted || ![doc.cover?.publicId, ...doc.gallery.map((image) => image.publicId)].includes(job.publicId))); },
  };
  return { ...collection, provider, files, repository, media: mediaService({ repository, gunpla: collection.gunpla, provider }) };
}
