# GPB · Etapa 4: dashboard y exploración

Versión independiente que continúa desde `../guia-03`. Incluye resumen privado, gráficos, recientes, búsqueda por nombre y filtros combinables antes de paginar.

## Ejecutar en desarrollo

Desde esta carpeta, con Node.js 26.13.1 y pnpm 12.18.0:

```sh
pnpm install --frozen-lockfile
cp -n server/.env.example server/.env
```

Configura `server/.env` localmente con los valores propios según la guía 3. Carga los catálogos con `pnpm --filter @gpb/server seed:catalogs`. Ejecuta `pnpm dev:server` y `pnpm dev:client` en terminales separadas y abre [GPB en localhost](http://localhost:5173).

## Comprobar

- `pnpm check` y `pnpm build` revisan y compilan React.
- `pnpm test` comprueba la API Express con adaptadores en memoria.
- `pnpm test:transport` requiere Chromium para Playwright, el binario Electron y puertos 3000 y 5173 libres. Levanta sus propios procesos de prueba.
- `node server/scripts/check-exploration-mongo.js 37104` comprueba el repositorio con una instancia MongoDB **local y desechable** de prueba que escuche en ese puerto. Usa y elimina una base exclusiva con nombre aleatorio.

[Registro y material docente](../../docs/etapas/04/REGISTRO.md)
