// Adaptado de shadcn/ui New York v4 para JavaScript y el tema oscuro de GPB.
import { createContext, useContext } from "react";
import { cn } from "cn";
import { ResponsiveContainer, Tooltip } from "recharts";

const ChartContext = createContext(null);

function ChartContainer({ className, children, config, style, ...props }) {
  const colors = Object.fromEntries(
    Object.entries(config).map(([key, { color }]) => [`--color-${key}`, color]),
  );
  return (
    <ChartContext.Provider value={config}>
      <div
        data-slot="chart"
        className={cn(
          "text-xs [&_.recharts-cartesian-axis-tick_text]:fill-muted-foreground [&_.recharts-cartesian-grid_line]:stroke-border/50",
          className,
        )}
        style={{ ...colors, ...style }}
        {...props}
      >
        <ResponsiveContainer initialDimension={{ width: 240, height: 210 }}>
          {children}
        </ResponsiveContainer>
      </div>
    </ChartContext.Provider>
  );
}

function ChartTooltipContent({ active, payload, label, nameKey, hideLabel }) {
  const config = useContext(ChartContext);
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-md border bg-card px-3 py-2 text-card-foreground shadow-md">
      {!hideLabel && <p>{label}</p>}
      {payload.map((item) => {
        const key = item.payload?.[nameKey] ?? item.dataKey;
        return (
          <p key={key}>
            {config[key]?.label ?? item.name} <strong>{item.value}</strong>
          </p>
        );
      })}
    </div>
  );
}

export { ChartContainer, Tooltip as ChartTooltip, ChartTooltipContent };
