import { useState } from "react";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";

export function MediaPanel({ item, onChange }) {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [confirmation, setConfirmation] = useState(null);
  async function perform(path, body, method = "POST") {
    setBusy(true);
    setError("");
    setMessage("");
    try {
      const result = await api(`/gunpla/${item.id}${path}`, { method, body });
      onChange(result.gunpla);
      setConfirmation(null);
      setMessage(
        result.cleanupPending
          ? "Cambio guardado. La limpieza anterior sigue pendiente y se reintentará."
          : "Imágenes actualizadas.",
      );
    } catch (failure) {
      setError(failure.message);
    } finally {
      setBusy(false);
    }
  }
  function upload(event, kind) {
    event.preventDefault();
    const form = event.currentTarget;
    const body = new FormData(form);
    const file = body.get("image");
    if (!file?.size || file.size > 5 * 1024 * 1024) {
      setError("Selecciona una imagen de hasta 5 MB.");
      return;
    }
    void perform(`/${kind}`, body).then(() => form.reset());
  }
  return (
    <section className="media-panel" aria-labelledby="images-title">
      <h2 id="images-title">Fotografías</h2>
      <p className="muted">
        Una portada y hasta ocho imágenes de galería. JPG, PNG o WebP; máximo 5 MB por archivo. Las
        imágenes subidas tienen una URL pública: evita fotografías privadas.
      </p>
      <div className="media-forms">
        {[
          ["cover", item.cover ? "Sustituir portada" : "Subir portada"],
          ["gallery", "Agregar a galería"],
        ].map(([kind, label]) => (
          <form key={kind} onSubmit={(event) => upload(event, kind)}>
            <fieldset disabled={busy || (kind === "gallery" && item.gallery.length >= 8)}>
              <label htmlFor={`upload-${kind}`}>Archivo para {label.toLowerCase()}</label>
              <input
                id={`upload-${kind}`}
                name="image"
                type="file"
                required
                accept="image/jpeg,image/png,image/webp"
              />
              <Button type="submit">{label}</Button>
            </fieldset>
          </form>
        ))}
      </div>
      {item.cover && (
        <Button
          variant="outline"
          disabled={busy}
          onClick={() => setConfirmation({ path: "/cover", label: "la portada" })}
        >
          Quitar portada
        </Button>
      )}
      <h3>Galería ({item.gallery.length}/8)</h3>
      {!item.gallery.length && <p className="muted">Todavía no hay fotografías adicionales.</p>}
      <div className="gallery-grid">
        {item.gallery.map((image, index) => (
          <figure key={image.publicId}>
            <a href={image.url} target="_blank" rel="noreferrer">
              <img src={image.url} alt={`Fotografía ${index + 1} de ${item.name}`} loading="lazy" />
            </a>
            <figcaption>
              <Button
                variant="outline"
                disabled={busy}
                onClick={() =>
                  setConfirmation({
                    path: `/gallery/${encodeURIComponent(image.publicId)}`,
                    label: `la fotografía ${index + 1}`,
                  })
                }
              >
                Eliminar fotografía {index + 1}
              </Button>
            </figcaption>
          </figure>
        ))}
      </div>
      {confirmation && (
        <section className="delete-confirmation" aria-label="Confirmar eliminación de imagen">
          <p>¿Eliminar {confirmation.label}?</p>
          <div className="actions">
            <Button
              variant="destructive"
              disabled={busy}
              onClick={() => perform(confirmation.path, undefined, "DELETE")}
            >
              Confirmar imagen
            </Button>
            <Button variant="outline" disabled={busy} onClick={() => setConfirmation(null)}>
              Cancelar imagen
            </Button>
          </div>
        </section>
      )}
      {busy && <p role="status">Procesando imagen… Espera la confirmación antes de salir.</p>}
      {message && (
        <p className="success" role="status">
          {message}
        </p>
      )}
      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
    </section>
  );
}

export function TagsInput({ initial = [] }) {
  const [tags, setTags] = useState(initial);
  const [draft, setDraft] = useState("");
  function add() {
    const value = draft.trim();
    if (!value || tags.length >= 20) return;
    if (!tags.some((tag) => tag.toLocaleLowerCase("es") === value.toLocaleLowerCase("es")))
      setTags([...tags, value]);
    setDraft("");
  }
  return (
    <div className="field">
      <label htmlFor="tag-draft">Etiquetas (opcional)</label>
      <div className="actions">
        <input
          id="tag-draft"
          value={draft}
          maxLength={30}
          onChange={(event) => setDraft(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === "Enter") {
              event.preventDefault();
              add();
            }
          }}
        />
        <Button
          type="button"
          variant="outline"
          disabled={!draft.trim() || tags.length >= 20}
          onClick={add}
        >
          Agregar etiqueta
        </Button>
      </div>
      <small className="muted">
        Hasta 20 etiquetas de 30 caracteres. Pulsa Agregar etiqueta antes de guardar.
      </small>
      <div className="tags">
        {tags.map((tag) => (
          <span key={tag}>
            <input type="hidden" name="tags" value={tag} />
            {tag}{" "}
            <button
              type="button"
              aria-label={`Quitar etiqueta ${tag}`}
              onClick={() => setTags(tags.filter((value) => value !== tag))}
            >
              ×
            </button>
          </span>
        ))}
      </div>
    </div>
  );
}
