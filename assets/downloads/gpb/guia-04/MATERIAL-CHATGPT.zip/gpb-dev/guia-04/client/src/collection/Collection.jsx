import { useState } from "react";
import { Link, useLocation, useNavigate, useParams, useSearchParams } from "react-router";
import { ResourceState, useResource } from "@/lib/resource";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";

import { MediaPanel, TagsInput } from "./MediaPanel";

export function Cover({ image, name }) {
  const [failedUrl, setFailedUrl] = useState("");
  if (image?.url && failedUrl !== image.url)
    return (
      <img
        className="gunpla-cover actual-cover"
        src={image.url}
        alt={`Portada de ${name}`}
        onError={() => setFailedUrl(image.url)}
      />
    );
  return (
    <div className="gunpla-cover" role="img" aria-label="Portada de reemplazo">
      <span aria-hidden="true">◇</span>
      <small>GPB / SIN PORTADA</small>
    </div>
  );
}
const filters = ["q", "grade", "scale", "state"];
const states = ["Sin armar", "En progreso", "Armado"];

function CollectionFilters({ params, apply, clear }) {
  const catalogs = useResource("/catalogs");
  if (!catalogs.data) return <ResourceState resource={catalogs} />;
  const fields = [
    ["grade", "Grado", catalogs.data.grades],
    ["scale", "Escala", catalogs.data.scales],
    ["state", "Estado", states.map((name) => ({ id: name, name }))],
  ];
  return (
    <form
      className="collection-filters"
      aria-label="Explorar colección"
      onSubmit={(event) => {
        event.preventDefault();
        apply(new FormData(event.currentTarget));
      }}
    >
      <label>
        Buscar por nombre
        <Input
          type="search"
          name="q"
          placeholder="Buscar Gunpla"
          maxLength={120}
          defaultValue={params.get("q") || ""}
        />
      </label>
      {fields.map(([key, label, options]) => (
        <label key={key}>
          {label}
          <select name={key} defaultValue={params.get(key) || ""}>
            <option value="">Cualquiera</option>
            {options.map(({ id, name }) => (
              <option key={id} value={id}>
                {name}
              </option>
            ))}
          </select>
        </label>
      ))}
      <div className="filter-actions">
        <Button type="submit">Aplicar filtros</Button>
        <Button
          variant="outline"
          type="button"
          onClick={(event) => {
            event.currentTarget.form.reset();
            clear();
          }}
        >
          Limpiar
        </Button>
      </div>
    </form>
  );
}

export function Collection() {
  const [params, setParams] = useSearchParams();
  const selected = new URLSearchParams();
  for (const key of filters) {
    if (params.get(key)) selected.set(key, params.get(key));
  }
  const query = new URLSearchParams(selected);
  query.set("page", params.get("page") || "1");
  const resource = useResource(`/gunpla?${query}`);
  const filtered = selected.size > 0;
  function apply(formData) {
    const next = new URLSearchParams();
    for (const key of filters) {
      const value = formData.get(key).trim();
      if (value) next.set(key, value);
    }
    setParams(next);
  }
  function goToPage(page) {
    const next = new URLSearchParams(selected);
    next.set("page", String(page));
    setParams(next);
  }
  const location = useLocation();
  return (
    <>
      <p className="eyebrow">TUS MODELOS / TU PROCESO</p>
      <div className="page-heading">
        <h1>Mi colección</h1>
        <Button asChild>
          <Link to="/coleccion/nuevo">Agregar Gunpla</Link>
        </Button>
      </div>
      <CollectionFilters
        key={selected.toString()}
        params={selected}
        apply={apply}
        clear={() => setParams({})}
      />
      {location.state?.message && (
        <p role="status" className="success">
          {location.state.message}
        </p>
      )}
      {!resource.data ? (
        <ResourceState resource={resource} />
      ) : (
        <>
          <p className="muted">
            {resource.data.total} {resource.data.total === 1 ? "modelo" : "modelos"}{" "}
            {filtered
              ? resource.data.total === 1
                ? "encontrado"
                : "encontrados"
              : "en tu colección"}
          </p>
          {resource.data.items.length === 0 ? (
            <Card className="empty-card">
              <CardContent>
                <h2>
                  {resource.data.total
                    ? "No hay registros en esta página"
                    : filtered
                      ? "Sin coincidencias"
                      : "El primer build está por llegar"}
                </h2>
                <p className="muted">
                  {resource.data.total
                    ? "Vuelve a la primera página para consultar tu colección."
                    : filtered
                      ? "Prueba con otro nombre o cambia los filtros."
                      : "Agrega tu primer Gunpla y acompaña su construcción."}
                </p>
                {resource.data.total ? (
                  <Button onClick={() => goToPage(1)}>Primera página</Button>
                ) : filtered ? (
                  <Button onClick={() => setParams({})}>Quitar filtros</Button>
                ) : (
                  <Button asChild>
                    <Link to="/coleccion/nuevo">Agregar mi primer Gunpla</Link>
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="collection-grid">
              {resource.data.items.map((item) => (
                <Link className="gunpla-card" to={`/coleccion/${item.id}`} key={item.id}>
                  <Cover image={item.cover} name={item.name} />
                  <div className="gunpla-card-body">
                    <span className="state-badge">{item.state}</span>
                    <h2>{item.name}</h2>
                    <p className="muted">
                      {item.grade?.name} · {item.scale?.name}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          )}
          {resource.data.pages > 1 && (
            <div className="pagination" aria-label="Páginas de la colección">
              <Button
                variant="outline"
                disabled={resource.data.page <= 1}
                onClick={() => goToPage(resource.data.page - 1)}
              >
                Anterior
              </Button>
              <span>
                Página {resource.data.page} de {resource.data.pages}
              </span>
              <Button
                variant="outline"
                disabled={resource.data.page >= resource.data.pages}
                onClick={() => goToPage(resource.data.page + 1)}
              >
                Siguiente
              </Button>
            </div>
          )}
        </>
      )}
    </>
  );
}
export function GunplaDetail() {
  const location = useLocation();
  const { id } = useParams();
  const resource = useResource(`/gunpla/${id}`);
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();
  async function remove() {
    setBusy(true);
    setError("");
    try {
      await api(`/gunpla/${id}`, { method: "DELETE" });
      navigate("/coleccion", { replace: true, state: { message: "Gunpla eliminado." } });
    } catch (failure) {
      setError(failure.message);
      setBusy(false);
    }
  }
  if (!resource.data) return <ResourceState resource={resource} />;
  const item = resource.data.gunpla;
  return (
    <>
      <Link className="text-link" to="/coleccion">
        Volver a mi colección
      </Link>
      {location.state?.message && (
        <p role="status" className="success">
          {location.state.message}
        </p>
      )}
      <div className="detail-grid">
        <Cover image={item.cover} name={item.name} />
        <section>
          <p className="eyebrow">DETALLE DEL GUNPLA</p>
          <h1>{item.name}</h1>
          <span className="state-badge">{item.state}</span>
          <dl>
            <dt>Grado</dt>
            <dd>{item.grade?.name}</dd>
            <dt>Escala</dt>
            <dd>{item.scale?.name}</dd>
            <dt>Descripción</dt>
            <dd>{item.description || "Sin descripción."}</dd>
            <dt>Notas</dt>
            <dd>{item.notes || "Sin notas."}</dd>
          </dl>
          <div className="actions">
            <Button asChild>
              <Link to={`/coleccion/${id}/editar`}>Editar Gunpla</Link>
            </Button>
            <Button variant="outline" onClick={() => setConfirming(true)}>
              Eliminar Gunpla
            </Button>
          </div>
          {confirming && (
            <section className="delete-confirmation" aria-label="Confirmar eliminación">
              <h2>¿Eliminar este Gunpla?</h2>
              <p>Se eliminará «{item.name}». Esta acción no se puede deshacer.</p>
              <div className="actions">
                <Button variant="destructive" disabled={busy} onClick={remove}>
                  {busy ? "Eliminando…" : "Confirmar eliminación"}
                </Button>
                <Button
                  variant="outline"
                  disabled={busy}
                  onClick={() => {
                    setConfirming(false);
                    setError("");
                  }}
                >
                  Cancelar
                </Button>
              </div>
            </section>
          )}
          {error && (
            <p className="error" role="alert">
              {error}
            </p>
          )}
        </section>
      </div>
      <div className="tags">
        {item.tags?.map((tag) => (
          <span key={tag}>{tag}</span>
        ))}
      </div>
      <MediaPanel
        item={{ ...item, gallery: item.gallery || [] }}
        onChange={(gunpla) => resource.setData({ gunpla })}
      />
      {item.youtubeId && (
        <section>
          <h2>Video del modelo</h2>
          <iframe
            className="youtube-player"
            title={`Video de ${item.name}`}
            src={`https://www.youtube-nocookie.com/embed/${item.youtubeId}`}
            loading="lazy"
            referrerPolicy="strict-origin-when-cross-origin"
            allow="encrypted-media; picture-in-picture"
            allowFullScreen
          />
        </section>
      )}
    </>
  );
}
export function GunplaFormPage() {
  const { id } = useParams();
  const options = useResource("/catalogs");
  const record = useResource(id ? `/gunpla/${id}` : null);
  if (!options.data) return <ResourceState resource={options} />;
  if (id && !record.data) return <ResourceState resource={record} />;
  return (
    <GunplaForm
      key={id || "new"}
      id={id}
      catalogs={options.data}
      initial={id ? record.data.gunpla : null}
    />
  );
}
function GunplaForm({ id, catalogs, initial }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const unavailable = !catalogs.grades.length || !catalogs.scales.length;
  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    setError("");
    const form = new FormData(event.currentTarget);
    const body = { ...Object.fromEntries(form), tags: form.getAll("tags") };
    try {
      const result = await api(id ? `/gunpla/${id}` : "/gunpla", {
        method: id ? "PUT" : "POST",
        body,
      });
      navigate(`/coleccion/${result.gunpla.id}`, {
        replace: true,
        state: { message: id ? "Gunpla actualizado." : "Gunpla creado." },
      });
    } catch (failure) {
      setError(failure.message);
      setBusy(false);
    }
  }
  return (
    <>
      <p className="eyebrow">TU SIGUIENTE BUILD</p>
      <h1>{id ? "Editar Gunpla" : "Agregar Gunpla"}</h1>
      <p className="muted">Nombre, grado, escala y estado son obligatorios.</p>
      {unavailable && (
        <p role="alert" className="error">
          Los catálogos todavía no están disponibles. Ejecuta la carga inicial del servidor y
          recarga esta página.
        </p>
      )}
      <form className="gunpla-form" onSubmit={submit}>
        <fieldset disabled={busy || unavailable}>
          <div className="field">
            <Label htmlFor="name">Nombre</Label>
            <Input
              id="name"
              name="name"
              required
              maxLength={120}
              defaultValue={initial?.name || ""}
            />
          </div>
          <div className="form-row">
            {[
              ["grade", "Grado", catalogs.grades],
              ["scale", "Escala", catalogs.scales],
            ].map(([name, label, items]) => (
              <div className="field" key={name}>
                <Label htmlFor={name}>{label}</Label>
                <select id={name} name={name} required defaultValue={initial?.[name]?.id || ""}>
                  <option value="" disabled>
                    Selecciona una opción
                  </option>
                  {items.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name}
                    </option>
                  ))}
                </select>
              </div>
            ))}
          </div>
          <div className="field">
            <Label htmlFor="state">Estado</Label>
            <select id="state" name="state" defaultValue={initial?.state || "Sin armar"} required>
              {["Sin armar", "En progreso", "Armado"].map((state) => (
                <option key={state}>{state}</option>
              ))}
            </select>
          </div>
          {[
            ["description", "Descripción"],
            ["notes", "Notas"],
          ].map(([name, label]) => (
            <div className="field" key={name}>
              <Label htmlFor={name}>{label} (opcional)</Label>
              <textarea
                id={name}
                name={name}
                maxLength={1000}
                rows={4}
                defaultValue={initial?.[name] || ""}
              />
              <small className="muted">Hasta 1000 caracteres.</small>
            </div>
          ))}
          <TagsInput initial={initial?.tags || []} />
          <div className="field">
            <Label htmlFor="youtubeUrl">Enlace de YouTube (opcional)</Label>
            <Input
              id="youtubeUrl"
              name="youtubeUrl"
              type="url"
              maxLength={300}
              placeholder="https://www.youtube.com/watch?v=…"
              defaultValue={
                initial?.youtubeId ? `https://www.youtube.com/watch?v=${initial.youtubeId}` : ""
              }
            />
            <small className="muted">
              Enlace HTTPS de youtube.com o youtu.be; no pegues código HTML.
            </small>
          </div>
        </fieldset>
        {error && (
          <p role="alert" className="error">
            {error}
          </p>
        )}
        <div className="actions">
          <Button type="submit" disabled={busy || unavailable}>
            {busy ? "Guardando…" : "Guardar Gunpla"}
          </Button>
          <Button variant="outline" asChild>
            <Link to={id ? `/coleccion/${id}` : "/coleccion"}>Cancelar</Link>
          </Button>
        </div>
      </form>
    </>
  );
}
