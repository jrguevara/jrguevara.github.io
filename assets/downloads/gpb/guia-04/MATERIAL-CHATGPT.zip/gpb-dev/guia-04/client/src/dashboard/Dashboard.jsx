import { Link } from "react-router";
import { Bar, BarChart, CartesianGrid, Pie, PieChart, XAxis, YAxis } from "recharts";
import { useAuth } from "@/auth/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { ResourceState, useResource } from "@/lib/resource";

const status = {
  armado: { label: "Armado", summary: "Armados", color: "#51d9aa" },
  progreso: { label: "En progreso", summary: "En progreso", color: "#f9bd6b" },
  pendiente: { label: "Sin armar", summary: "Sin armar", color: "#82adff" },
};
const gradeConfig = { count: { label: "Gunpla", color: "#82adff" } };

function DashboardCharts({ byState, byGrade }) {
  const distribution = Object.entries(status).map(([key, { label, color }]) => ({
    key,
    name: label,
    fill: color,
    count: byState[label],
  }));
  return (
    <div className="dashboard-charts">
      <Card>
        <CardHeader>
          <h2>Distribución por estado</h2>
        </CardHeader>
        <CardContent>
          <ChartContainer config={status} className="dashboard-donut">
            <PieChart accessibilityLayer>
              <ChartTooltip content={<ChartTooltipContent nameKey="key" hideLabel />} />
              <Pie
                data={distribution}
                dataKey="count"
                nameKey="name"
                innerRadius="58%"
                outerRadius="88%"
                stroke="none"
                isAnimationActive={false}
              />
            </PieChart>
          </ChartContainer>
          <ul className="dashboard-legend">
            {distribution.map(({ key, name, count, fill }) => (
              <li key={key}>
                <span style={{ backgroundColor: fill }} aria-hidden="true" />
                {name} <strong>{count}</strong>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <h2>Gunpla por grado</h2>
        </CardHeader>
        <CardContent>
          <ChartContainer
            config={gradeConfig}
            className="dashboard-bars"
            style={{ height: Math.max(210, byGrade.length * 34 + 44) }}
          >
            <BarChart accessibilityLayer layout="vertical" data={byGrade} margin={{ right: 12 }}>
              <CartesianGrid horizontal={false} />
              <XAxis type="number" allowDecimals={false} tick={{ fill: "#a5a7ae" }} />
              <YAxis
                tick={{ fill: "#a5a7ae" }}
                type="category"
                dataKey="name"
                width={78}
                interval={0}
                tickFormatter={(name) => name.match(/\(([^)]+)\)$/)?.[1] || name}
              />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Bar
                dataKey="count"
                fill="var(--color-count)"
                radius={[0, 4, 4, 0]}
                isAnimationActive={false}
              />
            </BarChart>
          </ChartContainer>
          <ul className="sr-only" aria-label="Recuentos por grado">
            {byGrade.map(({ name, count }) => (
              <li key={name}>
                {name} · {count}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const resource = useResource("/dashboard");
  const { data } = resource;
  return (
    <>
      <p className="eyebrow">DASHBOARD</p>
      <div className="page-heading">
        <h1>Hola, {user.username}.</h1>
        <Button asChild>
          <Link to="/coleccion">Ver mi colección</Link>
        </Button>
      </div>
      {!data ? (
        <ResourceState resource={resource} />
      ) : data.total === 0 ? (
        <Card className="empty-card">
          <CardContent>
            <h2>Tu colección está vacía</h2>
            <p className="muted">
              Agrega tu primer Gunpla para ver aquí el resumen de tu colección.
            </p>
            <Button asChild>
              <Link to="/coleccion/nuevo">Agregar mi primer Gunpla</Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="dashboard">
          <section className="dashboard-totals" aria-label="Resumen de la colección">
            <Card>
              <CardContent>
                <p>Total de Gunpla</p>
                <strong>{data.total}</strong>
              </CardContent>
            </Card>
            {Object.entries(status).map(([key, { label, summary, color }]) => (
              <Card key={key}>
                <CardContent>
                  <p>{summary}</p>
                  <strong style={{ color }}>{data.byState[label]}</strong>
                </CardContent>
              </Card>
            ))}
          </section>
          <DashboardCharts byState={data.byState} byGrade={data.byGrade} />
          <Card>
            <CardHeader>
              <h2>Registros recientes</h2>
            </CardHeader>
            <CardContent>
              <ul className="recent-gunpla">
                {data.recent.map(({ id, name, state }) => (
                  <li key={id}>
                    <Link to={`/coleccion/${id}`}>{name}</Link>
                    <span className="state-badge">{state}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
      )}
    </>
  );
}
