# Estado de GPB

Actualizado: 19 de noviembre de 2026.

## Etapa 1 — configuración y autenticación

**Guía 1 reproducida completamente con sus diagramas finales en gpb-dev/guia-01. Pruebas locales y Atlas aprobados; versión conservada.**

- Cliente React JavaScript con Vite+, Tailwind y componentes shadcn/ui: formularios oscuros, navegación y rutas protegidas.
- API Express/Mongoose independiente: registro, login, logout, Argon2id, sesiones connect-mongo, CSRF, validación y límites.
- Entorno confirmado: Node 26.13.1, pnpm 12.18.0, Vite+ global/local 1.6.0, macOS arm64. Versiones exactas y lock raíz conservados; sin modificaciones globales.
- Comprobados localmente: instalación congelada, revisión sin advertencias, compilación, 6/6 pruebas API y 2/2 pruebas de transporte Chromium/Electron.
- Atlas MongoDB 8.0.37: conexión, índices únicos, hash, persistencia de sesión al reiniciar API y revocación correctos.
- Flujo real React → proxy Vite+ → API → Atlas comprobado: registro, hash persistido, navegador y API reiniciados, navegación, rechazo de contraseña incorrecta, nuevo acceso y cierre. Cuenta y sesiones exclusivas de prueba eliminadas, perfiles temporales eliminados y procesos detenidos.
- Prueba Electron preparatoria aprobada; la integración completa de React y el paquete corresponden a etapa 6.
- Guía reproducida desde preparación en copia aislada, transcribiendo sus 33 bloques: instalación congelada, API/cliente, recorrido de navegador con Atlas, check, build, 6/6 pruebas API, 2/2 de transporte y ambos verificadores Atlas aprobados. Informe en docs/etapas/01/VERIFICACION.md.
- Repositorio Git inicializado por el docente en la raíz, rama main. Primer commit de la etapa 1 autorizado; su identificador se consulta con `git log -1 --oneline`. No se crearon etiquetas ni publicaciones. Fuentes conservadas con inventario SHA-256; ninguna copia incluye server/.env ni secretos.

## Reproducción persistente con los diagramas finales (18 de noviembre)

- Contenedor creado: `gpb-dev/`; primera versión: `gpb-dev/guia-01/`. Cada guía futura tendrá su propia carpeta sin sobrescribir la anterior.
- 33 bloques transcritos y comprobados; instalación exacta, revisión, compilación, 6 pruebas API y 2 de transporte aprobados.
- Tres diagramas validados en la nueva ruta, con 27 referencias de código, doce capturas y revisión visual de claro/oscuro. Exportaciones PNG/SVG y enlaces conservados.
- Atlas se repitió tras la intervención del docente: MongoDB 8.0.37, índices, hash, persistencia/revocación y flujo web con reinicios aprobados. Cuenta, sesiones y colecciones temporales limpiadas. El bloqueo inicial de conectividad quedó resuelto.
- Resultado detallado: `docs/etapas/01/VERIFICACION-GPB-DEV.md`. La configuración privada de guia-01 queda local e ignorada por Git; los procesos se detuvieron.

## Etapa 2 — gestión de la colección

Implementación y guía reproducidas en `gpb-dev/guia-02`, sin cambiar guia-01 ni la aplicación de referencia raíz. Modelos Gunpla/Grade/Scale, catálogos compartidos con carga idempotente y orden acordado, API CRUD privada por usuario, validación, tarjetas, detalle básico, formulario compartido, portada de reemplazo y paginación de 12.

- Código comprobado inicial: commit 86f4719; dependencias exactas y lock de guía 1 conservados.
- Aprobados: check, build (206 módulos), 12 pruebas API y 3 de navegador/Electron.
- Atlas 8.0.37: catálogos idempotentes, CRUD React, dos usuarios aislados, persistencia tras reiniciar API/navegador, edición/eliminación y limpieza aprobados.
- Guía: `docs/guias/02-GESTION-DE-LA-COLECCION.md`. Sus 15 bloques se reprodujeron desde guía 1 en copia aislada; código/lock coinciden con guia-02. Informe: `docs/etapas/02/VERIFICACION.md`.
- Dos diagramas respaldados por código, validados en navegador y exportados a PNG/SVG. Índice: `docs/etapas/02/DIAGRAMAS.md`.
- Material técnico y adjuntos en `docs/etapas/02/`. Guía publicada en GitHub.io con sus dos diagramas y adjuntos; compilación y despliegue remotos aprobados, página y recursos públicos comprobados. Resultado en PUBLICACION.md.
- Imágenes/galería/etiquetas/video corresponden a etapa 3; búsqueda/filtros/dashboard a etapa 4. Sin funcionalidades adelantadas.

## Etapa 3 — imágenes y detalle completo

Inicio autorizado el 19/11/2026. Implementación independiente en gpb-dev/guia-03: Cloudinary desde el servidor, portada y galería, validación real de imágenes, concurrencia acotada y bloqueo persistente, diario de limpieza y eliminación lógica, etiquetas, YouTube y detalle oscuro adaptable. La raíz y guías 1/2 se conservan.

- Node 26.13.1, pnpm 12.18.0, Vite+ 1.6.0; nuevas dependencias exactas Cloudinary 2.11.0, Multer 2.5.0 y Sharp 0.35.5.
- Aprobados en implementación: check, build de 207 módulos, 21 pruebas API y cuatro recorridos navegador/Electron; capturas oscuras de escritorio y móvil.
- Guía redactada en docs/guias/03-IMAGENES-Y-DETALLE-COMPLETO.md y reproducida desde guía 2: 24 bloques completos y lock coincidentes, instalación, check/build, 21 pruebas API y cuatro recorridos aprobados.
- Atlas real comprobado desde la copia aislada: MongoDB 8.0.39, autenticación/sesiones y diario de imágenes; en esa comprobación Cloudinary fue simulado, no se atribuye una prueba real al proveedor.
- Dos diagramas conceptuales interactivos y exportaciones PNG/SVG oscuras, validados y revisados visualmente; DIAGRAMAS.md distingue su alcance y falta de commit de etapa 3.
- Configuración privada Cloudinary recibida localmente en el ejemplo y trasladada a .env ignorado, con el ejemplo saneado. Tras corregir el cloud name, Atlas y Cloudinary reales pasaron en referencia y reproducción, con limpieza de cuentas, sesiones e imágenes temporales.
- Sin commits, etiquetas ni publicaciones nuevos. Se conservan los archivos sin seguimiento de Canvas y del demo de video.

## Continuación

La etapa 3 está implementada y reproducida con Atlas y Cloudinary reales comprobados. Borrador del sitio preparado en _drafts con published:false, recursos y descargas; Jekyll, HTML-Proofer (134 páginas), comparación de 24 bloques y revisión oscura de escritorio/móvil aprobados. Guía 3 publicada y comprobada en GitHub.io el 19/11/2026, con fecha editorial 14/11/2026; 24 bloques y 12 recursos públicos verificados. Canvas de guía 3 preparado como borrador provisional, con datos de sesión/foro y URL real pendientes, sin reutilizar los de guía 2 ni enviar sus archivos a Git. La guía 3 está técnicamente comprobada para grabar; su publicación editorial con fecha 14/11/2026 ya está comprobada. Render y el paquete macOS siguen en etapas 5/6.

## Material disponible

- Suplemento del 13 de noviembre: `docs/etapas/01/DIAGRAMAS.md` enlaza tres diagramas Archify (arquitectura local, registro y acceso/cierre de sesión), respaldados por el commit 525ad08. Comprobaciones automáticas completas aprobadas. Enlaces añadidos a la sección 1.2 de la guía; los ZIP previos no se regeneraron y no incluyen este suplemento.

- docs/guias/01-CONFIGURACION-Y-AUTENTICACION.md: versión final comprobada y lista para grabar.
- docs/etapas/01/VERIFICACION.md: entorno, secuencia ejecutada, resultados, diferencias y limpieza de la reproducción.

- docs/etapas/01/REGISTRO.md: comandos reales, versiones, historial de diagnósticos y resultados finales.
- docs/etapas/01/FUENTES.md: herramientas con descripción, motivo, Getting Started, requisitos y comprobaciones.
- docs/etapas/01/TRASPASO-CHATGPT.md: encargo de redacción, incrementos y adjuntos precisos.
- docs/etapas/01/capturas/: acceso en escritorio y móvil sin datos privados.
- docs/etapas/01/codigo-etapa-1.zip e INVENTARIO-SHA256.txt: fuentes conservadas.
- docs/etapas/01/MATERIAL-CHATGPT.zip: material actualizado con fuentes, documentación, guía final e informe de verificación; sin secretos.

## Uso local

Desde raíz, con server/.env privado configurado: `pnpm dev:server` y, en otra terminal raíz, `pnpm dev:client`. Abrir http://localhost:5173. Las herramientas de comprobación de Atlas son `pnpm --filter @gpb/server check:atlas` y `pnpm --filter @gpb/server check:web:atlas`; la segunda levanta y detiene API y cliente y requiere los puertos 3000/5173 libres.

## Pruebas posteriores separadas

Publicación real y HTTPS Render: etapa 5. Interfaz completa de Electron y paquete macOS Apple Silicon: etapa 6. La evaluación es independiente de las seis guías.
