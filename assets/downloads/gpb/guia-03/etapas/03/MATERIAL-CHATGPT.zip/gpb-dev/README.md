# GPB — versiones progresivas reproducidas

Cada carpeta conserva el resultado de una guía y funciona como proyecto independiente.

| Entrega | Carpeta | Estado actual |
|---|---|---|
| Guía 1 | [guia-01](guia-01/README.md) | Reproducción completa: aplicación, diagramas, pruebas locales y Atlas aprobados |
| Guía 2 | [guia-02](guia-02/README.md) | Colección privada, catálogos, CRUD, guía y diagramas; reproducción local y Atlas aprobada |
| Guía 3 | [guia-03](guia-03/README.md) | Imágenes y detalle completo; reproducción local, Atlas y Cloudinary reales aprobados |

Las guías 4 a 6 se incorporarán cuando se implementen y reproduzcan. Para cada nueva entrega se partirá de las fuentes comprobadas de la anterior sin sobrescribirla, sin copiar node_modules, dist, informes temporales o credenciales. No se crean carpetas futuras vacías ni se adelantan funciones.

Ejecutar los comandos desde la carpeta de cada guía, nunca desde este contenedor. Cada entrega tendrá su propio package.json, pnpm-workspace.yaml, archivo de bloqueo, dependencias y configuración local privada. Sólo puede usarse una versión a la vez con los puertos 3000 y 5173 predeterminados. El .gitignore del proyecto excluye .env, dependencias y compilaciones. Se utiliza el repositorio Git raíz; no hay repositorios anidados.

La implementación de referencia del repositorio permanece separada y no fue sustituida por estas copias de reproducción. Los resultados actuales se documentan tanto en cada versión como en docs/etapas/01/VERIFICACION-GPB-DEV.md de la raíz.
