# GPB — Gunpla Personal Builds: planificación del proyecto

Fecha: 10 de noviembre de 2026.

Última actualización: 19 de noviembre de 2026. Desarrollo organizado en seis partes.

## 1. Propósito

Desarrollar una aplicación para registrar y administrar una colección personal de Gunpla, como proyecto de la materia universitaria **Desarrollo de Aplicaciones Multiplataforma**.

La aplicación se construirá con el stack MERN (MongoDB, Express, React y Node.js). Posteriormente se integrará con Electron para distribuirla como aplicación de escritorio para macOS.

La guía principal utilizará macOS con Apple Silicon (arm64). No se exigirá a los estudiantes demostrar una versión para Windows o Linux. Se preparará una evaluación independiente, fuera de las seis guías, cuyo contenido y criterios se definirán por separado.

Los estudiantes ya tienen conocimientos de JavaScript, React y Electron. El curso se enfocará en integrar las tecnologías y construir una aplicación completa de forma progresiva.

## 2. Forma de trabajo

- **Codex:** implementación del proyecto, comprobación del funcionamiento y mantenimiento de la documentación técnica.
- **ChatGPT:** redacción de seis guías detalladas en Markdown para acompañar seis videos de YouTube.
- **Excepción acordada para la guía 1 (12 de noviembre de 2026):** el docente solicita que Codex redacte el borrador y lo entregue para su revisión. Codex no reproducirá esa guía hasta recibir una indicación posterior del docente. Se conserva la separación entre implementación comprobada y reproducción del documento.
- Este documento será la referencia compartida para mantener alineados el código, las guías y los videos.
- La implementación avanzará en el mismo orden que las seis guías. Cada entrega deberá dejar una versión ejecutable y comprobable.
- Antes de redactar cada guía, se documentarán los comandos utilizados, los archivos creados o modificados, las decisiones y las comprobaciones necesarias para reproducir esa etapa.
- Conviene conservar un punto de control de cada entrega mediante Git, para poder consultar el código correspondiente a cada video.
- Cada estudiante utilizará sus propias cuentas gratuitas de MongoDB Atlas, Cloudinary y Render.

### Ciclo de cada entrega

1. Codex implementa la etapa en incrementos enseñables y comprueba sus resultados.
2. Codex registra comandos, carpetas, versiones y cambios por archivo en `docs/etapas/NN/REGISTRO.md` y prepara `TRASPASO-CHATGPT.md` al cerrar la implementación.
3. El docente proporciona a ChatGPT el traspaso y los archivos de código indicados; ChatGPT redacta la guía Markdown. No se presupone acceso compartido entre ambas herramientas.
4. Codex reproduce la guía desde el punto de partida de la entrega en una copia aislada y registra resultados en `VERIFICACION.md`.
5. Se corrigen diferencias y se conserva la versión comprobada antes de grabar y avanzar a la siguiente entrega.

Las reglas permanentes se mantienen en `AGENTS.md`. Las skills locales `.agents/skills/gpb-desarrollar-etapa/SKILL.md` y `.agents/skills/gpb-verificar-guia/SKILL.md` establecen los procedimientos reutilizables. `docs/ESTADO.md` indica el punto actual y las comprobaciones pendientes.

### Tecnologías de la interfaz acordadas

El proyecto utilizará JavaScript con ES Modules. Versiones de referencia consultadas el 11 de noviembre de 2026; deberán comprobarse en conjunto al configurar el proyecto y conservarse mediante el archivo de bloqueo de dependencias:

| Elemento | Versión de referencia |
|---|---|
| React y React DOM | 19.3.1 |
| Vite+ | 1.6.0 |
| shadcn CLI | 4.23.0 |
| Tailwind CSS | 4.3.5 |
| Recharts | 3.10.1 |

shadcn/ui aportará los componentes visuales y los componentes de gráficos basados en Recharts. La versión de shadcn corresponde a su CLI; los componentes se incorporan como código al proyecto.

Referencia editorial aportada por el docente: [NextJS 13 eCommerce app, parte 4](https://jrguevara.github.io/posts/NextJS-13-eCommerce-app-parte-4/).

## 3. Alcance funcional

### Usuarios

- Registro de una cuenta e inicio y cierre de sesión.
- El registro solicitará nombre de usuario único, correo electrónico único y contraseña. El inicio de sesión utilizará correo y contraseña.
- La sesión se conservará al cerrar y abrir el cliente mientras siga vigente. Los límites confirmados son 30 minutos de inactividad y un máximo absoluto de 7 días desde el inicio de sesión, con invalidación en el servidor al cerrar sesión. Al superar cualquiera de los límites será necesario iniciar sesión nuevamente. Son decisiones del proyecto, no una duración obligatoria de un estándar.
- Cada usuario administra y consulta únicamente su propia colección.
- La API debe comprobar la identidad y la propiedad de los registros en cada operación protegida.
- Las contraseñas se almacenarán mediante un hash, nunca como texto plano.
- La autenticación utilizará sesiones en el servidor mediante express-session y almacenamiento en MongoDB con connect-mongo. La cookie persistente contendrá únicamente el identificador de sesión, con HttpOnly y Secure en producción. La sesión se regenerará al iniciar sesión y se invalidará al salir.
- Se conservarán fecha de inicio y última actividad para aplicar por separado los límites absoluto y de inactividad. Las consultas automáticas de fondo no deberán mantener indefinidamente la sesión sin actividad del usuario.
- Antes de completar la primera etapa se probará la persistencia en navegador y Electron. Se resolverá el transporte de cookies considerando los orígenes separados de Render y el cliente local de Electron; no se dependerá de que el navegador permita cookies de terceros. Se evaluará un proxy de API bajo el origen web y una comunicación controlada desde Electron. Las operaciones de escritura incluirán protección contra CSRF cuando utilicen cookies.

### Colección

- Crear, consultar, editar y eliminar Gunpla.
- Mostrar la colección en tarjetas con portada, nombre, grado, escala y estado.
- Buscar por nombre.
- Filtrar por grado, escala y estado.
- Mostrar un mensaje y una acción para agregar el primer registro cuando la colección esté vacía.
- Confirmar la eliminación de un registro.
- Mostrar 12 Gunpla por página. La búsqueda y los filtros se aplicarán a toda la colección del usuario antes de paginar.
- Al eliminar un Gunpla, eliminar también sus imágenes de Cloudinary.

### Fotografías y video

- Adjuntar una imagen principal o portada.
- Agregar y eliminar imágenes de una galería.
- Mostrar una imagen de reemplazo cuando no exista portada.
- Guardar un enlace opcional de YouTube y mostrar su reproductor integrado en el detalle.
- Validar el enlace y construir el reproductor a partir del identificador del video; no aceptar HTML arbitrario del usuario.
- Admitir una portada y hasta ocho imágenes adicionales, con un máximo de 5 MB por archivo, en JPG, PNG o WebP.

## 4. Datos de cada Gunpla

| Campo | Descripción | Requerimiento |
|---|---|---|
| Nombre | Nombre del Gunpla | Obligatorio |
| Grado | Selección de un catálogo de MongoDB | Obligatorio |
| Escala | Selección de un catálogo de MongoDB | Obligatorio |
| Descripción | Información general del modelo | Opcional |
| Notas | Observaciones personales o de construcción | Opcional |
| Portada | Imagen principal | Opcional |
| Galería | Fotografías adicionales | Opcional |
| Video de YouTube | Enlace para el reproductor del detalle | Opcional |
| Etiquetas | Lista de textos, por ejemplo pintado, barnizado o personalizado | Opcional |
| Estado | Sin armar, En progreso o Armado | Obligatorio; valor inicial: Sin armar |

Nombre, grado, escala y estado son obligatorios. Los demás campos son opcionales. El estado inicial será Sin armar.

No existirá un campo de categoría: toda la aplicación estará dedicada a Gunpla.

Cada registro también tendrá un propietario y fechas de creación y actualización, asignados por el servidor.

### Catálogos de grados y escalas

- Los grados y las escalas se almacenarán en dos colecciones de referencia de MongoDB.
- El formulario consultará la API para obtener sus opciones; no estarán definidas directamente en el cliente.
- Cada Gunpla guardará referencias a los documentos seleccionados.
- Los catálogos serán compartidos por todos los usuarios.
- Se incluirá un comando de carga inicial que pueda ejecutarse de nuevo sin duplicar opciones.
- Inicialmente no se incluirá una pantalla para administrar estos catálogos.
- Los dos desplegables serán independientes, salvo que posteriormente se decida restringir sus combinaciones.
- Los valores iniciales se cargarán en el orden acordado a continuación.

**Grados:** Entry Grade (EG), High Grade (HG), Real Grade (RG), Master Grade (MG), Perfect Grade (PG), Super Deformed (SD), Full Mechanics (FM), Reborn-One Hundred (RE/100), Master Grade Extreme (MGEX), Master Grade Super Deformed (MGSD), Mega Size y Sin Grado.

**Escalas:** 1/144, 1/100, 1/60, 1/48 y Sin Escala.

### Etiquetas

El usuario podrá agregar varias etiquetas y eliminarlas desde el formulario. Se propone recortar espacios y evitar etiquetas vacías o duplicadas. No se requiere un catálogo global de etiquetas.

## 5. Pantallas y navegación

La interfaz utilizará modo oscuro, con una estructura sencilla y pocos formularios.

| Pantalla | Función |
|---|---|
| Iniciar sesión | Acceso a la cuenta |
| Registro | Creación de una cuenta |
| Dashboard | Inicio después de iniciar sesión y resumen de la colección |
| Mi colección | Tarjetas, búsqueda y filtros |
| Detalle del Gunpla | Datos completos, fotografías, etiquetas y video |
| Crear o editar Gunpla | Un mismo formulario reutilizado para ambas operaciones |

La navegación principal incluirá **Dashboard**, **Mi colección** y la acción de cerrar sesión. Se mostrarán estados de carga, errores comprensibles y confirmaciones de las operaciones.

## 6. Dashboard

El dashboard será la primera pantalla después de iniciar sesión y mostrará únicamente datos del usuario conectado.

| Elemento | Información |
|---|---|
| Tarjetas de resumen | Total de Gunpla, armados, sin armar y en progreso |
| Gráfico de dona | Distribución por estado |
| Gráfico de barras | Cantidad de Gunpla por grado |
| Registros recientes | Últimos Gunpla agregados, con acceso a su detalle |

Las estadísticas se calcularán sobre toda la colección del usuario, independientemente de los filtros o de la cantidad de tarjetas cargadas en Mi colección. Cuando no haya registros, se mostrará un estado vacío con acceso al formulario de creación.

Los gráficos utilizarán los componentes de shadcn/ui basados en Recharts.

## 7. Arquitectura y alojamiento

Flujo general:

```text
React en navegador o dentro de Electron
                  |
                  | HTTPS
                  v
          API Node.js + Express
             |             |
             v             v
        MongoDB Atlas   Cloudinary
        Datos y usuarios   Imágenes
```

- Electron contendrá la interfaz React y consumirá la API remota.
- La aplicación terminada requerirá conexión a internet.
- El usuario final no tendrá que instalar MongoDB ni ejecutar Express en su equipo.
- MongoDB guardará los datos y, para las imágenes, su URL e identificador de Cloudinary.
- Las credenciales privadas de MongoDB y Cloudinary permanecerán en el servidor y no se incluirán en React ni en el paquete de Electron.
- El servidor comprobará permisos tanto para modificar registros como para cargar o eliminar sus imágenes.

### Servicios gratuitos recomendados

| Componente | Servicio propuesto | Consideraciones |
|---|---|---|
| Base de datos | MongoDB Atlas Free | Plan gratuito con 512 MB; las imágenes se guardarán fuera de MongoDB |
| Imágenes | Cloudinary Free | Su cuota combina almacenamiento, transferencia y transformaciones |
| API | Render Free | Se suspende después de 15 minutos sin tráfico; la reactivación puede tardar aproximadamente un minuto |
| Web React | Render Static Site gratuito | Publicación del cliente web sujeta a las cuotas del servicio |

Estas opciones fueron revisadas durante la planificación. Sus condiciones deben comprobarse nuevamente al preparar la guía de publicación.

Referencias oficiales:

- [Límites de MongoDB Atlas Free](https://www.mongodb.com/docs/atlas/reference/free-shared-limitations/).
- [Planes de Cloudinary](https://cloudinary.com/pricing).
- [Alojamiento gratuito en Render](https://render.com/docs/free).

El almacenamiento local de Render es temporal; no se utilizará para conservar fotografías. La interfaz deberá contemplar la espera inicial cuando la API se esté reactivando.

Se publicarán tanto la web React como la API en Render, como servicios separados. La distribución de escritorio de la guía será para macOS Apple Silicon.

## 8. División en seis guías

### Guía 1: configuración y autenticación

**Objetivo:** establecer la base del proyecto y permitir el acceso de usuarios.

- Definir versiones y herramientas de desarrollo.
- Crear la estructura de React y Express.
- Configurar variables de entorno y conexión con MongoDB Atlas.
- Implementar registro, inicio y cierre de sesión.
- Proteger rutas y establecer la navegación con modo oscuro.

**Resultado comprobable:** un usuario puede registrarse, iniciar sesión, acceder a una pantalla inicial protegida y cerrar sesión. Esa pantalla se completará con estadísticas en la guía 4.

### Guía 2: gestión de la colección

**Objetivo:** administrar registros de Gunpla pertenecientes al usuario conectado.

- Crear los modelos de Gunpla, grado y escala.
- Cargar los catálogos iniciales y exponer su consulta.
- Implementar la API de creación, consulta, edición y eliminación.
- Comprobar la propiedad de los registros y validar los datos.
- Crear la colección, el detalle básico y el formulario compartido de creación y edición.
- Usar una portada de reemplazo hasta integrar la carga de imágenes.

**Resultado comprobable:** cada usuario administra su colección y selecciona grados y escalas obtenidos de MongoDB; no puede consultar ni modificar registros de otro usuario.

### Guía 3: imágenes y detalle completo

**Objetivo:** completar el registro visual y la información adicional de cada Gunpla.

- Integrar Cloudinary.
- Implementar la carga y sustitución de portada.
- Implementar la galería y la eliminación de imágenes.
- Completar la edición y visualización de etiquetas.
- Validar el enlace de YouTube e integrar el reproductor en el detalle.
- Gestionar errores de carga y la limpieza de imágenes al sustituirlas o eliminar registros.

**Resultado comprobable:** un Gunpla muestra portada, galería, etiquetas y un video opcional en su detalle.

### Guía 4: dashboard y exploración

**Objetivo:** resumir la colección y facilitar su consulta.

- Implementar estadísticas por usuario en la API.
- Completar el dashboard con tarjetas, gráficos y registros recientes.
- Agregar búsqueda por nombre y filtros por grado, escala y estado.
- Revisar los estados vacíos, de carga y de error.
- Ajustar la interfaz oscura y el comportamiento en distintos tamaños de ventana.

**Resultado comprobable:** el dashboard refleja la colección del usuario y la búsqueda y los filtros permiten localizar sus Gunpla.

### Guía 5: alojamiento y configuración de producción

**Objetivo:** dejar la API publicada y comprobar la aplicación web con los servicios remotos.

- Publicar la API en Render y configurar las variables de producción.
- Publicar el cliente React como Static Site en Render y configurar las rutas de la aplicación web.
- Configurar la conexión con Atlas y Cloudinary.
- Configurar la URL de la API y los orígenes permitidos para el cliente web.
- Comprobar registro, inicio de sesión, operaciones de la colección, imágenes y estadísticas con la API publicada.
- Revisar los mensajes de espera durante la reactivación del servicio gratuito y el manejo de fallos de conexión.
- Documentar los pasos de publicación y las diferencias entre desarrollo y producción.

**Resultado comprobable:** el cliente React publicado en Render permite utilizar la colección mediante la API publicada, Atlas y Cloudinary.

### Guía 6: integración con Electron y empaquetado para macOS

**Objetivo:** distribuir una aplicación de escritorio que utilice los servicios remotos configurados en la guía 5.

- Integrar la compilación de React con Electron.
- Configurar el acceso a la API, los permisos necesarios y la apertura segura de enlaces externos.
- Comprobar autenticación, imágenes y video desde la aplicación empaquetada.
- Generar el paquete para macOS y documentar su instalación de prueba.
- Utilizar Apple Silicon (arm64) para el paquete de macOS de la guía.
- Explicar la diferencia entre un paquete de práctica y una distribución firmada y notarizada; la firma y notarización no forman parte del alcance gratuito acordado.

**Resultado comprobable:** la aplicación se ejecuta en macOS Apple Silicon mediante la API alojada.

## 9. Formato de las guías

Cada guía se entregará como un archivo `.md` e incluirá:

1. Objetivos y resultado esperado.
2. Requisitos y punto de partida de la entrega anterior.
3. Comandos en su orden de ejecución, indicando en qué carpeta ejecutarlos.
4. Rutas exactas de los archivos que se crean o modifican.
5. Código progresivo, indicando qué agregar o reemplazar.
6. Explicación breve del propósito de cada cambio.
7. Comprobaciones manuales con resultados esperados.
8. Errores frecuentes y cómo resolverlos.
9. Cierre y conexión con la siguiente entrega.

Los comandos y ejemplos deberán corresponder al código comprobado de cada etapa. Se usarán valores de ejemplo y un archivo de variables de entorno de referencia, sin publicar credenciales reales.

### Presentación de herramientas y fuentes oficiales

Al introducir cada herramienta por primera vez, la guía incluirá, en este orden:

1. Una descripción breve de qué es y qué función cumple.
2. La razón concreta para utilizarla en GPB.
3. Un enlace directo a su documentación oficial de inicio o instalación (Getting Started), junto a la explicación.
4. Requisitos previos y versión elegida para el curso.
5. Comandos de instalación o configuración, con carpeta de ejecución y plataforma cuando corresponda.
6. Comandos para verificar la versión y el funcionamiento, indicando resultados esperados y resultados realmente comprobados.

Para dependencias sin CLI propia se consultará su versión instalada mediante el gestor de paquetes; no se inventará una opción `--version`. Para servicios administrados se comprobarán la configuración y conectividad cuando corresponda. Las guías posteriores podrán remitir a la instalación anterior si no cambia.

El registro técnico y el material de traspaso para ChatGPT conservarán las URL oficiales consultadas, fecha de consulta y comandos comprobados. Se distinguirán las instrucciones oficiales generales de las adaptaciones del proyecto.

Ejemplo de referencia: [Vite+ — Getting Started](https://viteplus.dev/guide/). Presentar su función en el desarrollo del cliente y justificar su uso para unificar comandos. Priorizar la instalación por proyecto, conforme a AGENTS.md; la instalación global publicada por el proveedor es una alternativa, no un requisito de GPB. Los comandos definitivos se documentarán tras probarlos en la etapa 1.

## 10. Elecciones técnicas para la implementación

Selección realizada el 12 de noviembre de 2026. Las versiones exactas se fijarán al instalar y comprobar el conjunto; una familia como 5.x no significa permitir actualizaciones automáticas durante el curso. Se conservará el archivo de bloqueo y se documentarán las versiones efectivamente utilizadas.

| Herramienta | Versión o línea elegida | Motivo |
|---|---|---|
| Node.js | 26.13.1 LTS | Línea LTS activa para desarrollo y API; misma versión en local y Render |
| Express | 5.x estable | API REST sencilla organizada en rutas, controladores y servicios |
| Mongoose | 9.x; referencia consultada 9.12.0 | Esquemas, validación, referencias y agregaciones para estadísticas |
| MongoDB | Versión administrada compatible ofrecida por Atlas Free | No requiere instalar ni administrar un servidor local; registrar la versión real del clúster al crearlo |
| express-session | 1.19.0 | Sesiones revocables con datos almacenados en el servidor |
| connect-mongo | Estable compatible con Node 26 y el driver seleccionado | Persistencia de sesiones sin contratar Redis ni depender de la memoria de Render |
| Argon2id mediante argon2 | Estable compatible con Node 26 | Hash de contraseñas; ejecutado únicamente en la API |
| Electron | 45.3.1 como referencia estable consultada | Contenedor de escritorio; comprobar actualizaciones de seguridad antes de la guía 6 |
| electron-builder | 26.x estable | Generar DMG y ZIP para macOS arm64 con configuración explícita |

### Organización y herramientas complementarias

- Un repositorio con carpetas para cliente, servidor, Electron y documentación. El servidor será independiente del paquete de escritorio.
- Vite+ será la herramienta del cliente y pnpm el gestor de paquetes, con su versión fijada al configurar el proyecto.
- React Router para navegación, fetch nativo para HTTP y Context para el estado de autenticación. Evitar un gestor global adicional mientras el alcance no lo requiera.
- Zod para validar entradas en la API; los índices únicos de MongoDB respaldarán la unicidad de nombre de usuario y correo.
- SDK oficial de Cloudinary y Multer para recibir imágenes con límites estrictos. Se validará también el contenido del archivo y se limitará el número de cargas simultáneas para controlar el uso de memoria.
- Helmet y límites de intentos en autenticación, además de la configuración de orígenes y protección CSRF correspondientes al transporte elegido.
- Variables de entorno con soporte nativo de Node.js; no añadir dotenv ni nodemon si las funciones nativas cubren el flujo de desarrollo.
- Pruebas de API para aislamiento entre usuarios, expiración de sesiones y validaciones, más comprobaciones de la web y del paquete Electron. Se aprovechará el ejecutor integrado de Node.js y las herramientas de Vite+ donde corresponda.
- Electron utilizará contextIsolation, sin acceso directo a Node.js desde React y con una interfaz preload limitada cuando sea necesaria. No se incluirán credenciales privadas ni módulos del servidor en el paquete.

### Comprobaciones técnicas previas a la guía 1

- Fijar las versiones exactas de las dependencias auxiliares y comprobar instalación, compilación y compatibilidad con Vite+ y JavaScript.
- Validar el transporte y persistencia de sesión en navegador y Electron con la topología prevista para producción.
- Confirmar la compatibilidad entre Mongoose, el driver requerido por connect-mongo y Atlas.

Referencias oficiales de las elecciones:

- [Versiones de Node.js](https://nodejs.org/en/blog/release).
- [Documentación de Express](https://expressjs.com/).
- [Soporte de versiones de Mongoose](https://mongoosejs.com/docs/version-support.html).
- [express-session](https://expressjs.com/en/resources/middleware/session/).
- [connect-mongo](https://github.com/jdesboeufs/connect-mongo).
- [node-argon2](https://github.com/ranisalt/node-argon2).
- [Versiones estables de Electron](https://releases.electronjs.org/?channel=stable).
- [electron-builder](https://www.electron.build/).

## 11. Límites del alcance inicial

La primera versión estará centrada en la colección personal. No contempla colecciones públicas, funciones sociales, roles de administración, recuperación de contraseña por correo, sincronización sin conexión ni actualizaciones automáticas de escritorio.

Estas funciones podrán evaluarse después sin ampliar las seis entregas acordadas.

## 12. Criterios generales de finalización

- El registro, inicio y cierre de sesión funcionan.
- Cada usuario solo accede a sus registros, imágenes y estadísticas.
- Los catálogos de grado y escala se obtienen de MongoDB.
- Las operaciones de la colección funcionan con validación y manejo de errores.
- La portada, galería y video se muestran correctamente.
- El dashboard refleja los cambios realizados en la colección.
- La búsqueda y los filtros funcionan con la colección del usuario.
- La aplicación empaquetada para macOS funciona con los servicios remotos.
- La web publicada funciona con la misma API.
- Las seis etapas son reproducibles a partir de sus comandos, código y comprobaciones documentadas.

## 13. Evaluación independiente

Se preparará una evaluación por separado. No formará parte de las seis guías ni será un requisito para completar sus entregas. Sus objetivos, actividades, entregables y criterios de calificación se definirán posteriormente en un documento independiente. No se establece como requisito demostrar una versión de la aplicación para Windows o Linux.


### Acuerdos de implementación de la etapa 1 (12 de noviembre de 2026)

- Entorno observado: Node.js 26.13.1, Vite+ 1.6.0 y pnpm 12.18.0. Se fija pnpm por proyecto sin cambiar herramientas globales. Las versiones exactas efectivas están en los manifiestos y el archivo de bloqueo raíz.
- Web: React llama exclusivamente a `/api` en su propio origen. Vite+ hace de proxy en desarrollo. En la etapa 5 Render Static Site deberá tener una regla de proxy/rewrite `/api/*` hacia la API, anterior al fallback de React; verificar que conserve Set-Cookie y Origin. No se aceptará una simple URL de API de terceros como sustituto. La publicación real sigue pendiente.
- Escritorio: la prueba mínima usa `fetch` nativo de Node desde el proceso principal y el almacén de cookies de una partición persistente de Electron. En la etapa 6 se conectará mediante una interfaz preload limitada con validación de remitente y acciones; React no recibirá cookies ni un fetch arbitrario. La prueba de etapa 1 no empaqueta la aplicación.
- CSRF: token aleatorio ligado a la sesión, regenerado al autenticar, encabezado `X-CSRF-Token` y comprobación del origen en escrituras, incluidas registro y login. Sin CORS abierto.
- Nombre de usuario normalizado a minúsculas: 3–30 caracteres ASCII, números, guion y guion bajo. Correo normalizado a minúsculas. Contraseña de 12–128 caracteres, sin recortarla. Unicidad respaldada por índices de MongoDB.
- Cookie host-only HttpOnly, SameSite=Lax, Path=/api, persistente hasta el límite absoluto, Secure en producción. Sólo eventos de interacción del usuario envían actividad, como máximo una vez por minuto; GET de identidad y sondeos no renuevan inactividad. Los límites se aplican en el servidor aun cuando el cliente esté cerrado.


### Cierre editorial de la guía 1 (12 de noviembre de 2026)

El docente autorizó crear la versión final de la guía y reservar sus indicaciones de publicación para después. Se cierra la redacción como versión final editorial, con reproducción técnica aún pendiente. La revisión automática rechazó iniciar la instalación aislada porque exige autorización posterior explícita para reproducir, dada la solicitud previa de revisión docente. No se publica ni se declara lista para grabar sin completar la reproducción.


### Verificación final de la guía 1 (12 de noviembre de 2026)

El docente autorizó expresamente reproducir la guía en copia aislada, incluidas pruebas Atlas y limpieza temporal. Se completó desde la preparación, transcribiendo los archivos del documento y comprobando cliente, API, sesiones, transporte y persistencia real. Se aclararon la dirección localhost y el cambio local de rama a main; no cambió código de aplicación. Resultados en docs/etapas/01/VERIFICACION.md. Guía final técnicamente lista para grabar; la publicación espera indicaciones del docente. El rechazo previo de aprobación se conserva sólo como historial y ya no es un bloqueo.


### Versiones progresivas de reproducción (18 de noviembre de 2026)

El docente solicita conservar las reproducciones dentro de `gpb-dev/`, con una carpeta por guía. Se utiliza `gpb-dev/guia-01/` para la primera; las siguientes partirán de las fuentes de la anterior y se crearán al implementar/reproducir cada entrega, sin sobrescribir versiones ni copiar secretos, dependencias o compilaciones. Estas copias son proyectos independientes dentro del repositorio raíz, sin repositorios Git anidados ni ampliación del alcance de las seis entregas. El informe de la nueva reproducción con diagramas registra las comprobaciones locales y ambos verificadores reales de Atlas aprobados; el bloqueo inicial de conectividad quedó resuelto.


### Acuerdos de la etapa 2 (18 de noviembre de 2026)

El docente autoriza implementar la gestión de colección en `gpb-dev/guia-02`, crear diagramas explicativos, redactar y reproducir la guía 2, sincronizar los archivos finales con Git/GitHub y publicar la guía en su sitio GitHub.io respetando el formato anterior. Se conserva `guia-01`. La raíz mantiene su referencia de etapa 1. Se reutilizan las dependencias fijadas; se implementa paginación de 12 registros sin búsqueda ni filtros. Descripción y notas admiten hasta 1000 caracteres cada una y nombre hasta 120, conservando el límite de cuerpo de 8 KB. Etiquetas, imágenes y video se incorporarán en la etapa 3.

### Presentación visual acordada (18 de noviembre de 2026)

El docente solicita que todos los diagramas, imágenes y capturas se preparen en modo oscuro. Los SVG se exportarán con tema oscuro fijo en lugar de automático; también las imágenes PNG y las capturas de interfaz. Se aplica al material nuevo y a sus actualizaciones, incluida la corrección de las exportaciones de guía 2. Las evidencias históricas de pruebas de ambos temas se conservan como historial, sin reutilizar sus versiones claras en entregas o publicaciones.


### Acuerdos de la etapa 3 (19 de noviembre de 2026)

El docente autoriza implementar imágenes y detalle completo en `gpb-dev/guia-03`, redactar y reproducir la guía en copia aislada, y preparar diagramas y material para el sitio. Se conservan guía 1, guía 2 y la referencia raíz. No se autorizan commits ni publicaciones por este inicio. La publicación del sitio requiere fecha editorial y autorización posteriores; Canvas se prepara para copiar tras confirmar los datos de sesión y el foro, sin publicar ni incluirlo en commits.

Etiquetas: máximo 20, de 1 a 30 caracteres tras recortar espacios; duplicados sin distinguir mayúsculas. Imágenes: originales hasta 5 MiB y 25 megapíxeles, sin animación, normalizados a WebP de hasta 2400 × 2400. Dos cargas por proceso y bloqueo persistente por Gunpla. Diario privado en MongoDB para recursos pendientes, eliminación lógica durante la limpieza, reintentos al iniciar y cada minuto y comando manual. Una operación externa de borrado por pasada y registro; incertidumbre de subida conservada durante al menos 24 h. Son decisiones de consistencia y control de recursos de esta etapa, sin adelantar funciones de etapas posteriores.
