# GPB — guía 3: imágenes y detalle completo

Proyecto independiente derivado de `guia-02`. Conserva las versiones anteriores y la aplicación raíz. JavaScript ES Modules, interfaz oscura y documentos en español.

Desde esta carpeta:

```sh
pnpm install --frozen-lockfile
cp server/.env.example server/.env
chmod 600 server/.env
```

Configura privadamente MongoDB, un SESSION_SECRET propio y las tres variables CLOUDINARY del ejemplo. No copies ni publiques credenciales. La colección funciona sin Cloudinary; la subida informa 503 hasta configurarlo.

```sh
pnpm --filter @gpb/server seed:catalogs
pnpm dev:server
# Otra terminal desde esta misma carpeta:
pnpm dev:client
```

Abrir http://localhost:5173. Puertos 3000/5173 libres; detener otras versiones antes de iniciar ésta.

```sh
pnpm check
pnpm build
pnpm test
pnpm test:transport
pnpm --filter @gpb/server check:atlas
pnpm --filter @gpb/server check:collection:atlas
pnpm --filter @gpb/server check:images:atlas
pnpm --filter @gpb/server images:cleanup
```

El verificador de imágenes usa cuentas temporales y recursos propios, y los limpia al finalizar. `node --env-file=.env scripts/check-images-atlas.js --provider-memory`, desde `server`, comprueba Atlas real con Cloudinary simulado; no equivale a comprobar el proveedor real. `images:cleanup` realiza una pasada de limpieza, con código 2 si quedan tareas pendientes. El servidor también reintenta al arrancar y cada minuto.

Una portada y ocho imágenes adicionales; JPG, PNG o WebP, hasta 5 MiB por original. Se comprueba el contenido real y se normaliza a WebP. Dos cargas simultáneas por proceso y bloqueo por Gunpla. Diario persistente para limpieza y recuperación; los recursos con resultado incierto se reintentan durante al menos 24 horas. Una eliminación externa por pasada y registro; puede ser necesario esperar varias pasadas. Los registros eliminados permanecen ocultos mientras se limpian y se purgan al terminar. Los fallos no se descartan.

Etiquetas: hasta 20 de 30 caracteres; recortadas, no vacías ni duplicadas sin distinguir mayúsculas. YouTube: enlaces HTTPS válidos y reproductor generado desde el identificador; nunca HTML arbitrario. Un enlace válido no garantiza disponibilidad del video.

Estado y resultados detallados en `../../docs/etapas/03/`. Las pruebas locales usan adaptadores de memoria y reemplazan las respuestas de imágenes/video externos. El transporte Electron es preparatorio; no se ha creado un paquete. Dashboard, búsqueda/filtros, Render y empaquetado conservan sus etapas previstas.
