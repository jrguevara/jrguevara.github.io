// Adaptadores exclusivos de pruebas: Atlas usa los modelos reales.
import { GRADE_NAMES, SCALE_NAMES } from '../src/catalogs.js';
const hex = (value) => value.toString(16).padStart(24, '0');
export function memoryCollection() {
  const grades = GRADE_NAMES.map((name, i) => ({ id: hex(i + 1), name }));
  const scales = SCALE_NAMES.map((name, i) => ({ id: hex(i + 101), name }));
  const records = new Map();
  let sequence = 1000;
  const view = (doc) => {
    const { owner: _owner, ...data } = doc;
    return { ...data, grade: grades.find((g) => g.id === doc.grade), scale: scales.find((s) => s.id === doc.scale) };
  };
  return {
    records,
    catalogs: { async list() { return { grades, scales }; }, async valid(g, s) { return grades.some((x) => x.id === g) && scales.some((x) => x.id === s); } },
    gunpla: {
      async list(owner, page) {
        const all = [...records.values()].filter((doc) => doc.owner === owner && !doc.deleted).reverse();
        return { items: all.slice((page - 1) * 12, page * 12).map(view), total: all.length, page, pageSize: 12, pages: Math.max(1, Math.ceil(all.length / 12)) };
      },
      async get(owner, id) { const doc = records.get(id); return doc?.owner === owner && !doc.deleted ? view(doc) : null; },
      async create(owner, data) { const id = hex(sequence++); const doc = { cover: null, gallery: [], mediaJobs: [], ...data, owner, id, _id: id, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }; records.set(id, doc); return view(doc); },
      async update(owner, id, data) { const doc = records.get(id); if (doc?.owner !== owner || doc.deleted) return null; Object.assign(doc, data, { updatedAt: new Date().toISOString() }); return view(doc); },
      async remove(owner, id) { return records.get(id)?.owner === owner && records.delete(id); },
    },
  };
}
