import mongoose from 'mongoose';

export const STATES = ['Sin armar', 'En progreso', 'Armado'];
const image = new mongoose.Schema({ publicId: String, url: String }, { _id: false });
const job = new mongoose.Schema({ publicId: String, createdAt: { type: Date, default: Date.now }, settled: { type: Boolean, default: false } }, { _id: false });
const schema = new mongoose.Schema({
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, immutable: true },
  name: { type: String, required: true, trim: true, maxlength: 120 },
  grade: { type: mongoose.Schema.Types.ObjectId, ref: 'Grade', required: true },
  scale: { type: mongoose.Schema.Types.ObjectId, ref: 'Scale', required: true },
  description: { type: String, trim: true, maxlength: 1000, default: '' },
  notes: { type: String, trim: true, maxlength: 1000, default: '' },
  tags: { type: [String], default: [] },
  youtubeId: { type: String, default: '' },
  cover: { type: image, default: null },
  gallery: { type: [image], default: [] },
  mediaJobs: { type: [job], default: [] },
  mediaLock: { token: String, until: Date },
  deleted: { type: Boolean, default: false },
  state: { type: String, enum: STATES, required: true, default: 'Sin armar' },
}, { timestamps: true });
schema.index({ owner: 1, createdAt: -1, _id: -1 });
export const Gunpla = mongoose.model('Gunpla', schema);
const populate = (query) => query.populate('grade', 'name').populate('scale', 'name').lean();
export function publicGunpla(doc) {
  const option = (value) => value ? { id: String(value._id), name: value.name } : null;
  return { id: String(doc._id), name: doc.name, grade: option(doc.grade), scale: option(doc.scale),
    cover: doc.cover || null, gallery: doc.gallery || [], tags: doc.tags || [], youtubeId: doc.youtubeId || '',
    description: doc.description, notes: doc.notes, state: doc.state, createdAt: doc.createdAt, updatedAt: doc.updatedAt };
}
export const gunpla = {
  async list(owner, page) {
    const filter = { owner, deleted: { $ne: true } };
    const [docs, total] = await Promise.all([
      populate(Gunpla.find(filter).sort({ createdAt: -1, _id: -1 }).skip((page - 1) * 12).limit(12)),
      Gunpla.countDocuments(filter),
    ]);
    return { items: docs.map(publicGunpla), total, page, pageSize: 12, pages: Math.max(1, Math.ceil(total / 12)) };
  },
  async get(owner, id) {
    const doc = await populate(Gunpla.findOne({ _id: id, owner, deleted: { $ne: true } }));
    return doc ? publicGunpla(doc) : null;
  },
  async create(owner, input) {
    const doc = await Gunpla.create({ ...input, owner });
    return this.get(owner, doc._id);
  },
  async update(owner, id, input) {
    const doc = await populate(Gunpla.findOneAndUpdate({ _id: id, owner, deleted: { $ne: true } }, { $set: input }, { returnDocument: 'after', runValidators: true }));
    return doc ? publicGunpla(doc) : null;
  },
  async remove(owner, id) { return Boolean(await Gunpla.findOneAndDelete({ _id: id, owner, deleted: { $ne: true } })); },
};
