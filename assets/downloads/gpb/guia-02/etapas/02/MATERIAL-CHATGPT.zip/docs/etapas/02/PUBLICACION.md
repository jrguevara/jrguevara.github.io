# Publicación de la guía 2

Fecha: 18 de noviembre de 2026. Publicación autorizada por el docente en este chat.

## Resultado

[Guía 2 — Gestión de la colección](https://jrguevara.github.io/posts/gpb-guia-02-gestion-de-la-coleccion/) publicada y consultada después del despliegue, HTTP 200. Los 15 bloques de archivo del HTML público coinciden con los de la guía reproducida; la compresión del sitio elimina comentarios HTML, por lo que la comparación se hizo sobre el texto de los bloques pre, no sobre marcadores invisibles.

Los 13 destinos únicos de imágenes, diagramas y descargas enlazados en el artículo respondieron HTTP 200; incluye dos HTML interactivos, dos PNG/SVG de diagramas, captura de colección y material técnico/código. La guía 1 se conservó sin cambios.

## Versiones y procesos

- GPB: commits 86f4719 (implementación) y e7ebbb7 (guía, diagramas y reproducción), enviados a origin/main de https://github.com/jrguevara/MERN-electron.git. El cierre documental se conserva en un commit posterior, consultable con git log.
- Sitio: commit de publicación d2cc3cc83b4b4f5a941263633e5b475567179684, enviado a origin/main de https://github.com/jrguevara/jrguevara.github.io.git. Los informes técnicos descargables reciben después la actualización de cierre/limpieza; no cambia el código de la guía.
- [Automatic build](https://github.com/jrguevara/jrguevara.github.io/actions/runs/44328035974): completed / success para d2cc3cc.
- [GitHub Pages](https://github.com/jrguevara/jrguevara.github.io/actions/runs/44328169947): completed / success para la rama generada a0f0cc44.

## Verificación local previa

Se usaron Ruby 3.2.2 y gems existentes; bundle check aprobado. Jekyll compiló en producción y HTML-Proofer revisó 130 archivos sin errores, con las mismas opciones de comprobación del flujo del sitio. No se cambiaron Gemfile, lock, tema, configuración, Ruby global ni workflow.

La entrada conserva metadatos, categorías/tags, tabla de contenido, filtros relative_url y protección raw de los bloques de código, siguiendo guía 1. Revisión en navegador: imágenes cargadas, dos enlaces interactivos, escritorio y móvil sin desbordamiento horizontal; capturas en capturas/blog-*.png.

La publicación corresponde al material docente. La API/web de GPB en Render y el paquete macOS todavía pertenecen a las etapas 5/6. No se publicó ninguna credencial ni se adelantó ese despliegue.
