# Capturas de formularios y CRUD — guía 2

19 de noviembre de 2026. Siete capturas de `gpb-dev/guia-02` en modo oscuro y con datos ficticios, obtenidas con `node /private/tmp/gpb-capturas-app-guia2.mjs`. La interfaz React utiliza la API local de pruebas con los adaptadores de memoria existentes, iniciada con `node tests/local-api.js`; cliente con su Vite+ local. No se accedió a servicios remotos ni cuentas personales.

Se crearon tres registros desde el formulario, se consultaron tarjetas y detalle, se editaron estado/notas y se confirmó la eliminación de uno. Se comprobó el mensaje de éxito, la ausencia de la tarjeta y el 404 de su consulta posterior. La vista móvil se capturó a 390×844 y la de escritorio a 1440×1000; sin desbordamientos. No se adelantaron imágenes, etiquetas, video ni otras funcionalidades de guía 3.

- `capturas/app-crud/coleccion-crud.png`: Colección en tarjetas.
- `capturas/app-crud/formulario-crear.png`: Crear un Gunpla.
- `capturas/app-crud/detalle-crud.png`: Consultar el detalle.
- `capturas/app-crud/formulario-editar.png`: Editar el registro.
- `capturas/app-crud/confirmar-eliminacion.png`: Confirmar la eliminación.
- `capturas/app-crud/coleccion-eliminada.png`: Comprobar la eliminación.
- `capturas/app-crud/coleccion-crud-movil.png`: Vista móvil.

Los procesos y el navegador temporales se cerraron al finalizar; los registros de memoria desaparecieron. COMPROBACION.json conserva el resumen sin datos de sesión. Los bloques de código de la guía y del artículo permanecen idénticos. Las capturas se añaden a la sección 4.1; el tema del blog proporciona la ampliación de las imágenes y cada pie incluye un enlace al PNG completo.

Se inspeccionaron visualmente las siete capturas oscuras. La compilación de Jekyll y HTML-Proofer aprobaron 134 archivos. La sección renderizada se comprobó en escritorio y móvil: las siete imágenes cargan, conservan proporciones y no desbordan el ancho. El primer intento del verificador visual usó por error el sufijo de URL de guía 3; se corrigió a gestion-de-la-coleccion y se repitió la comprobación sobre guía 2.
