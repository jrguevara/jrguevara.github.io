# GPB — guía 2: gestión de la colección

Proyecto independiente derivado de `guia-01`; ejecutar comandos desde esta carpeta. Requiere las versiones fijadas y una configuración privada propia en `server/.env`, basada en `.env.example`. No se copian credenciales de otra entrega.

```sh
pnpm install --frozen-lockfile
pnpm --filter @gpb/server seed:catalogs
pnpm dev:server
# Otra terminal, misma carpeta:
pnpm dev:client
```

Abrir http://localhost:5173. Detener otras versiones antes de usar los puertos 3000/5173.

```sh
pnpm check
pnpm build
pnpm test
pnpm test:transport
pnpm --filter @gpb/server check:atlas
pnpm --filter @gpb/server check:collection:atlas
```

Incluye catálogos de MongoDB, CRUD privado por usuario, validación, tarjetas, formulario compartido, detalle básico y paginación de 12. Las imágenes, etiquetas y video corresponden a guía 3; estadísticas y búsqueda/filtros a guía 4. La prueba Electron sigue siendo preparatoria.

Los informes de la entrega están en `../../docs/etapas/02/`; la guía en `../../docs/guias/02-GESTION-DE-LA-COLECCION.md`.
