import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture } from './helpers.js';
import { memoryCollection } from './collection-helpers.js';
import { IDLE_MS } from '../src/app.js';
async function setup(t) {
  const f = await fixture(memoryCollection()); t.after(f.close);
  async function account(suffix) {
    const c = f.client(); await c.call('/auth/csrf');
    assert.equal((await c.call('/auth/register', { method: 'POST', body: { username: 'piloto_' + suffix, email: suffix + '@example.com', password: 'Clave de prueba 123!' } })).status, 201);
    return c;
  }
  const a = await account('a'), b = await account('b');
  const { data } = await a.call('/catalogs');
  const input = { name: 'RX-78-2', grade: data.grades[1].id, scale: data.scales[0].id };
  return { ...f, a, b, input };
}
test('catálogos protegidos, completos y ordenados; colección vacía', async (t) => {
  const f = await setup(t);
  assert.equal((await f.client().call('/catalogs')).status, 401);
  assert.equal((await f.client().call('/gunpla')).status, 401);
  const { data } = await f.a.call('/catalogs');
  assert.equal(data.grades.length, 12); assert.equal(data.scales.length, 5);
  assert.equal(data.grades[0].name, 'Entry Grade (EG)'); assert.equal(data.grades[11].name, 'Sin Grado');
  assert.deepEqual(data.scales.map((s) => s.name), ['1/144', '1/100', '1/60', '1/48', 'Sin Escala']);
  assert.equal((await f.a.call('/gunpla')).data.total, 0);
});
test('crear, consultar, editar y eliminar; estado inicial y textos recortados', async (t) => {
  const { a, input } = await setup(t);
  const created = await a.call('/gunpla', { method: 'POST', body: { ...input, name: ' RX-78-2 ' } });
  assert.equal(created.status, 201); const item = created.data.gunpla;
  assert.equal(item.name, 'RX-78-2'); assert.equal(item.state, 'Sin armar'); assert.equal(item.owner, undefined);
  assert.ok(item.createdAt); assert.ok(item.updatedAt);
  assert.equal((await a.call('/gunpla/' + item.id)).data.gunpla.grade.name, 'High Grade (HG)');
  assert.equal((await a.call('/gunpla/' + item.id, { method: 'PUT', body: { ...input, state: 'Armado', notes: ' Listo ' } })).data.gunpla.notes, 'Listo');
  assert.equal((await a.call('/gunpla/' + item.id, { method: 'DELETE' })).status, 204);
  assert.equal((await a.call('/gunpla/' + item.id)).status, 404);
});
test('un segundo usuario no lista, consulta, edita ni elimina registros ajenos', async (t) => {
  const { a, b, input } = await setup(t);
  const id = (await a.call('/gunpla', { method: 'POST', body: input })).data.gunpla.id;
  assert.equal((await b.call('/gunpla')).data.total, 0);
  for (const method of ['GET', 'PUT', 'DELETE']) assert.equal((await b.call('/gunpla/' + id, { method, ...(method === 'PUT' ? { body: { ...input, name: 'Robado' } } : {}) })).status, 404);
  assert.equal((await a.call('/gunpla/' + id)).data.gunpla.name, input.name);
});
test('rechaza referencias inexistentes, tipos y campos adicionales, textos largos y estados inválidos', async (t) => {
  const { a, input } = await setup(t);
  for (const body of [{}, { ...input, name: ' ' }, { ...input, name: 'x'.repeat(121) }, { ...input, grade: 'bad' }, { ...input, scale: 'f'.repeat(24) }, { ...input, grade: { $ne: null } }, { ...input, state: 'Pintado' }, { ...input, description: 'x'.repeat(1001) }, { ...input, notes: [] }, { ...input, owner: '1' }, { ...input, createdAt: 'ayer' }, { ...input, cover: 'url' }]) {
    assert.equal((await a.call('/gunpla', { method: 'POST', body })).status, 400);
  }
  assert.equal((await a.call('/gunpla/no-es-id')).status, 400);
  for (const query of ['page=0','page=-1','page=1.5','page=abc','page=1&page=2','owner=otro']) assert.equal((await a.call('/gunpla?' + query)).status, 400);
  assert.equal((await a.call('/gunpla')).data.total, 0);
});
test('paginación de 12 sin registros de otro usuario', async (t) => {
  const { a, b, input } = await setup(t);
  for (let i = 0; i < 13; i++) await a.call('/gunpla', { method: 'POST', body: { ...input, name: 'Modelo ' + i } });
  await b.call('/gunpla', { method: 'POST', body: input });
  const first = (await a.call('/gunpla')).data, second = (await a.call('/gunpla?page=2')).data;
  assert.equal(first.total, 13); assert.equal(first.items.length, 12); assert.equal(first.pages, 2); assert.equal(second.items.length, 1);
  assert.equal(first.items[0].name, 'Modelo 12'); assert.equal(second.items[0].name, 'Modelo 0');
});
test('CSRF, origen, caducidad y revocación protegen las operaciones nuevas', async (t) => {
  const f = await setup(t); const { a, input } = f;
  const id = (await a.call('/gunpla', { method: 'POST', body: input })).data.gunpla.id;
  for (const headers of [{ 'x-csrf-token': '' }, { origin: 'https://ajeno.example' }]) {
    for (const [method, path] of [['POST', '/gunpla'], ['PUT', '/gunpla/' + id], ['DELETE', '/gunpla/' + id]]) assert.equal((await a.call(path, { method, body: input, headers })).status, 403);
  }
  f.advance(IDLE_MS - 1); assert.equal((await a.call('/gunpla')).status, 200);
  f.advance(1); assert.equal((await a.call('/gunpla/' + id)).status, 401);
  await f.b.call('/auth/logout', { method: 'POST' });
  assert.equal((await f.b.call('/gunpla')).status, 401);
});
