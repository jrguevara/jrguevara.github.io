# GPB · Etapa 5: alojamiento y configuración de producción

Versión independiente que continúa desde `../guia-04`. Incluye una plantilla para dos servicios Render y una pantalla de espera al establecer la primera conexión.

## Ejecutar en desarrollo

Desde esta carpeta, con Node.js 26.13.1 y pnpm 12.18.0:

```sh
pnpm install --frozen-lockfile
cp -n server/.env.example server/.env
```

Configura `server/.env` localmente con los valores propios según la guía 3. Carga los catálogos con `pnpm --filter @gpb/server seed:catalogs`. Ejecuta `pnpm dev:server` y `pnpm dev:client` en terminales separadas y abre [GPB en localhost](http://localhost:5173).

## Comprobar

- `pnpm check` y `pnpm build` revisan y compilan React.
- `pnpm test` comprueba la API Express con adaptadores en memoria.
- `pnpm test:transport` requiere Chromium para Playwright, el binario Electron y puertos 3000 y 5173 libres. Levanta sus propios procesos de prueba.
- `node server/scripts/check-exploration-mongo.js 37104` comprueba el repositorio con una instancia MongoDB **local y desechable** de prueba que escuche en ese puerto. Usa y elimina una base exclusiva con nombre aleatorio.

- `pnpm exec playwright test -c playwright.https.config.js` requiere una compilación previa con `pnpm build`, Chromium instalado, OpenSSL y los puertos libres 3000, 5173 y 5443. Comprueba la app compilada tras un proxy HTTPS local con certificado efímero y datos ficticios.

## Preparar Render

El Blueprint está en `gpb-dev/guia-05/render.yaml`. Las instrucciones de configuración, la prueba del mismo origen en Render y el plan de diagnóstico están en [DESPLIEGUE.md](../../docs/etapas/05/DESPLIEGUE.md).

[Registro y traspaso](../../docs/etapas/05/REGISTRO.md)
