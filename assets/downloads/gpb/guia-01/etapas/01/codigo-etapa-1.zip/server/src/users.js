import mongoose from 'mongoose';

const schema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  passwordHash: { type: String, required: true, select: false },
}, { timestamps: true });
export const User = mongoose.model('User', schema);
export const users = {
  create: (data) => User.create(data),
  byEmail: (email) => User.findOne({ email }).select('+passwordHash'),
  byId: (id) => User.findById(id),
};
export const publicUser = (user) => ({ id: String(user._id), username: user.username, email: user.email });
