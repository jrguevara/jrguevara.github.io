// Verificación real opcional. Usa colecciones temporales con sufijo aleatorio y las elimina al terminar.
import mongoose from 'mongoose';
import MongoStore from 'connect-mongo';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { createApp } from '../src/app.js';
import { readConfig } from '../src/config.js';
import { User } from '../src/users.js';

let connection, server;
const suffix = randomBytes(6).toString('hex');
const collections = [`gpb_probe_users_${suffix}`, `gpb_probe_sessions_${suffix}`];
try {
  const config = readConfig();
  connection = await mongoose.createConnection(config.MONGODB_URI, { serverSelectionTimeoutMS: 10000 }).asPromise();
  const ProbeUser = connection.model('ProbeUser', User.schema.clone(), collections[0]);
  await ProbeUser.init();
  const users = { create: (data) => ProbeUser.create(data), byEmail: (email) => ProbeUser.findOne({ email }).select('+passwordHash'), byId: (id) => ProbeUser.findById(id) };
  const start = async () => {
    const store = MongoStore.create({ client: connection.getClient(), collectionName: collections[1] });
    store.on('error', () => {});
    server = createApp({ config: { ...config, NODE_ENV: 'test' }, store, users }).listen(0, '127.0.0.1');
    await new Promise((resolve) => server.once('listening', resolve));
    return `http://127.0.0.1:${server.address().port}/api/auth`;
  };
  let base = await start(), cookie = '', csrf = '';
  const call = async (action, body) => {
    const response = await fetch(`${base}/${action}`, { method: body ? 'POST' : 'GET', headers: { cookie, origin: config.WEB_ORIGIN, 'content-type': 'application/json', 'x-csrf-token': csrf }, body: body ? JSON.stringify(body) : undefined });
    const set = response.headers.get('set-cookie'); if (set) cookie = set.split(';')[0];
    const data = response.status === 204 ? null : await response.json(); if (data?.csrfToken) csrf = data.csrfToken;
    return { status: response.status, data };
  };
  await call('csrf');
  const account = { username: `probe_${suffix}`, email: `${suffix}@example.com`, password: randomBytes(24).toString('hex') };
  assert.equal((await call('register', account)).status, 201);
  const saved = await users.byEmail(account.email); assert.match(saved.passwordHash, /^\$argon2id\$/);
  assert.equal((await call('register', account)).status, 409);
  const persistentCookie = cookie;
  await new Promise((resolve) => server.close(resolve));
  base = await start(); cookie = persistentCookie;
  assert.equal((await call('me')).data.user.username, account.username);
  await call('csrf'); assert.equal((await call('logout', {})).status, 204);
  cookie = persistentCookie; assert.equal((await call('me')).status, 401);
  const info = await connection.db.admin().serverInfo();
  console.log(`Atlas comprobado: MongoDB ${info.version}; índices únicos, hash, sesión tras reiniciar la API y revocación correctos.`);
} catch (error) {
  const category = ['ENOTFOUND', 'EAI_AGAIN', 'ESERVFAIL'].includes(error.code) ? 'DNS del servidor Atlas' : error.code === 18 ? 'autenticación Atlas' : error.issues ? 'variables de entorno' : 'conexión o verificación';
  console.error(`Etapa pendiente: ${category}.`);
  console.error('Comprobación Atlas no completada. Revisa conexión, variables y permisos locales. No se muestran datos privados.');
  process.exitCode = 1;
} finally {
  if (server?.listening) await new Promise((resolve) => server.close(resolve));
  if (connection?.readyState === 1) {
    for (const name of collections) {
      try { await connection.dropCollection(name); } catch (error) { if (error.code !== 26) { console.error('Quedó pendiente limpiar una colección temporal gpb_probe.'); process.exitCode = 1; } }
    }
    await connection.close();
  }
}
