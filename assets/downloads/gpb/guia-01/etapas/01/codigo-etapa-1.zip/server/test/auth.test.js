import test from 'node:test';
import assert from 'node:assert/strict';
import argon2 from 'argon2';
import { fixture } from './helpers.js';
import { IDLE_MS, ABSOLUTE_MS } from '../src/app.js';

const account = { username: 'piloto', email: 'piloto@example.com', password: 'Clave de prueba 123!' };
async function register(c, data = account) {
  await c.call('/auth/csrf');
  return c.call('/auth/register', { method: 'POST', body: data });
}
test('registro, hash Argon2id, regeneración, identidad y revocación', async (t) => {
  const f = await fixture(); t.after(f.close);
  const a = f.client(); await a.call('/auth/csrf'); const anonymous = a.cookie;
  const result = await a.call('/auth/register', { method: 'POST', body: account });
  assert.equal(result.status, 201); assert.notEqual(a.cookie, anonymous);
  assert.equal(result.data.user.passwordHash, undefined);
  const stored = f.users.records.get('1');
  assert.match(stored.passwordHash, /^\$argon2id\$/); assert.ok(await argon2.verify(stored.passwordHash, account.password));
  assert.equal((await a.call('/auth/me')).data.user.email, account.email);
  assert.match(result.headers.get('set-cookie'), /HttpOnly/); assert.match(result.headers.get('set-cookie'), /SameSite=Lax/);
  const oldCookie = a.cookie;
  assert.equal((await a.call('/auth/logout', { method: 'POST' })).status, 204);
  assert.equal((await a.call('/auth/me', { headers: { cookie: oldCookie } })).status, 401);
  await a.call('/auth/csrf');
  assert.equal((await a.call('/auth/login', { method: 'POST', body: { email: account.email, password: 'incorrecta' } })).status, 401);
  assert.equal((await a.call('/auth/login', { method: 'POST', body: { email: account.email, password: account.password } })).status, 200);
});
test('validación, duplicados, CSRF y dos identidades aisladas', async (t) => {
  const f = await fixture(); t.after(f.close);
  const a = f.client(), b = f.client();
  assert.equal((await a.call('/auth/register', { method: 'POST', body: account })).status, 403);
  await a.call('/auth/csrf');
  assert.equal((await a.call('/auth/register', { method: 'POST', body: { ...account, password: 'corta' } })).status, 400);
  assert.equal((await register(a)).status, 201);
  assert.equal((await register(b)).status, 409);
  assert.equal((await register(b, { ...account, username: 'otro' })).status, 409);
  assert.equal((await register(b, { ...account, email: 'otro@example.com' })).status, 409);
  assert.equal((await register(b, { ...account, username: 'otro', email: 'otro@example.com' })).status, 201);
  assert.notEqual((await a.call('/auth/me')).data.user.id, (await b.call('/auth/me')).data.user.id);
  assert.equal((await a.call('/auth/logout', { method: 'POST', headers: { origin: 'https://externo.example' } })).status, 403);
  assert.equal((await a.call('/auth/logout', { method: 'POST', headers: { 'x-csrf-token': 'x' } })).status, 403);
});
test('lecturas no renuevan inactividad; actividad explícita sí', async (t) => {
  const f = await fixture(); t.after(f.close); const a = f.client(); await register(a);
  f.advance(IDLE_MS - 1000); assert.equal((await a.call('/auth/me')).status, 200);
  f.advance(1000); assert.equal((await a.call('/auth/me')).status, 401);
  await register(a, { ...account, username: 'nuevo', email: 'nuevo@example.com' });
  f.advance(IDLE_MS - 1000); assert.equal((await a.call('/auth/activity', { method: 'POST' })).status, 204);
  f.advance(1000); assert.equal((await a.call('/auth/me')).status, 200);
});
test('el límite absoluto vence aunque exista actividad', async (t) => {
  const f = await fixture({ idleMs: ABSOLUTE_MS * 2 }); t.after(f.close); const a = f.client(); await register(a);
  f.advance(ABSOLUTE_MS - 1); assert.equal((await a.call('/auth/activity', { method: 'POST' })).status, 204);
  f.advance(1); assert.equal((await a.call('/auth/me')).status, 401);
});
test('límites de intentos y cuerpo JSON inválido', async (t) => {
  const f = await fixture({ authLimit: 2 }); t.after(f.close); const a = f.client(); await a.call('/auth/csrf');
  for (let i = 0; i < 2; i++) assert.equal((await a.call('/auth/login', { method: 'POST', body: {} })).status, 400);
  assert.equal((await a.call('/auth/login', { method: 'POST', body: {} })).status, 429);
  const response = await fetch(f.base + '/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{' });
  assert.equal(response.status, 400);
});
test('cookie Secure en producción detrás del proxy HTTPS y rechazo de cuerpos grandes', async (t) => {
  const f = await fixture({ config: { NODE_ENV: 'production', SESSION_SECRET: 'prueba-segura-'.repeat(4), WEB_ORIGIN: 'https://gpb.example.com' } });
  t.after(f.close); const a = f.client();
  const result = await a.call('/auth/csrf', { headers: { 'x-forwarded-proto': 'https' } });
  assert.match(result.headers.get('set-cookie'), /; Secure/);
  assert.match(result.headers.get('set-cookie'), /Path=\/api/);
  assert.equal((await a.call('/auth/register', { method: 'POST', body: account, headers: { origin: 'https://gpb.example.com', 'x-forwarded-proto': 'https' } })).status, 201);
  const response = await fetch(f.base + '/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ large: 'x'.repeat(9000) }) });
  assert.equal(response.status, 413);
});
