import { test, expect, _electron as electron } from '@playwright/test';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

test('transporte controlado Electron conserva y revoca sesión al reiniciar', async () => {
  const profile = await mkdtemp(join(tmpdir(), 'gpb-electron-'));
  const options = { args: ['electron/session-probe.js'], env: { ...process.env, GPB_PROBE_PROFILE: profile, GPB_PROBE_API: 'http://127.0.0.1:3000', GPB_PROBE_WEB_ORIGIN: 'http://localhost:5173' } };
  let desktop = await electron.launch(options);
  const call = (action, body) => desktop.evaluate((_electron, values) => globalThis.gpbProbe(values.action, values.body), { action, body });
  try {
    expect((await call('csrf')).status).toBe(200);
    expect((await call('register', { username: 'piloto_electron', email: 'electron@example.com', password: 'Clave de prueba 123!' })).status).toBe(201);
    await desktop.close(); desktop = await electron.launch(options);
    expect((await call('me')).user.username).toBe('piloto_electron');
    await call('csrf'); expect((await call('logout')).status).toBe(204);
    await desktop.close(); desktop = await electron.launch(options);
    expect((await call('me')).status).toBe(401);
  } finally { await desktop.close(); await rm(profile, { recursive: true, force: true }); }
});
