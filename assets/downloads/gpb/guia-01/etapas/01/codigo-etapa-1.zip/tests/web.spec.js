import { test, expect, chromium } from '@playwright/test';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

test('registro, reinicio de navegador, login y cierre con cookies de terceros bloqueadas', async () => {
  const profile = await mkdtemp(join(tmpdir(), 'gpb-web-'));
  const options = { headless: true, ...(process.env.GPB_BROWSER_CHANNEL ? { channel: process.env.GPB_BROWSER_CHANNEL } : {}), args: ['--test-third-party-cookie-phaseout'], viewport: { width: 1280, height: 800 } };
  let context = await chromium.launchPersistentContext(profile, options);
  try {
    let page = await context.newPage();
    await page.goto('http://localhost:5173/');
    await expect(page).toHaveURL(/login/);
    if (process.env.GPB_CAPTURE_DIR) {
      await page.getByRole('button', { name: 'Iniciar sesión', exact: true }).waitFor();
      await page.screenshot({ path: join(process.env.GPB_CAPTURE_DIR, 'acceso.png') });
      await page.setViewportSize({ width: 390, height: 844 });
      await page.screenshot({ path: join(process.env.GPB_CAPTURE_DIR, 'acceso-movil.png'), fullPage: true });
      await page.setViewportSize({ width: 1280, height: 800 });
    }
    await page.getByRole('link', { name: 'Regístrate' }).click();
    await page.getByLabel('Nombre de usuario').fill('piloto_web');
    await page.getByLabel('Correo electrónico').fill('web@example.com');
    await page.getByLabel('Contraseña', { exact: true }).fill('Clave de prueba 123!');
    await page.getByRole('button', { name: 'Crear cuenta', exact: true }).click();
    await expect(page.getByRole('heading', { name: 'Hola, piloto_web.' })).toBeVisible();
    const cookie = (await context.cookies()).find((c) => c.name === 'gpb.sid');
    expect(cookie.httpOnly).toBe(true); expect(cookie.expires).toBeGreaterThan(Date.now() / 1000);
    await context.close();
    context = await chromium.launchPersistentContext(profile, options);
    page = await context.newPage(); await page.goto('http://localhost:5173/');
    await expect(page.getByRole('heading', { name: 'Hola, piloto_web.' })).toBeVisible();
    await page.getByRole('link', { name: 'Mi colección', exact: true }).click();
    await expect(page.getByRole('heading', { name: 'Mi colección' })).toBeVisible();
    await page.getByRole('button', { name: 'Cerrar sesión' }).click();
    await expect(page).toHaveURL(/login/);
    await page.reload(); await expect(page.getByRole('button', { name: 'Iniciar sesión', exact: true })).toBeVisible();
    await page.getByLabel('Correo electrónico').fill('web@example.com');
    await page.getByLabel('Contraseña', { exact: true }).fill('incorrecta');
    await page.getByRole('button', { name: 'Iniciar sesión', exact: true }).click();
    await expect(page.getByRole('alert')).toContainText('Correo o contraseña incorrectos.');
    await page.getByLabel('Contraseña', { exact: true }).fill('Clave de prueba 123!');
    await page.getByRole('button', { name: 'Iniciar sesión', exact: true }).click();
    await expect(page.getByRole('heading', { name: 'Hola, piloto_web.' })).toBeVisible();
    await page.setViewportSize({ width: 390, height: 844 });
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  } finally { await context.close(); await rm(profile, { recursive: true, force: true }); }
});
