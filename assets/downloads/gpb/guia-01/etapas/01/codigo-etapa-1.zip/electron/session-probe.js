// Preparativo de etapa 1. No empaqueta ni integra React (etapa 6).
import { app, BrowserWindow, session } from 'electron';
app.setPath('userData', process.env.GPB_PROBE_PROFILE);
app.whenReady().then(async () => {
  const transport = session.fromPartition('persist:gpb-session-probe');
  const origin = new URL(process.env.GPB_PROBE_API);
  if (!['http:', 'https:'].includes(origin.protocol) || origin.pathname !== '/') throw new Error('Origen de prueba inválido');
  const allowed = new Map([
    ['csrf', 'GET'], ['me', 'GET'], ['register', 'POST'], ['login', 'POST'], ['logout', 'POST'], ['activity', 'POST'],
  ]);
  let csrfToken;
  // Sólo proceso principal y controlador de pruebas; ninguna cookie se entrega al renderer.
  // Fetch nativo de Node + almacén persistente de Electron: no cambia CORP/CORS de la API.
  globalThis.gpbProbe = async (action, body) => {
    if (!allowed.has(action)) throw new Error('Acción no permitida');
    const method = allowed.get(action);
    const url = new URL(`/api/auth/${action}`, origin).href;
    const cookies = await transport.cookies.get({ url, name: 'gpb.sid' });
    const response = await fetch(url, {
      method, redirect: 'error', signal: AbortSignal.timeout(15000),
      headers: {
        Origin: process.env.GPB_PROBE_WEB_ORIGIN,
        Cookie: cookies.map(({ name, value }) => `${name}=${value}`).join('; '),
        ...(body ? { 'Content-Type': 'application/json' } : {}),
        ...(method === 'POST' ? { 'X-CSRF-Token': csrfToken } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    // El contrato de la API es una única cookie host-only, Path=/api, HttpOnly, SameSite=Lax.
    // No se aceptan cookies de otros nombres, dominios o rutas.
    for (const header of response.headers.getSetCookie()) {
      const [pair, ...attributes] = header.split(';').map((part) => part.trim());
      const separator = pair.indexOf('=');
      if (pair.slice(0, separator) !== 'gpb.sid') continue;
      const fields = new Map(attributes.map((field) => { const i = field.indexOf('='); return i < 0 ? [field.toLowerCase(), true] : [field.slice(0, i).toLowerCase(), field.slice(i + 1)]; }));
      if (fields.has('domain') || fields.get('path') !== '/api' || !fields.has('httponly') || String(fields.get('samesite')).toLowerCase() !== 'lax') throw new Error('Cookie fuera del contrato');
      const expirationDate = Date.parse(fields.get('expires')) / 1000;
      if (!Number.isFinite(expirationDate)) throw new Error('Cookie sin vencimiento');
      if (expirationDate <= Date.now() / 1000) await transport.cookies.remove(url, 'gpb.sid');
      else await transport.cookies.set({ url, name: 'gpb.sid', value: pair.slice(separator + 1), path: '/api', httpOnly: true, secure: fields.has('secure'), sameSite: 'lax', expirationDate });
    }
    await transport.cookies.flushStore();
    const data = response.status === 204 ? null : await response.json();
    if (data?.csrfToken) csrfToken = data.csrfToken;
    return { status: response.status, user: data?.user };
  };
  const window = new BrowserWindow({ show: false, webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true } });
  window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  window.webContents.on('will-navigate', (event) => event.preventDefault());
  await window.loadURL('about:blank');
});
