# GPB — Gunpla Personal Builds

Etapa 1: configuración y autenticación. Interfaz y API independientes, JavaScript ES Modules.

Requisitos comprobados: Node.js 26.13.1, pnpm 12.18.0, macOS arm64. Desde la raíz:

```sh
pnpm install --frozen-lockfile
pnpm check
pnpm build
pnpm test
```

Crear `server/.env` usando `server/.env.example` y completar los valores privados de Atlas. No añadir secretos al cliente.

```sh
pnpm --filter @gpb/server check:atlas
# Verificación completa con navegador; puertos 3000 y 5173 libres:
pnpm --filter @gpb/server check:web:atlas
pnpm dev:server
```

En otra terminal desde la raíz:

```sh
pnpm dev:client
```

Abrir http://localhost:5173. El cliente utiliza `/api` bajo el mismo origen mediante el proxy local. La API escucha en 127.0.0.1:3000 en desarrollo. En producción requiere origen HTTPS y proxy confiable; aún no está desplegada.

Pruebas independientes de Atlas (puertos 3000 y 5173 libres):

```sh
pnpm exec playwright install chromium
pnpm exec install-electron
pnpm test:transport
```

Usan cuentas y perfiles temporales; no usan el perfil personal del navegador. Electron aquí sólo prueba el transporte de sesiones. No es todavía la aplicación de escritorio.

Consultar [estado](docs/ESTADO.md), [registro](docs/etapas/01/REGISTRO.md), [fuentes oficiales](docs/etapas/01/FUENTES.md) y [traspaso para ChatGPT](docs/etapas/01/TRASPASO-CHATGPT.md). Atlas y el flujo web están comprobados. La [guía 1 final](docs/guias/01-CONFIGURACION-Y-AUTENTICACION.md) ya fue reproducida en una copia aislada; consulta el [informe de verificación](docs/etapas/01/VERIFICACION.md). La publicación espera indicaciones del docente.
