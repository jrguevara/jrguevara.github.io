import { createContext, useContext, useEffect, useState } from "react";
import { api, csrf, resetCsrf } from "@/lib/api";

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  async function loadSession() {
    try {
      await csrf();
      setUser((await api("/auth/me")).user);
    } catch (failure) {
      if (failure.status !== 401) setError(failure.message);
      setUser(null);
    } finally {
      setLoading(false);
    }
  }
  function refresh() {
    setLoading(true);
    setError("");
    return loadSession();
  }
  useEffect(() => {
    let active = true;
    csrf()
      .then(() => api("/auth/me"))
      .then((data) => {
        if (active) setUser(data.user);
      })
      .catch((failure) => {
        if (active && failure.status !== 401) setError(failure.message);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);
  useEffect(() => {
    if (!user) return;
    let lastSent = 0;
    const expire = (failure) => {
      if (failure.status === 401) setUser(null);
    };
    const activity = (event) => {
      if (
        !event.isTrusted ||
        document.visibilityState !== "visible" ||
        Date.now() - lastSent < 60000
      )
        return;
      lastSent = Date.now();
      api("/auth/activity", { method: "POST" }).catch(expire);
    };
    const check = () => api("/auth/me").catch(expire);
    const timer = setInterval(check, 60000);
    window.addEventListener("pointerdown", activity);
    window.addEventListener("keydown", activity);
    window.addEventListener("focus", check);
    return () => {
      clearInterval(timer);
      window.removeEventListener("pointerdown", activity);
      window.removeEventListener("keydown", activity);
      window.removeEventListener("focus", check);
    };
  }, [user]);
  async function authenticate(mode, data) {
    const result = await api(`/auth/${mode}`, { method: "POST", body: data });
    setUser(result.user);
  }
  async function logout() {
    await api("/auth/logout", { method: "POST" });
    resetCsrf();
    setUser(null);
  }
  return (
    <AuthContext.Provider value={{ user, loading, error, refresh, authenticate, logout }}>
      {children}
    </AuthContext.Provider>
  );
}
