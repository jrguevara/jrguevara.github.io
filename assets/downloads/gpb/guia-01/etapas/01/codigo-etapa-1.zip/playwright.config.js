import { defineConfig } from '@playwright/test';
export default defineConfig({
  testDir: './tests', testMatch: '*.spec.js', workers: 1,
  use: { baseURL: 'http://localhost:5173', trace: 'off', screenshot: 'off', video: 'off' },
  webServer: [
    { command: 'node tests/local-api.js', url: 'http://127.0.0.1:3000/api/health', reuseExistingServer: false },
    { command: 'pnpm dev:client', url: 'http://localhost:5173', reuseExistingServer: false },
  ],
});
