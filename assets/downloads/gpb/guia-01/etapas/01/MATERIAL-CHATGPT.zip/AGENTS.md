# GPB — instrucciones del proyecto

## Referencias y alcance

- Leer `PLANIFICACION.md` antes de implementar una etapa. Es la referencia de decisiones del producto; una instrucción posterior del docente prevalece y debe reflejarse allí.
- Mantener seis entregas progresivas. Implementar la etapa solicitada y los preparativos necesarios, sin adelantar funcionalidades de otras etapas sin necesidad.
- La evaluación es independiente y no pertenece a las seis guías. No exigir una demostración para Windows o Linux.
- Todo el código del proyecto será JavaScript con ES Modules. La interfaz y los documentos docentes estarán en español.

## Arquitectura

- Cliente React con Vite+, shadcn/ui, Tailwind CSS y gráficos de Recharts.
- API Express y Mongoose independiente del cliente y del paquete de Electron.
- MongoDB Atlas para datos y sesiones; Cloudinary para imágenes; Render para web y API.
- Directorios previstos: `client/`, `server/`, `electron/` y `docs/`. Crear cada uno cuando tenga contenido real.
- Electron empaquetará el cliente para macOS Apple Silicon, sin incluir el servidor ni sus credenciales.
- Conservar los límites de sesión y de imágenes, la propiedad de los registros y los catálogos definidos en la planificación.

## Flujo de implementación y documentación

- Para desarrollar una entrega, usar `.agents/skills/gpb-desarrollar-etapa/SKILL.md`.
- Para revisar y reproducir una guía de ChatGPT, usar `.agents/skills/gpb-verificar-guia/SKILL.md`.
- Registrar comandos reales con su carpeta de ejecución, versiones, archivos y resultados en `docs/etapas/NN/REGISTRO.md`.
- Al introducir herramientas, incluir descripción, motivo de uso en GPB, enlace oficial Getting Started, requisitos, instalación y comprobación de versión y funcionamiento. Aplicar el formato de PLANIFICACION.md tanto al traspaso como a la revisión de guías; registrar fuentes y fecha de consulta. No inventar comandos de versión para paquetes sin CLI.
- Preparar para ChatGPT un material de traspaso vinculado al código comprobado de esa etapa, incluyendo los archivos nuevos y los cambios respecto a la anterior. ChatGPT redactará la guía; no presentar el registro técnico como la guía final.
- Las correcciones derivadas de una reproducción deben reflejarse tanto en el código como en el material de la guía.
- No afirmar que una entrega funciona si sus comprobaciones siguen pendientes. Distinguir comprobado, pendiente y bloqueado por un recurso externo.
- Usar puntos de control de Git cuando esté disponible. No crear commits, etiquetas o publicaciones por el solo hecho de documentarlos como recomendación.

## Herramientas y comprobaciones

- Verificar las versiones de referencia antes de instalarlas. Fijar versiones exactas y conservar el archivo de bloqueo de pnpm una vez comprobado el conjunto.
- No cambiar globalmente Node.js ni gestores de paquetes para adaptar el equipo al proyecto. Preferir una configuración por proyecto.
- Documentar comandos de desarrollo, compilación y pruebas cuando existan; actualmente no hay aplicación ni comandos de ejecución configurados.
- Comprobar aislamiento entre usuarios, expiración y revocación de sesión, entradas inválidas y límites de imágenes con pruebas significativas cuando se implementen.
- Probar el transporte de sesión con la topología web/API/Electron desde la primera etapa; no asumir disponibilidad de cookies de terceros.
- Las pruebas del despliegue real y del paquete se registrarán separadamente de las pruebas locales.
- No registrar credenciales, cookies, tokens ni datos privados en documentación, capturas o archivos versionados. Usar `.env.example` sin secretos.

## Situación inicial

La etapa de preparación contiene planificación, instrucciones y skills. El desarrollo funcional de la guía 1 aún no está completado. Consultar `docs/ESTADO.md` para conocer el punto de continuación.
