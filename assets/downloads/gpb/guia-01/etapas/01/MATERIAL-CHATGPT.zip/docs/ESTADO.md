# Estado de GPB

Actualizado: 12 de noviembre de 2026.

## Etapa 1 — configuración y autenticación

**Guía 1 final y reproducida desde la preparación. Técnicamente lista para grabar; publicación pendiente de indicaciones del docente.**

- Cliente React JavaScript con Vite+, Tailwind y componentes shadcn/ui: formularios oscuros, navegación y rutas protegidas.
- API Express/Mongoose independiente: registro, login, logout, Argon2id, sesiones connect-mongo, CSRF, validación y límites.
- Entorno confirmado: Node 26.13.1, pnpm 12.18.0, Vite+ global/local 1.6.0, macOS arm64. Versiones exactas y lock raíz conservados; sin modificaciones globales.
- Comprobados localmente: instalación congelada, revisión sin advertencias, compilación, 6/6 pruebas API y 2/2 pruebas de transporte Chromium/Electron.
- Atlas MongoDB 8.0.37: conexión, índices únicos, hash, persistencia de sesión al reiniciar API y revocación correctos.
- Flujo real React → proxy Vite+ → API → Atlas comprobado: registro, hash persistido, navegador y API reiniciados, navegación, rechazo de contraseña incorrecta, nuevo acceso y cierre. Cuenta y sesiones exclusivas de prueba eliminadas, perfiles temporales eliminados y procesos detenidos.
- Prueba Electron preparatoria aprobada; la integración completa de React y el paquete corresponden a etapa 6.
- Guía reproducida desde preparación en copia aislada, transcribiendo sus 33 bloques: instalación congelada, API/cliente, recorrido de navegador con Atlas, check, build, 6/6 pruebas API, 2/2 de transporte y ambos verificadores Atlas aprobados. Informe en docs/etapas/01/VERIFICACION.md.
- Repositorio Git inicializado por el docente en la raíz, rama main. Primer commit de la etapa 1 autorizado; su identificador se consulta con `git log -1 --oneline`. No se crearon etiquetas ni publicaciones. Fuentes conservadas con inventario SHA-256; ninguna copia incluye server/.env ni secretos.

## Continuación

1. Guía final: `docs/guias/01-CONFIGURACION-Y-AUTENTICACION.md`. Código de aplicación de referencia: commit 9900285. Reproducción completa registrada en `docs/etapas/01/VERIFICACION.md`.
2. El docente autorizó expresamente la reproducción después de revisar la guía. El bloqueo previo de aprobación quedó resuelto; no se requieren más pruebas para cerrar la entrega 1.
3. Esperar las indicaciones del docente antes de publicar. No se crearon commits adicionales, etiquetas ni publicaciones durante la redacción/verificación.
4. La etapa 2 se iniciará cuando el docente lo solicite. No se han adelantado funciones de colección, imágenes ni estadísticas.

## Material disponible

- docs/guias/01-CONFIGURACION-Y-AUTENTICACION.md: versión final comprobada y lista para grabar.
- docs/etapas/01/VERIFICACION.md: entorno, secuencia ejecutada, resultados, diferencias y limpieza de la reproducción.

- docs/etapas/01/REGISTRO.md: comandos reales, versiones, historial de diagnósticos y resultados finales.
- docs/etapas/01/FUENTES.md: herramientas con descripción, motivo, Getting Started, requisitos y comprobaciones.
- docs/etapas/01/TRASPASO-CHATGPT.md: encargo de redacción, incrementos y adjuntos precisos.
- docs/etapas/01/capturas/: acceso en escritorio y móvil sin datos privados.
- docs/etapas/01/codigo-etapa-1.zip e INVENTARIO-SHA256.txt: fuentes conservadas.
- docs/etapas/01/MATERIAL-CHATGPT.zip: material actualizado con fuentes, documentación, guía final e informe de verificación; sin secretos.

## Uso local

Desde raíz, con server/.env privado configurado: `pnpm dev:server` y, en otra terminal raíz, `pnpm dev:client`. Abrir http://localhost:5173. Las herramientas de comprobación de Atlas son `pnpm --filter @gpb/server check:atlas` y `pnpm --filter @gpb/server check:web:atlas`; la segunda levanta y detiene API y cliente y requiere los puertos 3000/5173 libres.

## Pruebas posteriores separadas

Publicación real y HTTPS Render: etapa 5. Interfaz completa de Electron y paquete macOS Apple Silicon: etapa 6. La evaluación es independiente de las seis guías.
