const id = "[a-f0-9]{24}";
const collection = new RegExp(`^/gunpla/${id}$`);
const upload = new RegExp(`^/gunpla/${id}/(?:cover|gallery)$`);
const removal = new RegExp(`^/gunpla/${id}/(?:cover|gallery/[\\w-]+(?:%2F[\\w-]+)*)$`, "i");
const queries = new Set(["page", "q", "grade", "scale", "state"]);

export function getAction(request) {
  const { path, method, body } = request ?? {};
  if (typeof path !== "string" || path.length > 1500) return;
  const [route, query, extra] = path.split("?");
  if (extra !== undefined || (query !== undefined &&
      (route !== "/gunpla" || method !== "GET" ||
        [...new URLSearchParams(query).keys()].some((key) => !queries.has(key))))) return;

  if (method === "GET" && body === undefined &&
      (["/health", "/auth/me", "/catalogs", "/dashboard", "/gunpla"].includes(route) ||
       collection.test(route))) return { path, method };

  if (method === "POST" && upload.test(route)) {
    const { bytes, name, type } = body ?? {};
    if (!(bytes instanceof ArrayBuffer) || !bytes.byteLength || bytes.byteLength > 5 * 1024 * 1024 ||
        typeof name !== "string" || name.length > 255 || /[/\\\x00-\x1f\x7f]/.test(name) ||
        !["image/jpeg", "image/png", "image/webp"].includes(type)) return;
    const form = new FormData();
    form.set("image", new Blob([bytes], { type }), name);
    return { path, method, body: form };
  }

  if (body === undefined &&
      ((method === "DELETE" && (collection.test(route) || removal.test(route))) ||
       (method === "POST" && ["/auth/logout", "/auth/activity"].includes(route)))) {
    return { path, method };
  }

  if ((method === "POST" && ["/auth/register", "/auth/login", "/gunpla"].includes(route)) ||
      (method === "PUT" && collection.test(route))) {
    if (typeof body === "string" && Buffer.byteLength(body) <= 8192) return { path, method, body };
  }
}
