import { app, BrowserWindow, ipcMain, net, protocol, session, shell } from "electron";
import { resolve, sep } from "node:path";
import { pathToFileURL } from "node:url";
import { getAction } from "./actions.js";
import { createSessionApi } from "./session-api.js";

const appPage = "gpb://app/index.html";
const appId = "io.github.jrguevara.gpb";
const youtube = "https://www.youtube-nocookie.com";
const cloudinary = "https://res.cloudinary.com";
const apiOrigin = "https://gpb-jrguevara-api.onrender.com";
const webOrigin = "https://gpb-web.onrender.com";

protocol.registerSchemesAsPrivileged([{ scheme: "gpb", privileges: { standard: true, secure: true } }]);
let window;

function allowedExternal(url) {
  const target = new URL(url);
  return !target.username && !target.password && target.origin === cloudinary &&
    /^\/[\w-]+\/image\/upload\//.test(target.pathname);
}

function createWindow() {
  window = new BrowserWindow({
    width: 1200, height: 850, minWidth: 360, minHeight: 550, backgroundColor: "#111318",
    webPreferences: {
      preload: resolve(app.getAppPath(), "electron/preload.cjs"),
      contextIsolation: true, nodeIntegration: false, sandbox: true, webviewTag: false,
    },
  });
  const contents = window.webContents;
  contents.setWindowOpenHandler(({ url, disposition }) => {
    if (["foreground-tab", "background-tab"].includes(disposition) && allowedExternal(url)) {
      void shell.openExternal(url).catch(() => {});
    }
    return { action: "deny" };
  });
  contents.on("will-navigate", (event) => event.preventDefault());
  contents.on("will-redirect", (event) => {
    if (event.isMainFrame || new URL(event.url).origin !== youtube) event.preventDefault();
  });
  contents.on("will-frame-navigate", (event) => {
    if (event.isMainFrame || new URL(event.url).origin !== youtube) event.preventDefault();
  });
  window.on("closed", () => { window = undefined; });
  void window.loadURL(appPage);
}

app.whenReady().then(() => {
  const files = resolve(app.getAppPath(), "client/dist");
  protocol.handle("gpb", async (request) => {
    const url = new URL(request.url);
    const filename = resolve(files, `.${url.pathname}`);
    if (request.method !== "GET" || url.host !== "app" || !filename.startsWith(files + sep) ||
        (url.pathname !== "/index.html" && !/^\/assets\/[\w.-]+$/.test(url.pathname))) {
      return new Response(null, { status: 404 });
    }
    const response = await net.fetch(pathToFileURL(filename).href);
    const headers = new Headers(response.headers);
    headers.set("Content-Security-Policy", [
      "default-src 'none'", "script-src 'self'", "style-src 'self' 'unsafe-inline'",
      `img-src 'self' data: ${cloudinary}`, "font-src 'self'",
      `frame-src ${youtube}`, "base-uri 'none'", "form-action 'none'", "object-src 'none'",
    ].join("; "));
    return new Response(response.body, { status: response.status, headers });
  });

  const renderer = session.defaultSession;
  renderer.setPermissionRequestHandler((_contents, _permission, callback) => callback(false));
  renderer.setPermissionCheckHandler(() => false);
  renderer.webRequest.onBeforeSendHeaders({ urls: [`${youtube}/embed/*`] }, (details, callback) => {
    if (details.webContentsId === window?.webContents.id && details.resourceType === "subFrame") {
      details.requestHeaders.Referer = `https://${appId}/`;
    }
    callback({ requestHeaders: details.requestHeaders });
  });

  const transport = createSessionApi({
    cookies: session.fromPartition("persist:gpb-api").cookies, apiOrigin, webOrigin,
  });
  ipcMain.handle("gpb:request", (event, request) => {
    const frame = event.senderFrame;
    if (event.sender !== window?.webContents || !frame || frame.parent ||
        frame.url.split("#")[0] !== appPage) {
      throw new Error("Remitente de GPB inválido.");
    }
    const action = getAction(request);
    if (!action) throw new Error("Acción de GPB no permitida.");
    return transport(action);
  });
  createWindow();
  app.on("activate", () => { if (!window) createWindow(); });
});

app.on("window-all-closed", () => { if (process.platform !== "darwin") app.quit(); });
