const cookieName = "gpb.sid";

export function createSessionApi({ cookies, apiOrigin, webOrigin }) {
  let csrfToken;
  let pending = Promise.resolve();

  async function saveCookie(response, url) {
    for (const header of response.headers.getSetCookie()) {
      const [pair, ...attributes] = header.split(";").map((entry) => entry.trim());
      const prefix = `${cookieName}=`;
      if (!pair.startsWith(prefix)) continue;
      const fields = new Map(attributes.map((entry) => {
        const index = entry.indexOf("=");
        return index < 0
          ? [entry.toLowerCase(), true]
          : [entry.slice(0, index).toLowerCase(), entry.slice(index + 1)];
      }));
      const secure = new URL(url).protocol === "https:";
      const expirationDate = Date.parse(fields.get("expires")) / 1000;
      if (fields.has("domain") || fields.get("path") !== "/api" || !fields.has("httponly") ||
          String(fields.get("samesite")).toLowerCase() !== "lax" ||
          fields.has("secure") !== secure || !Number.isFinite(expirationDate)) {
        throw new Error("Cookie fuera del contrato de GPB.");
      }
      if (expirationDate <= Date.now() / 1000) await cookies.remove(url, cookieName);
      else await cookies.set({
        url, name: cookieName, value: pair.slice(prefix.length), path: "/api",
        httpOnly: true, sameSite: "lax", secure, expirationDate,
      });
      await cookies.flushStore();
    }
  }

  async function send({ path, method, body }) {
    const url = new URL(`/api${path}`, apiOrigin).href;
    const health = path === "/health";
    const stored = health ? [] : await cookies.get({ url, name: cookieName });
    const response = await fetch(url, {
      method, body, redirect: "error",
      signal: AbortSignal.timeout(health ? 12000 : body instanceof FormData ? 60000 : 20000),
      headers: {
        Origin: webOrigin,
        ...(stored.length ? { Cookie: stored.map(({ name, value }) => `${name}=${value}`).join("; ") } : {}),
        ...(typeof body === "string" ? { "Content-Type": "application/json" } : {}),
        ...(method !== "GET" && csrfToken ? { "X-CSRF-Token": csrfToken } : {}),
      },
    });
    if (!health) await saveCookie(response, url);
    const data = response.status === 204 ? null : await response.json();
    if ([401, 403].includes(response.status) || path === "/auth/logout") csrfToken = undefined;
    if (data && Object.hasOwn(data, "csrfToken")) {
      csrfToken = data.csrfToken;
      delete data.csrfToken;
    }
    return { status: response.status, data };
  }

  return (action) => {
    if (action.path === "/health") return send(action);
    // Ordena la rotación de cookie y del token frente a lecturas y escrituras simultáneas.
    const result = pending.then(async () => {
      if (action.method !== "GET" && !csrfToken) {
        const response = await send({ path: "/auth/csrf", method: "GET" });
        if (!csrfToken) return response;
      }
      return send(action);
    });
    pending = result.catch(() => {});
    return result;
  };
}
