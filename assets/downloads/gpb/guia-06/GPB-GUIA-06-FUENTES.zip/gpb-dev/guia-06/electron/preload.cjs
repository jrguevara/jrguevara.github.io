// El sandbox de Electron carga el preload como CommonJS.
const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("gpbDesktop", {
  request: (action) => ipcRenderer.invoke("gpb:request", action),
});
