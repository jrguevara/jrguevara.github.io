import { defineConfig } from '@playwright/test';

const origin = 'https://localhost:5443';
export default defineConfig({
  testDir: './tests',
  testMatch: ['production.spec.js', 'collection.spec.js', 'images.spec.js', 'dashboard.spec.js'],
  workers: 1,
  use: { baseURL: origin, ignoreHTTPSErrors: true, launchOptions: { args: ['--test-third-party-cookie-phaseout'] }, trace: 'off', screenshot: 'off', video: 'off' },
  webServer: [
    { command: 'node tests/local-api.js', env: { GPB_TEST_WEB_ORIGIN: origin }, url: 'http://127.0.0.1:3000/api/health' },
    { command: 'pnpm --filter @gpb/client preview', url: 'http://localhost:5173' },
    { command: 'node tests/local-https.js', url: origin, ignoreHTTPSErrors: true },
  ],
});
