import mongoose from 'mongoose';
import MongoStore from 'connect-mongo';
import { ZodError } from 'zod';
import { readConfig } from './config.js';
import { users, User } from './users.js';
import { catalogs, Grade, Scale } from './catalogs.js';
import { gunpla, Gunpla } from './gunpla.js';
import { mediaRepository } from './media-repository.js';
import { mediaService } from './media-service.js';
import { cloudinaryProvider } from './cloudinary.js';
import { createApp } from './app.js';

let startupStep = 'validar las variables de entorno';
try {
  const config = readConfig();
  startupStep = 'conectar con MongoDB';
  await mongoose.connect(config.MONGODB_URI, { serverSelectionTimeoutMS: 10000 });
  startupStep = 'preparar los índices de MongoDB';
  await Promise.all([User.init(), Grade.init(), Scale.init(), Gunpla.init()]); // Esperar los índices únicos antes de aceptar registros.
  startupStep = 'preparar las sesiones y el proveedor de imágenes';
  const store = MongoStore.create({ client: mongoose.connection.getClient(), collectionName: 'sessions', ttl: 7 * 24 * 60 * 60, touchAfter: 0 });
  store.on('error', () => console.error('No se pudo acceder al almacén de sesiones.'));
  const media = mediaService({ repository: mediaRepository, gunpla, provider: cloudinaryProvider(config) });
  let cleaning = false;
  async function clean() {
    if (cleaning) return;
    cleaning = true;
    try { const result = await media.reconcile(); if (result.pending) console.warn('Hay limpiezas de imágenes pendientes; se reintentarán.'); }
    catch { console.warn('No se pudo completar la limpieza de imágenes; se reintentará.'); }
    finally { cleaning = false; }
  }
  const timer = setInterval(clean, 60000); timer.unref();
  void clean();
  startupStep = 'iniciar Express';
  const server = createApp({ config, store, users, catalogs, gunpla, media }).listen(config.PORT, config.NODE_ENV === 'production' ? '0.0.0.0' : '127.0.0.1', () => console.log(`API GPB disponible en el puerto ${config.PORT}`));
  for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => {
    clearInterval(timer);
    server.close(async () => { await mongoose.disconnect(); process.exit(0); });
  });
} catch (error) {
  console.error(`No se pudo iniciar GPB al ${startupStep}.`);
  if (startupStep === 'validar las variables de entorno') {
    if (error instanceof ZodError) {
      const fields = [...new Set(error.issues.map(({ path }) => path[0]))];
      console.error(`Variables ausentes o inválidas: ${fields.join(', ')}.`);
    } else {
      console.error(error.message);
    }
  }
  process.exitCode = 1;
}
