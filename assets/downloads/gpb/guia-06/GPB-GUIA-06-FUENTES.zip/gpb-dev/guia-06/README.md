# GPB · Etapa 6 de escritorio

Esta copia continúa la guía 5. GPB carga la compilación de React en Electron y conecta con la API de Render por HTTPS. Para usar la aplicación de escritorio se necesita conexión a Internet y una cuenta de GPB.

## Ejecutar y empaquetar

Desde `gpb-dev/guia-06` en un Mac Apple Silicon con Node.js 26.13.1 y pnpm 12.18.0:

```sh
pnpm install --frozen-lockfile
pnpm exec install-electron
pnpm exec electron --version
pnpm exec electron-builder --version
pnpm desktop
pnpm package:mac
```

Cierra la ventana de desarrollo y sal de GPB con **⌘Q** antes de ejecutar el último comando. El DMG y el ZIP de práctica aparecen en `release/`. Monta el DMG y arrastra **GPB** a Aplicaciones, o descomprime el ZIP y abre **GPB.app**. El paquete conserva la firma ad hoc del binario y carece de firma Developer ID y de notarización para distribución pública. [Instalación y resultados](../../docs/etapas/06/REGISTRO.md) · [Apple y Gatekeeper](https://support.apple.com/es-es/102445)

## Comprobar

- `pnpm check`, `pnpm build` y `pnpm test` revisan React y prueban Express.
- `pnpm test:transport` y `pnpm exec playwright test -c playwright.https.config.js` requieren Chromium de Playwright y los puertos libres 3000, 5173 y 5443. Para el recorrido HTTPS, ejecuta antes `pnpm build` y ten OpenSSL disponible.
- `node tests/check-desktop.js release/mac-arm64/GPB.app/Contents/MacOS/GPB` comprueba el paquete con un perfil temporal y una API local en memoria. Requiere el puerto 3000 libre y usa dobles para Cloudinary y YouTube.
- Para recorrer el entorno alojado, abre el paquete y accede con una cuenta de GPB. Crea un Gunpla, añade portada, galería y un video, cierra y vuelve a abrir GPB y comprueba que siga la sesión. Elimina los datos de prueba y cierra sesión.

El cliente web mantiene las rutas y el proxy de la [guía 5](../../docs/etapas/05/DESPLIEGUE.md). Se conserva `render.yaml` como referencia al despliegue de esa guía.

[Traspaso a ChatGPT](../../docs/etapas/06/TRASPASO-CHATGPT.md)
