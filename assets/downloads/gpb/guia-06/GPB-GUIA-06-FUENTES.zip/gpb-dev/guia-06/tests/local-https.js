// Terminación TLS para probar dist y la API en memoria. Sólo escucha en loopback.
import { execFileSync } from 'node:child_process';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { request } from 'node:http';
import { createServer } from 'node:https';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const tlsDirectory = mkdtempSync(join(tmpdir(), 'gpb-tls-'));
let tls;
try {
  const key = join(tlsDirectory, 'key.pem');
  const cert = join(tlsDirectory, 'cert.pem');
  execFileSync('openssl', ['req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-days', '1',
    '-subj', '/CN=localhost', '-addext', 'subjectAltName=DNS:localhost', '-keyout', key, '-out', cert],
  { stdio: 'ignore' });
  tls = { key: readFileSync(key), cert: readFileSync(cert) };
} finally {
  rmSync(tlsDirectory, { recursive: true, force: true });
}

createServer(tls, (req, res) => {
  const api = /^\/api(?:\/|\?|$)/.test(req.url);
  const upstream = request({
    hostname: '127.0.0.1', port: api ? 3000 : 5173, path: req.url, method: req.method,
    headers: { ...req.headers, 'x-forwarded-proto': 'https' },
  }, (response) => {
    res.writeHead(response.statusCode, response.headers);
    response.pipe(res);
  });
  upstream.on('error', () => { res.writeHead(502); res.end(); });
  req.pipe(upstream);
}).listen(5443, '127.0.0.1');
