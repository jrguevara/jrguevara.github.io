// Sólo pruebas de transporte; nunca es un sustituto de Atlas en producción.
import session from '../server/node_modules/express-session/index.js';
import { createApp } from '../server/src/app.js';
import { memoryMedia } from '../server/test/media-helpers.js';
import { memoryUsers } from '../server/test/helpers.js';
const config = { NODE_ENV: process.env.GPB_TEST_WEB_ORIGIN ? 'production' : 'test', WEB_ORIGIN: process.env.GPB_TEST_WEB_ORIGIN ?? 'http://localhost:5173', SESSION_SECRET: 'pruebas-locales-sin-secretos-reales-123456789' };
const server = createApp({ config, store: new session.MemoryStore(), users: memoryUsers(), ...memoryMedia(), authLimit: 200 }).listen(3000, '127.0.0.1', () => console.log('API aislada de prueba disponible'));
process.on('SIGTERM', () => server.close());
