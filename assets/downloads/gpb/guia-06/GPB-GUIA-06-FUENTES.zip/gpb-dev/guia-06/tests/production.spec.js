import { expect, test } from '@playwright/test';
import { join } from 'node:path';

test('HTTPS de mismo origen, reactivación, sesión segura y CSRF', async ({ page, context }) => {
  let healthCalls = 0;
  await page.route('**/api/health', (route) => {
    healthCalls++;
    return healthCalls === 1
      ? route.fulfill({ status: 503, contentType: 'text/html', body: '<p>Servicio iniciando</p>' })
      : route.continue();
  });
  const folder = process.env.GPB_PRODUCTION_CAPTURES;
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.goto('/registro');
  await expect(page.getByRole('status')).toContainText('Si el servicio estaba en pausa');
  if (folder) {
    await page.screenshot({ path: join(folder, 'reactivacion-escritorio.png') });
    await page.setViewportSize({ width: 390, height: 844 });
    await page.screenshot({ path: join(folder, 'reactivacion-movil.png') });
  }
  await expect(page.getByLabel('Nombre de usuario')).toBeVisible();
  if (folder) await page.screenshot({ path: join(folder, 'registro-movil.png') });
  await page.getByLabel('Nombre de usuario').fill('piloto_https');
  expect(healthCalls).toBe(2);
  await page.getByLabel('Correo electrónico').fill('piloto_https@example.com');
  await page.getByLabel('Contraseña', { exact: true }).fill('Clave de prueba 123!');
  const registered = page.waitForResponse('**/api/auth/register');
  await page.getByRole('button', { name: 'Crear cuenta', exact: true }).click();
  const response = await registered;
  expect(response.status()).toBe(201);
  expect((await response.request().allHeaders()).origin).toBe(new URL(page.url()).origin);
  const cookie = (await context.cookies()).find(({ name }) => name === 'gpb.sid');
  expect(cookie).toMatchObject({ domain: 'localhost', path: '/api', secure: true, httpOnly: true, sameSite: 'Lax' });
  expect(cookie.expires).toBeGreaterThan(Date.now() / 1000);

  await page.goto('/coleccion/nuevo');
  await expect(page.getByLabel('Grado', { exact: true }).locator('option')).toHaveCount(13);
  await expect(page.getByLabel('Escala', { exact: true }).locator('option')).toHaveCount(6);
  const csrfResponse = await context.request.get('/api/auth/csrf');
  const { csrfToken } = await csrfResponse.json();
  expect(csrfResponse.headers()['cache-control']).toBe('no-store');
  const route = '/api/auth/logout';
  expect((await context.request.post(route, {
    headers: { origin: new URL(page.url()).origin },
  })).status()).toBe(403);
  expect((await context.request.post(route, {
    headers: { origin: 'https://externo.example', 'x-csrf-token': csrfToken },
  })).status()).toBe(403);

  await page.getByRole('button', { name: 'Cerrar sesión' }).click();
  await expect(page).toHaveURL(/\/login$/);
  if (folder) await page.screenshot({ path: join(folder, 'acceso-movil.png') });
  expect((await context.request.get('/api/auth/me')).status()).toBe(401);
  expect((await context.request.get('/api/auth/me', {
    headers: { cookie: `gpb.sid=${cookie.value}` },
  })).status()).toBe(401);
  await page.getByLabel('Correo electrónico').fill('piloto_https@example.com');
  await page.getByLabel('Contraseña', { exact: true }).fill('Clave de prueba 123!');
  await page.getByRole('button', { name: 'Iniciar sesión', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'Hola, piloto_https.' })).toBeVisible();
});

test('límite de espera y reintento manual con la API disponible', async ({ page }) => {
  await page.clock.install();
  let available = false;
  await page.route('**/api/health', (route) => available
    ? route.continue()
    : route.fulfill({ status: 503, contentType: 'text/html', body: '<p>Servicio iniciando</p>' }));

  await page.setViewportSize({ width: 1440, height: 1000 });
  const firstProbe = page.waitForResponse('**/api/health');
  await page.goto('/login');
  expect((await firstProbe).status()).toBe(503);
  await page.clock.fastForward(91_000);
  await expect(page.getByRole('alert')).toContainText('GPB todavía no responde');

  const folder = process.env.GPB_PRODUCTION_CAPTURES;
  if (folder) {
    await page.screenshot({ path: join(folder, 'reintentar-escritorio.png') });
    await page.setViewportSize({ width: 390, height: 844 });
    await page.screenshot({ path: join(folder, 'reintentar-movil.png') });
  }

  available = true;
  await page.getByRole('button', { name: 'Reintentar conexión' }).click();
  await expect(page.getByRole('button', { name: 'Iniciar sesión', exact: true })).toBeVisible();
});
