import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { resolve } from "node:path";
import { spawn } from "node:child_process";
import { createRequire } from "node:module";
import { _electron as electron, expect } from "@playwright/test";

const sharp = createRequire(new URL("../server/package.json", import.meta.url))("sharp");
const image = await sharp({
  create: { width: 640, height: 400, channels: 3, background: "#284763" },
}).png().toBuffer();
const profile = await mkdtemp(resolve(tmpdir(), "gpb06-"));
const binary = process.argv[2];
const remote = process.env.GPB_REMOTE_REGISTER === "1";
const video = process.env.GPB_REAL_VIDEO === "1";
const username = remote ? `gpb06_${randomUUID().slice(0, 12)}` : "prueba_escritorio";
const password = remote ? randomUUID() : "Clave de prueba 123!";
const origin = "https://gpb-web.onrender.com";
let server;
let desktop;
let recordPath;
let playerIssue;

async function start() {
  desktop = await electron.launch({
    ...(binary ? { executablePath: resolve(binary) } : {}),
    args: [...(binary ? [] : ["."]), `--user-data-dir=${profile}`],
  });
  if (server) {
    // Redirige sólo el transporte principal al doble de API. El paquete queda intacto.
    await desktop.evaluate(() => {
      const original = globalThis.fetch;
      globalThis.fetch = (input, options) => {
        const url = new URL(input);
        if (url.origin !== "https://gpb-jrguevara-api.onrender.com") return original(input, options);
        return original(`http://127.0.0.1:3000${url.pathname}${url.search}`, {
          ...options, headers: { ...options.headers, "X-Forwarded-Proto": "https" },
        });
      };
    });
  }
  const page = await desktop.firstWindow();
  if (server) {
    await page.route("https://res.cloudinary.com/**", (route) =>
      route.fulfill({ contentType: "image/png", body: image }));
  }
  if (video) {
    page.on("requestfailed", (request) => {
      if (request.url().startsWith("https://www.youtube-nocookie.com/embed/")) {
        console.log("Petición del iframe:", request.failure()?.errorText);
      }
    });
  } else {
    await page.route("https://www.youtube-nocookie.com/**", (route) => route.fulfill({
      contentType: "text/html",
      body: '<body style="background:#111318;color:#eee">Reproductor de prueba</body>',
    }));
  }
  return page;
}

const button = (page, name) => page.getByRole("button", { name, exact: true });
const link = (page, name) => page.getByRole("link", { name, exact: true });
const label = (page, name) => page.getByLabel(name, { exact: true });
const heading = (page, name) => page.getByRole("heading", { name, exact: true });

try {
  if (!remote) {
    server = spawn(process.execPath, ["tests/local-api.js"], {
      env: { ...process.env, GPB_TEST_WEB_ORIGIN: origin }, stdio: ["ignore", "pipe", "inherit"],
    });
    await new Promise((done, reject) => {
      server.stdout.once("data", done);
      server.once("exit", (code) => reject(new Error(`API local terminó con estado ${code}`)));
      server.once("error", reject);
    });
  }
  let page = await start();
  await expect(button(page, "Iniciar sesión")).toBeVisible({ timeout: 95000 });
  assert.equal(await page.evaluate(() => typeof window.require), "undefined");
  assert.equal(await page.evaluate(() => document.cookie), "");
  assert.equal(await page.evaluate(() => window.gpbDesktop.request({
    path: "/auth/csrf", method: "GET",
  }).then(() => false, () => true)), true);
  await link(page, "Regístrate").click();
  await label(page, "Nombre de usuario").fill(username);
  await label(page, "Correo electrónico").fill(`${username}@example.com`);
  await label(page, "Contraseña").fill(password);
  await button(page, "Crear cuenta").click();
  await expect(link(page, "Mi colección")).toBeVisible();
  await desktop.close();
  page = await start();
  await expect(link(page, "Mi colección")).toBeVisible({ timeout: 95000 });
  console.log("Sesión conservada después de reiniciar Electron.");

  await link(page, "Mi colección").click();
  await link(page, "Agregar mi primer Gunpla").click();
  await label(page, "Nombre").fill("RX-78-2 de práctica");
  await label(page, "Grado").selectOption({ label: "High Grade (HG)" });
  await label(page, "Escala").selectOption({ label: "1/144" });
  await label(page, "Enlace de YouTube (opcional)").fill("https://youtu.be/M7lc1UVf-VE");
  await button(page, "Guardar Gunpla").click();
  await expect(heading(page, "RX-78-2 de práctica")).toBeVisible({ timeout: 20000 });
  recordPath = new URL(page.url()).hash.replace(/^#\/coleccion\//, "/gunpla/");
  await link(page, "Editar Gunpla").click();
  await label(page, "Notas (opcional)").fill("Comprobación de escritorio.");
  await button(page, "Guardar Gunpla").click();
  await expect(page.getByText("Comprobación de escritorio.")).toBeVisible();
  for (const [field, action] of [
    ["Archivo para subir portada", "Subir portada"],
    ["Archivo para agregar a galería", "Agregar a galería"],
  ]) {
    await label(page, field).setInputFiles({ name: "practica.png", mimeType: "image/png", buffer: image });
    await button(page, action).click();
    await expect(page.getByRole("status").filter({ hasText: "Imágenes actualizadas." })).toBeVisible({ timeout: 45000 });
  }
  await expect(heading(page, "Galería (1/8)")).toBeVisible();
  for (const alt of ["Portada de RX-78-2 de práctica", "Fotografía 1 de RX-78-2 de práctica"]) {
    await expect.poll(() => page.getByAltText(alt).evaluate((img) => img.naturalWidth)).toBeGreaterThan(0);
  }
  await page.locator("iframe").scrollIntoViewIfNeeded();
  const player = page.frameLocator("iframe");
  if (video) {
    try {
      const play = player.locator(".ytp-large-play-button");
      await player.locator(".html5-video-player").waitFor({ state: "attached", timeout: 25000 });
      if (await play.isVisible()) await play.click({ timeout: 15000 });
      else await player.locator(".html5-video-player").click({ timeout: 15000 });
      await expect.poll(() => player.locator("video").evaluate((element) => element.currentTime),
        { timeout: 35000 }).toBeGreaterThan(1);
      console.log("YouTube reprodujo video real en el iframe.");
    } catch (error) {
      console.log(error.message.slice(0, 1000));
      const frame = page.frames().find((candidate) => candidate.parentFrame());
      const detail = await frame?.locator("body").innerText({ timeout: 3000 }).catch(() => "");
      const state = await frame?.evaluate(() => {
        const element = document.querySelector("video");
        const player = document.querySelector(".html5-video-player");
        return {
          paused: element?.paused, ready: element?.readyState, error: element?.error?.code,
          player: player?.className, message: document.querySelector(".ytp-error")?.innerText,
          playButtons: [...document.querySelectorAll("button[aria-label]")].slice(0, 16).map((button) => button.ariaLabel),
        };
      }).catch(() => null);
      console.log("Estado del elemento de video:", state);
      playerIssue = new Error(`Reproducción pendiente. Estado del iframe: ${detail?.slice(0, 350) || frame?.url() || "sin contenido"}`);
    }
  } else {
    await expect(player.getByText("Reproductor de prueba")).toBeVisible();
  }
  if (process.env.GPB_CAPTURE_DIR && !remote) {
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.screenshot({ path: resolve(process.env.GPB_CAPTURE_DIR, "detalle-electron.png"), fullPage: true, scale: "css" });
  }
  await button(page, "Eliminar fotografía 1").click();
  await button(page, "Confirmar imagen").click();
  await expect(heading(page, "Galería (0/8)")).toBeVisible({ timeout: 30000 });
  await button(page, "Eliminar Gunpla").click();
  await button(page, "Confirmar eliminación").click();
  await expect(page.getByText("Gunpla eliminado.", { exact: true })).toBeVisible();
  recordPath = undefined;
  await button(page, "Cerrar sesión").click();
  await expect(button(page, "Iniciar sesión")).toBeVisible();
  await desktop.close();
  page = await start();
  await expect(button(page, "Iniciar sesión")).toBeVisible({ timeout: 95000 });
  assert.equal((await page.evaluate(() => window.gpbDesktop.request({
    path: "/auth/me", method: "GET",
  }))).status, 401);
  console.log("Colección, portada, galería y revocación comprobadas.");
  if (playerIssue) throw playerIssue;
} finally {
  if (remote && desktop && recordPath?.startsWith("/gunpla/")) {
    const page = await desktop.firstWindow().catch(() => null);
    const report = await page?.evaluate((path) => window.gpbDesktop.request({ path, method: "DELETE" }), recordPath).catch(() => null);
    console.log("Limpieza del Gunpla de prueba:", report?.status ?? "pendiente");
    await page?.evaluate(() => window.gpbDesktop.request({ path: "/auth/logout", method: "POST" })).catch(() => {});
  }
  await desktop?.close().catch(() => {});
  server?.kill();
  await rm(profile, { recursive: true, force: true });
}
